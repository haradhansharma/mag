"use client";

import {
  Camera,
  TrendingUp,
  MapPin,
  Clock,
  Eye,
  MessageCircle,
  ArrowRight,
  Flame,
  Star,
  Users,
  Award,
  Shield,
  Zap,
  ChevronRight,
  Bookmark,
  Share2,
  PlayCircle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";

const breakingNews = {
  title: "Massive Flood Displaces Thousands in Northern Districts — Citizens Report from Ground Zero",
  excerpt:
    "Trained citizen journalists from Gaibandha, Kurigram, and Jamalpur are sending real-time updates as floodwaters continue to rise. Over 50,000 families have been affected, with many still awaiting rescue operations.",
  image: "flood",
  category: "Breaking News",
  district: "Gaibandha",
  time: "2 hours ago",
  views: "12.4K",
  reporter: "Anonymous Citizen Reporter",
};

const newsCards = [
  {
    title: "Illegal Sand Mining Continues Unabated in Sylhet River Basins",
    excerpt:
      "Despite government bans, sand mining operations continue to destroy river ecosystems in several upazilas. Local residents report that authorities have turned a blind eye to the activities.",
    category: "Environment",
    district: "Sylhet",
    time: "4 hours ago",
    image: "river",
    points: 85,
  },
  {
    title: "Rural School Students Win National Science Competition",
    excerpt:
      "Students from a remote school in Netrokona have won first place in a national science competition, proving that talent exists everywhere regardless of resources.",
    category: "Education",
    district: "Netrokona",
    time: "6 hours ago",
    image: "school",
    points: 60,
  },
  {
    title: "Health Workers Allege Corruption in Medicine Distribution",
    excerpt:
      "Community health workers in several villages report that allocated medicines are being diverted to private clinics instead of reaching patients in rural areas.",
    category: "Health",
    district: "Bogra",
    time: "8 hours ago",
    image: "health",
    points: 90,
  },
  {
    title: "New Road Construction Brings Hope to Remote Hill Tract Villages",
    excerpt:
      "A newly constructed road connecting three remote villages in the Chittagong Hill Tracts has transformed local commerce and enabled children to attend school regularly.",
    category: "Development",
    district: "Rangamati",
    time: "10 hours ago",
    image: "road",
    points: 45,
  },
  {
    title: "Farmers Protest Against Land Acquisition for Corporate Project",
    excerpt:
      "Hundreds of farmers in Gazipur have staged protests against what they call unfair land acquisition for a corporate agricultural project.",
    category: "Human Rights",
    district: "Gazipur",
    time: "12 hours ago",
    image: "protest",
    points: 75,
  },
  {
    title: "Community-Led Cleanup Drive Restores Polluted Canal in Comilla",
    excerpt:
      "Inspired by citizen journalist reports, local residents organized a massive cleanup drive that restored a canal polluted by industrial waste.",
    category: "Environment",
    district: "Comilla",
    time: "1 day ago",
    image: "cleanup",
    points: 55,
  },
];

const trendingNews = [
  {
    title: "Human Trafficking Ring Exposed Through Citizen Reports",
    time: "3 hours ago",
    views: "8.2K",
  },
  {
    title: "Corruption in Local Government Schools — Teachers Never Show Up",
    time: "5 hours ago",
    views: "6.1K",
  },
  {
    title: "Woman Led Self-Help Group Transforms Village Economy",
    time: "7 hours ago",
    views: "4.8K",
  },
  {
    title: "Police Crackdown on Drug Trade Following Citizen Tips",
    time: "9 hours ago",
    views: "3.9K",
  },
  {
    title: "Solar Power Initiative Lights Up Off-Grid Village",
    time: "11 hours ago",
    views: "3.2K",
  },
];

const placeholderColors: Record<string, string> = {
  flood: "from-blue-900 to-cyan-800",
  river: "from-teal-800 to-blue-700",
  school: "from-amber-800 to-orange-700",
  health: "from-green-800 to-emerald-700",
  road: "from-stone-700 to-amber-800",
  protest: "from-red-900 to-rose-800",
  cleanup: "from-emerald-800 to-green-700",
};

const placeholderIcons: Record<string, React.ReactNode> = {
  flood: <Zap className="w-16 h-16 text-cyan-300/30" />,
  river: <Waves className="w-16 h-16 text-blue-300/30" />,
  school: <Star className="w-16 h-16 text-amber-300/30" />,
  health: <Shield className="w-16 h-16 text-green-300/30" />,
  road: <MapPin className="w-16 h-16 text-amber-300/30" />,
  protest: <Flame className="w-16 h-16 text-rose-300/30" />,
  cleanup: <PlayCircle className="w-16 h-16 text-emerald-300/30" />,
};

// Import Waves icon
import { Waves } from "lucide-react";

function ImagePlaceholder({
  type,
  className,
}: {
  type: string;
  className?: string;
}) {
  return (
    <div
      className={`bg-gradient-to-br ${placeholderColors[type] || "from-gray-700 to-gray-800"} ${className || ""} flex items-center justify-center relative overflow-hidden`}
    >
      {placeholderIcons[type] || <Camera className="w-12 h-12 text-white/20" />}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(255,255,255,0.1),transparent_60%)]" />
    </div>
  );
}

export default function HomePage() {
  return (
    <div className="bg-[#F8F9FC] min-h-screen">
      {/* Breaking News Ticker */}
      <div className="bg-red-600 text-white py-1.5 overflow-hidden">
        <div className="flex items-center max-w-7xl mx-auto px-4">
          <Badge className="bg-red-700 text-white text-[10px] font-bold px-2 py-0 shrink-0 mr-3">
            <Flame className="w-3 h-3 mr-1" /> BREAKING
          </Badge>
          <p className="text-sm font-medium truncate animate-pulse">
            Flood situation deteriorates in northern districts — Live updates
            from citizen reporters
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Featured / Hero Story */}
            <article className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100">
              <div className="md:flex">
                <ImagePlaceholder
                  type={breakingNews.image}
                  className="md:w-1/2 h-56 md:h-auto min-h-[250px]"
                />
                <div className="p-5 md:w-1/2 flex flex-col justify-center">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className="bg-red-100 text-red-700 text-[10px] font-semibold">
                      {breakingNews.category}
                    </Badge>
                    <span className="flex items-center gap-1 text-xs text-gray-500">
                      <MapPin className="w-3 h-3" /> {breakingNews.district}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-gray-500">
                      <Clock className="w-3 h-3" /> {breakingNews.time}
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-gray-900 mb-3 leading-snug">
                    {breakingNews.title}
                  </h2>
                  <p className="text-sm text-gray-600 leading-relaxed mb-4">
                    {breakingNews.excerpt}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500 flex items-center gap-1">
                      <Camera className="w-3 h-3" /> {breakingNews.reporter}
                    </span>
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" /> {breakingNews.views}
                      </span>
                      <button className="hover:text-gray-600">
                        <Bookmark className="w-3.5 h-3.5" />
                      </button>
                      <button className="hover:text-gray-600">
                        <Share2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </article>

            {/* News Grid */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-gray-900">
                  Latest Reports
                </h3>
                <a
                  href="#"
                  className="text-sm text-[#0B6BCB] hover:text-[#0B5AAF] font-medium flex items-center gap-1"
                >
                  View All <ArrowRight className="w-4 h-4" />
                </a>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {newsCards.map((news, i) => (
                  <article
                    key={i}
                    className="bg-white rounded-xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-md transition-shadow group cursor-pointer"
                  >
                    <ImagePlaceholder
                      type={news.image}
                      className="h-40 w-full"
                    />
                    <div className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge
                          variant="secondary"
                          className="text-[10px] font-semibold bg-gray-100 text-gray-600"
                        >
                          {news.category}
                        </Badge>
                        <span className="flex items-center gap-1 text-[11px] text-gray-400">
                          <MapPin className="w-2.5 h-2.5" /> {news.district}
                        </span>
                      </div>
                      <h4 className="font-semibold text-gray-900 text-sm mb-2 leading-snug group-hover:text-[#0B6BCB] transition-colors">
                        {news.title}
                      </h4>
                      <p className="text-xs text-gray-500 leading-relaxed line-clamp-2">
                        {news.excerpt}
                      </p>
                      <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-50">
                        <span className="flex items-center gap-1 text-[11px] text-gray-400">
                          <Clock className="w-3 h-3" /> {news.time}
                        </span>
                        <span className="flex items-center gap-1 text-[11px] text-[#E8A317] font-semibold">
                          <Star className="w-3 h-3 fill-[#E8A317]" /> {news.points}{" "}
                          pts
                        </span>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Trending */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-sm">
                <TrendingUp className="w-4 h-4 text-[#E8A317]" /> Trending Now
              </h3>
              <div className="space-y-3">
                {trendingNews.map((item, i) => (
                  <div
                    key={i}
                    className="flex gap-3 group cursor-pointer pb-3 border-b border-gray-50 last:border-0 last:pb-0"
                  >
                    <span className="text-2xl font-black text-gray-200 group-hover:text-[#E8A317]/30 transition-colors">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <div>
                      <h4 className="text-sm font-medium text-gray-800 leading-snug group-hover:text-[#0B6BCB] transition-colors">
                        {item.title}
                      </h4>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-gray-400">
                        <span className="flex items-center gap-0.5">
                          <Clock className="w-2.5 h-2.5" /> {item.time}
                        </span>
                        <span className="flex items-center gap-0.5">
                          <Eye className="w-2.5 h-2.5" /> {item.views}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Become a Reporter CTA */}
            <div className="bg-gradient-to-br from-[#0B1D3A] to-[#152C50] rounded-xl p-5 text-white">
              <div className="w-10 h-10 bg-[#E8A317] rounded-lg flex items-center justify-center mb-3">
                <Camera className="w-5 h-5 text-white" />
              </div>
              <h3 className="font-bold text-lg mb-2">Become a Reporter</h3>
              <p className="text-sm text-gray-300 mb-4 leading-relaxed">
                Join our network of citizen journalists. Get trained, report news
                from your area, and earn money for valid reports.
              </p>
              <ul className="space-y-2 text-sm text-gray-300 mb-4">
                <li className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4 text-[#E8A317]" /> Free online
                  training course
                </li>
                <li className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4 text-[#E8A317]" /> Earn points
                  for valid reports
                </li>
                <li className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4 text-[#E8A317]" /> Get paid for
                  your contributions
                </li>
                <li className="flex items-center gap-2">
                  <ChevronRight className="w-4 h-4 text-[#E8A317]" /> Full
                  identity protection
                </li>
              </ul>
              <button className="w-full bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] font-semibold py-2.5 rounded-lg text-sm transition-colors">
                Start Your Journey →
              </button>
            </div>

            {/* Stats */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2 text-sm">
                <Award className="w-4 h-4 text-[#E8A317]" /> Our Impact
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  {
                    icon: Users,
                    label: "Active Reporters",
                    value: "1,247",
                  },
                  {
                    icon: Camera,
                    label: "Reports Published",
                    value: "8,392",
                  },
                  {
                    icon: MapPin,
                    label: "Districts Covered",
                    value: "48",
                  },
                  {
                    icon: Eye,
                    label: "Monthly Readers",
                    value: "125K",
                  },
                ].map(({ icon: Icon, label, value }) => (
                  <div
                    key={label}
                    className="text-center p-3 bg-gray-50 rounded-lg"
                  >
                    <Icon className="w-5 h-5 text-[#E8A317] mx-auto mb-1" />
                    <p className="text-lg font-bold text-gray-900">{value}</p>
                    <p className="text-[10px] text-gray-500">{label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Newsletter Sidebar */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-2 text-sm">
                📰 Daily Digest
              </h3>
              <p className="text-xs text-gray-500 mb-3">
                Get top citizen reports in your inbox every morning.
              </p>
              <input
                type="email"
                placeholder="Enter your email"
                className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E8A317] transition-colors mb-2"
              />
              <button className="w-full bg-[#0B1D3A] hover:bg-[#152C50] text-white py-2 rounded-lg text-sm font-medium transition-colors">
                Subscribe Free
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

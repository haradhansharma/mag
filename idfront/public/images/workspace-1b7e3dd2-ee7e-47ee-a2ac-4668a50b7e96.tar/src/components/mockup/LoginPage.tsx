"use client";

import { useState } from "react";
import {
  Mail,
  Lock,
  Eye,
  EyeOff,
  User,
  Phone,
  MapPin,
  Shield,
  Camera,
  GraduationCap,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0B1D3A] via-[#152C50] to-[#0B1D3A] flex">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 flex-col justify-between p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_50%,rgba(232,163,23,0.15),transparent_50%)]" />
        <div className="relative">
          <div className="flex items-center gap-2 mb-8">
            <div className="w-10 h-10 bg-[#E8A317] rounded-lg flex items-center justify-center">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-xl">GroundNews</h1>
              <p className="text-[#E8A317] text-[10px] font-medium tracking-wider uppercase">
                Citizen Reports
              </p>
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-4 leading-tight">
            Every citizen has a story.
            <br />
            <span className="text-[#E8A317]">Tell yours.</span>
          </h2>
          <p className="text-gray-400 text-sm leading-relaxed max-w-md">
            Join our network of trained citizen journalists from rural communities
            across the country. Report the truth from the ground, earn rewards, and
            make a real difference in your community.
          </p>
        </div>

        <div className="relative space-y-4">
          <h3 className="text-white font-semibold text-sm mb-3">
            Why join GroundNews?
          </h3>
          {[
            {
              icon: GraduationCap,
              text: "Free training course on journalism fundamentals",
            },
            {
              icon: Shield,
              text: "Complete identity protection and encrypted submissions",
            },
            {
              icon: Camera,
              text: "Earn points and get paid for verified reports",
            },
          ].map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                <Icon className="w-4 h-4 text-[#E8A317]" />
              </div>
              <span className="text-sm text-gray-300">{text}</span>
            </div>
          ))}

          <div className="flex items-center gap-6 mt-6 pt-6 border-t border-white/10">
            <div>
              <p className="text-2xl font-bold text-white">1,247</p>
              <p className="text-[11px] text-gray-500">Active Reporters</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-white">48</p>
              <p className="text-[11px] text-gray-500">Districts</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-white">8,392</p>
              <p className="text-[11px] text-gray-500">Reports</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center gap-2 justify-center mb-8">
            <div className="w-9 h-9 bg-[#E8A317] rounded-lg flex items-center justify-center">
              <Camera className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-white font-bold text-lg">GroundNews</h1>
          </div>

          <div className="bg-white rounded-2xl shadow-2xl p-8">
            {/* Tabs */}
            <div className="flex mb-6 bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setIsSignUp(false)}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                  !isSignUp
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                Login
              </button>
              <button
                onClick={() => setIsSignUp(true)}
                className={`flex-1 py-2 rounded-md text-sm font-medium transition-colors ${
                  isSignUp
                    ? "bg-white text-gray-900 shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                Sign Up
              </button>
            </div>

            {!isSignUp ? (
              /* Login Form */
              <div className="space-y-4">
                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold text-gray-900">
                    Welcome Back
                  </h2>
                  <p className="text-sm text-gray-500 mt-1">
                    Sign in to your reporter account
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="email"
                      placeholder="you@example.com"
                      className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-3 py-2.5 text-sm outline-none focus:border-[#E8A317] transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-10 py-2.5 text-sm outline-none focus:border-[#E8A317] transition-colors"
                    />
                    <button
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 rounded accent-[#E8A317]" />
                    <span className="text-sm text-gray-600">Remember me</span>
                  </label>
                  <a
                    href="#"
                    className="text-sm text-[#0B6BCB] hover:text-[#0B5AAF] font-medium"
                  >
                    Forgot password?
                  </a>
                </div>

                <button className="w-full bg-[#0B1D3A] hover:bg-[#152C50] text-white py-2.5 rounded-lg text-sm font-semibold transition-colors">
                  Sign In
                </button>

                <div className="relative flex items-center my-4">
                  <div className="flex-1 border-t border-gray-200" />
                  <span className="px-3 text-xs text-gray-400">or continue with</span>
                  <div className="flex-1 border-t border-gray-200" />
                </div>

                <button className="w-full flex items-center justify-center gap-2 border border-gray-200 py-2.5 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  Google
                </button>
              </div>
            ) : (
              /* Sign Up Form */
              <div className="space-y-4">
                <div className="text-center mb-4">
                  <h2 className="text-xl font-bold text-gray-900">
                    Create Your Account
                  </h2>
                  <p className="text-sm text-gray-500 mt-1">
                    Join as a contributor or reader
                  </p>
                </div>

                {/* Account Type */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    I want to...
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button className="p-3 rounded-lg border-2 border-[#E8A317] bg-[#E8A317]/5 text-center">
                      <Camera className="w-5 h-5 mx-auto mb-1 text-[#E8A317]" />
                      <span className="text-xs font-semibold text-gray-900">
                        Become a Reporter
                      </span>
                      <p className="text-[10px] text-gray-500 mt-0.5">
                        Submit news & earn points
                      </p>
                    </button>
                    <button className="p-3 rounded-lg border border-gray-200 hover:border-gray-300 text-center transition-colors">
                      <User className="w-5 h-5 mx-auto mb-1 text-gray-400" />
                      <span className="text-xs font-medium text-gray-600">
                        Just Read News
                      </span>
                      <p className="text-[10px] text-gray-400 mt-0.5">
                        Browse & follow stories
                      </p>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Your name"
                        className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-3 py-2.5 text-sm outline-none focus:border-[#E8A317]"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input
                        type="tel"
                        placeholder="+880"
                        className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-3 py-2.5 text-sm outline-none focus:border-[#E8A317]"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="email"
                      placeholder="you@example.com"
                      className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-3 py-2.5 text-sm outline-none focus:border-[#E8A317]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    District
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <select className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-3 py-2.5 text-sm text-gray-700 outline-none focus:border-[#E8A317] appearance-none">
                      <option value="">Select your district</option>
                      <option>Dhaka</option>
                      <option>Chittagong</option>
                      <option>Sylhet</option>
                      <option>Rajshahi</option>
                      <option>Khulna</option>
                      <option>Barisal</option>
                      <option>Rangpur</option>
                      <option>Mymensingh</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type={showPassword ? "text" : "password"}
                      placeholder="Create a strong password"
                      className="w-full bg-gray-50 border border-gray-200 rounded-lg pl-10 pr-10 py-2.5 text-sm outline-none focus:border-[#E8A317]"
                    />
                    <button
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="mt-0.5 w-4 h-4 rounded accent-[#E8A317]"
                  />
                  <span className="text-xs text-gray-500 leading-relaxed">
                    I agree to the{" "}
                    <a href="#" className="text-[#0B6BCB] underline">
                      Terms of Service
                    </a>{" "}
                    and{" "}
                    <a href="#" className="text-[#0B6BCB] underline">
                      Privacy Policy
                    </a>
                    . I understand that as a reporter, my submissions will be
                    verified before publication.
                  </span>
                </label>

                <button className="w-full bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] py-2.5 rounded-lg text-sm font-semibold transition-colors">
                  Create Account
                </button>

                <p className="text-xs text-gray-400 text-center">
                  Already have an account?{" "}
                  <button
                    onClick={() => setIsSignUp(false)}
                    className="text-[#0B6BCB] font-medium"
                  >
                    Sign In
                  </button>
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

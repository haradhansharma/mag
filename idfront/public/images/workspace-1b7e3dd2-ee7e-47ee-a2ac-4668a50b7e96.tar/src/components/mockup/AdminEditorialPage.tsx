"use client";

import {
  CheckCircle2,
  XCircle,
  Clock,
  Eye,
  MapPin,
  Star,
  Camera,
  AlertTriangle,
  Search,
  Filter,
  ChevronRight,
  MoreVertical,
  ArrowRight,
  BarChart3,
  Users,
  FileText,
  Shield,
  Flag,
  Image as ImageIcon,
  Edit,
  Send,
  Trash2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const pendingSubmissions = [
  {
    id: "SUB-2026-0847",
    title: "Massive fish die-off reported in Buriganga River — Industrial pollution suspected",
    reporter: "GND-DHK-123",
    district: "Dhaka",
    category: "Environment",
    priority: "high",
    submittedAt: "2 hours ago",
    photos: 4,
    whComplete: true,
  },
  {
    id: "SUB-2026-0846",
    title: "Local council member accused of embezzling relief funds",
    reporter: "GND-KHL-089",
    district: "Khulna",
    category: "Corruption",
    priority: "high",
    submittedAt: "3 hours ago",
    photos: 2,
    whComplete: true,
  },
  {
    id: "SUB-2026-0845",
    title: "Road collapse injures 3 in Cox's Bazar after heavy rain",
    reporter: "GND-CXB-034",
    district: "Cox's Bazar",
    category: "Accident",
    priority: "breaking",
    submittedAt: "4 hours ago",
    photos: 3,
    whComplete: false,
  },
  {
    id: "SUB-2026-0844",
    title: "New community library opens in remote village of Sunamganj",
    reporter: "GND-SMG-012",
    district: "Sunamganj",
    category: "Education",
    priority: "routine",
    submittedAt: "5 hours ago",
    photos: 2,
    whComplete: true,
  },
  {
    id: "SUB-2026-0843",
    title: "Unauthorized construction blocks natural water drainage in Rajshahi",
    reporter: "GND-RJH-056",
    district: "Rajshahi",
    category: "Environment",
    priority: "medium",
    submittedAt: "6 hours ago",
    photos: 1,
    whComplete: true,
  },
];

const adminStats = [
  { label: "Pending Review", value: "23", icon: Clock, color: "bg-yellow-100 text-yellow-600", link: null },
  { label: "Published Today", value: "12", icon: CheckCircle2, color: "bg-green-100 text-green-600", link: null },
  { label: "Active Contributors", value: "1,247", icon: Users, color: "bg-blue-100 text-blue-600", link: null },
  { label: "Reports This Month", value: "384", icon: FileText, color: "bg-purple-100 text-purple-600", link: null },
];

export default function AdminEditorialPage() {
  return (
    <div className="bg-[#F8F9FC] min-h-screen">
      {/* Admin Top Bar */}
      <div className="bg-[#0B1D3A] text-white py-2 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#E8A317]" />
            <span className="text-xs font-medium">Admin Panel — Editorial Management</span>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="text-gray-400">Editor: Ahmed Khan</span>
            <div className="w-6 h-6 bg-[#E8A317] rounded-full flex items-center justify-center text-[10px] font-bold text-[#0B1D3A]">
              AK
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Admin Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {adminStats.map(({ label, value, icon: Icon, color }) => (
            <div
              key={label}
              className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 flex items-center gap-3"
            >
              <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center`}>
                <Icon className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xl font-bold text-gray-900">{value}</p>
                <p className="text-[11px] text-gray-500">{label}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Editorial Queue */}
          <div className="lg:col-span-2 space-y-4">
            {/* Header */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-bold text-gray-900 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#E8A317]" />
                  Editorial Queue
                  <Badge className="bg-red-100 text-red-700 text-[10px] font-bold">
                    {pendingSubmissions.length} pending
                  </Badge>
                </h2>
                <div className="flex items-center gap-2">
                  <button className="flex items-center gap-1 text-xs bg-gray-50 border border-gray-200 px-2 py-1 rounded-lg text-gray-600 hover:bg-gray-100">
                    <Filter className="w-3 h-3" /> Filter
                  </button>
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search submissions..."
                      className="bg-gray-50 border border-gray-200 rounded-lg pl-8 pr-3 py-1.5 text-xs outline-none focus:border-[#E8A317] w-48"
                    />
                  </div>
                </div>
              </div>

              {/* Submissions List */}
              <div className="divide-y divide-gray-50">
                {pendingSubmissions.map((sub) => (
                  <div
                    key={sub.id}
                    className="flex items-start gap-3 py-3 hover:bg-gray-50/50 transition-colors cursor-pointer group"
                  >
                    {/* Priority Indicator */}
                    <div
                      className={`w-1 h-full min-h-[60px] rounded-full shrink-0 ${
                        sub.priority === "breaking"
                          ? "bg-red-500"
                          : sub.priority === "high"
                          ? "bg-orange-500"
                          : sub.priority === "medium"
                          ? "bg-yellow-400"
                          : "bg-gray-300"
                      }`}
                    />

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-[10px] text-gray-400 font-mono">
                          {sub.id}
                        </span>
                        <Badge
                          variant="secondary"
                          className="text-[10px] bg-gray-100 text-gray-600"
                        >
                          {sub.category}
                        </Badge>
                        {sub.priority === "breaking" && (
                          <Badge className="bg-red-100 text-red-700 text-[10px]">
                            BREAKING
                          </Badge>
                        )}
                        {!sub.whComplete && (
                          <Badge className="bg-orange-100 text-orange-700 text-[10px] flex items-center gap-0.5">
                            <AlertTriangle className="w-2.5 h-2.5" /> Incomplete
                          </Badge>
                        )}
                      </div>
                      <h3 className="text-sm font-semibold text-gray-900 leading-snug group-hover:text-[#0B6BCB] transition-colors">
                        {sub.title}
                      </h3>
                      <div className="flex items-center gap-3 mt-1 text-[11px] text-gray-400">
                        <span className="flex items-center gap-0.5">
                          <Shield className="w-2.5 h-2.5" /> {sub.reporter}
                        </span>
                        <span className="flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5" /> {sub.district}
                        </span>
                        <span className="flex items-center gap-0.5">
                          <ImageIcon className="w-2.5 h-2.5" /> {sub.photos} photos
                        </span>
                        <span>{sub.submittedAt}</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        className="w-7 h-7 rounded-lg bg-green-50 hover:bg-green-100 flex items-center justify-center text-green-600"
                        title="Approve"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                      </button>
                      <button
                        className="w-7 h-7 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center text-red-600"
                        title="Reject"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                      <button
                        className="w-7 h-7 rounded-lg bg-blue-50 hover:bg-blue-100 flex items-center justify-center text-blue-600"
                        title="Edit"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-3 text-sm">
                Quick Actions
              </h3>
              <div className="space-y-2">
                {[
                  { icon: CheckCircle2, label: "Approve All Routine", color: "text-green-600 bg-green-50" },
                  { icon: Flag, label: "Flag for Review", color: "text-orange-600 bg-orange-50" },
                  { icon: Send, label: "Send Feedback", color: "text-blue-600 bg-blue-50" },
                  { icon: BarChart3, label: "View Analytics", color: "text-purple-600 bg-purple-50" },
                ].map(({ icon: Icon, label, color }) => (
                  <button
                    key={label}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium ${color} hover:opacity-80 transition-opacity`}
                  >
                    <Icon className="w-4 h-4" /> {label}
                    <ChevronRight className="w-3 h-3 ml-auto opacity-50" />
                  </button>
                ))}
              </div>
            </div>

            {/* Submission Preview */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-3 text-sm">
                Preview: SUB-2026-0847
              </h3>
              <div className="space-y-3">
                <div className="bg-gray-100 rounded-lg h-32 flex items-center justify-center">
                  <ImageIcon className="w-8 h-8 text-gray-300" />
                  <span className="ml-2 text-xs text-gray-400">
                    4 photos attached
                  </span>
                </div>
                <div className="space-y-2">
                  {["What", "When", "Where", "Who", "Why", "How"].map((wh) => (
                    <div
                      key={wh}
                      className="flex items-center gap-2 text-xs"
                    >
                      <Badge
                        variant="outline"
                        className="text-[10px] font-bold w-10 justify-center shrink-0"
                      >
                        {wh}
                      </Badge>
                      <span className="text-gray-500 truncate">
                        {wh === "What"
                          ? "Massive fish die-off reported..."
                          : wh === "When"
                          ? "April 5, 2026, early morning..."
                          : wh === "Where"
                          ? "Buriganga River near..."
                          : "Content preview..."}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Approve
                  </button>
                  <button className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1">
                    <XCircle className="w-3.5 h-3.5" /> Reject
                  </button>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-3 text-sm">
                Recent Activity
              </h3>
              <div className="space-y-3">
                {[
                  { action: "Approved", title: "Flood report from Gaibandha", time: "15 min ago", type: "approve" },
                  { action: "Rejected", title: "Duplicate report from Dhaka", time: "30 min ago", type: "reject" },
                  { action: "Feedback sent", title: "Incomplete WH data", time: "1 hour ago", type: "feedback" },
                  { action: "Published", title: "School corruption story", time: "2 hours ago", type: "publish" },
                ].map(({ action, title, time, type }) => (
                  <div key={title} className="flex items-start gap-2">
                    <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                      type === "approve" || type === "publish" ? "bg-green-500" :
                      type === "reject" ? "bg-red-500" : "bg-yellow-500"
                    }`} />
                    <div>
                      <p className="text-xs text-gray-700">
                        <span className="font-semibold">{action}</span> — {title}
                      </p>
                      <p className="text-[10px] text-gray-400">{time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

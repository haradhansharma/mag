"use client";

import { useState } from "react";
import {
  GraduationCap,
  PlayCircle,
  CheckCircle2,
  Lock,
  Clock,
  Star,
  ChevronRight,
  Trophy,
  BookOpen,
  Shield,
  Camera,
  FileText,
  AlertTriangle,
  Award,
  Video,
  RotateCcw,
  ArrowRight,
  BarChart3,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";

const modules = [
  {
    id: 1,
    title: "Introduction to Citizen Journalism",
    desc: "What is citizen journalism, its importance, ethics, and your role as a citizen reporter.",
    duration: "45 min",
    lessons: 4,
    status: "completed",
    score: 92,
  },
  {
    id: 2,
    title: "The WH Question Framework",
    desc: "Master the Who, What, When, Where, Why, and How framework for structured news reporting.",
    duration: "60 min",
    lessons: 5,
    status: "completed",
    score: 88,
  },
  {
    id: 3,
    title: "Mobile Photography for News",
    desc: "How to capture compelling photos and videos using your smartphone for news reporting.",
    duration: "50 min",
    lessons: 4,
    status: "completed",
    score: 95,
  },
  {
    id: 4,
    title: "Digital Security & Anonymous Reporting",
    desc: "Protect your identity, secure your communications, and understand encryption basics.",
    duration: "40 min",
    lessons: 3,
    status: "in-progress",
    score: null,
  },
  {
    id: 5,
    title: "Field Safety & Risk Assessment",
    desc: "How to stay safe while reporting from the field, assess risks, and handle dangerous situations.",
    duration: "35 min",
    lessons: 3,
    status: "locked",
    score: null,
  },
  {
    id: 6,
    title: "News Writing & Submission",
    desc: "How to write clear, factual news reports and submit them through the platform effectively.",
    duration: "55 min",
    lessons: 5,
    status: "locked",
    score: null,
  },
];

const quizQuestions = [
  {
    id: 1,
    question: "When reporting a crime scene, which of the following should be your FIRST priority?",
    options: [
      "Take as many photos as possible",
      "Ensure your personal safety first",
      "Post immediately on social media",
      "Confront the suspects",
    ],
    correct: 1,
  },
  {
    id: 2,
    question: "Which of the following is NOT a standard WH question in news reporting?",
    options: ["Who", "What", "When", "How much"],
    correct: 3,
  },
  {
    id: 3,
    question: "What is the best way to protect your identity while submitting a report?",
    options: [
      "Use a fake name on social media",
      "Submit through the encrypted platform without personal details",
      "Ask a friend to submit for you",
      "Hide your face in profile photos only",
    ],
    correct: 1,
  },
];

const courseStats = {
  totalModules: 6,
  completedModules: 3,
  totalLessons: 24,
  completedLessons: 13,
  averageScore: 91.7,
  timeSpent: "3h 25m",
  estimatedRemaining: "2h 5m",
};

export default function TrainingLMS() {
  const [activeModule, setActiveModule] = useState(4);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});

  const completedCount = modules.filter((m) => m.status === "completed").length;
  const overallProgress = (completedCount / modules.length) * 100;

  return (
    <div className="bg-[#F8F9FC] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#E8A317] rounded-xl flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                Citizen Reporter Training Course
              </h1>
              <p className="text-sm text-gray-500">
                Complete all 6 modules to become a certified contributor
              </p>
            </div>
          </div>
          <Badge className="bg-amber-100 text-amber-700 text-xs font-semibold px-3 py-1">
            <Clock className="w-3 h-3 mr-1" /> In Progress — Module {completedCount + 1} of {modules.length}
          </Badge>
        </div>

        {/* Course Overview Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {[
            { label: "Progress", value: `${Math.round(overallProgress)}%`, icon: BarChart3, color: "text-blue-600" },
            { label: "Avg Score", value: `${courseStats.averageScore}%`, icon: Star, color: "text-amber-600" },
            { label: "Time Spent", value: courseStats.timeSpent, icon: Clock, color: "text-emerald-600" },
            { label: "Remaining", value: courseStats.estimatedRemaining, icon: PlayCircle, color: "text-purple-600" },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 flex items-center gap-3">
              <Icon className={`w-5 h-5 ${color}`} />
              <div>
                <p className="text-lg font-bold text-gray-900">{value}</p>
                <p className="text-[11px] text-gray-500">{label}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Overall Progress Bar */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Overall Course Progress</span>
            <span className="text-sm font-bold text-[#E8A317]">
              {completedCount}/{modules.length} modules completed
            </span>
          </div>
          <Progress value={overallProgress} className="h-3" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Modules List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-4 border-b border-gray-100">
                <h2 className="font-bold text-gray-900 text-sm">Course Modules</h2>
              </div>
              <div className="divide-y divide-gray-50">
                {modules.map((mod) => (
                  <button
                    key={mod.id}
                    onClick={() => setActiveModule(mod.id)}
                    className={`w-full text-left p-4 flex items-start gap-3 transition-colors hover:bg-gray-50 ${
                      activeModule === mod.id ? "bg-[#E8A317]/5 border-l-3 border-l-[#E8A317]" : ""
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 text-sm font-bold ${
                        mod.status === "completed"
                          ? "bg-green-100 text-green-600"
                          : mod.status === "in-progress"
                          ? "bg-[#E8A317] text-white"
                          : "bg-gray-100 text-gray-400"
                      }`}
                    >
                      {mod.status === "completed" ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : mod.status === "locked" ? (
                        <Lock className="w-4 h-4" />
                      ) : (
                        mod.id
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium ${
                        mod.status === "locked" ? "text-gray-400" : "text-gray-900"
                      }`}>
                        {mod.title}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[11px] text-gray-400 flex items-center gap-0.5">
                          <Clock className="w-2.5 h-2.5" /> {mod.duration}
                        </span>
                        <span className="text-[11px] text-gray-400">
                          {mod.lessons} lessons
                        </span>
                        {mod.score && (
                          <Badge className="bg-green-100 text-green-700 text-[10px]">
                            {mod.score}%
                          </Badge>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Certificate Preview */}
            <div className="mt-4 bg-gradient-to-br from-[#0B1D3A] to-[#152C50] rounded-xl p-5 text-white">
              <Award className="w-8 h-8 text-[#E8A317] mb-3" />
              <h3 className="font-bold mb-1">Certificate of Completion</h3>
              <p className="text-xs text-gray-300 mb-3">
                Complete all modules with 70%+ average to earn your certificate and become a verified contributor.
              </p>
              <div className="flex items-center gap-2 text-xs text-gray-400">
                <CheckCircle2 className="w-3 h-3 text-green-400" />
                Your current average: 91.7% — On track!
              </div>
            </div>
          </div>

          {/* Module Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Current Module */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6">
                <div className="flex items-center gap-2 mb-2">
                  <Badge className="bg-[#E8A317] text-[#0B1D3A] text-[10px] font-bold">
                    MODULE {activeModule}
                  </Badge>
                  <Badge variant="secondary" className="text-[10px]">
                    In Progress
                  </Badge>
                </div>
                <h2 className="text-xl font-bold text-gray-900 mb-2">
                  Digital Security & Anonymous Reporting
                </h2>
                <p className="text-sm text-gray-600 leading-relaxed mb-4">
                  This module covers essential digital security practices for citizen journalists.
                  You will learn how to protect your identity, secure your communications, use
                  encryption tools, and understand the principles of anonymous reporting.
                </p>

                {/* Lesson List */}
                <div className="space-y-2 mb-6">
                  {[
                    { title: "Why Digital Security Matters", duration: "10 min", type: "video", completed: true },
                    { title: "Understanding Encryption Basics", duration: "12 min", type: "video", completed: true },
                    { title: "Secure Communication Tools", duration: "18 min", type: "video", completed: false },
                  ].map((lesson, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg"
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                        lesson.completed ? "bg-green-100" : "bg-blue-100"
                      }`}>
                        {lesson.type === "video" ? (
                          <Video className={`w-4 h-4 ${lesson.completed ? "text-green-600" : "text-blue-600"}`} />
                        ) : (
                          <BookOpen className={`w-4 h-4 ${lesson.completed ? "text-green-600" : "text-blue-600"}`} />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{lesson.title}</p>
                        <p className="text-[11px] text-gray-400">{lesson.duration}</p>
                      </div>
                      {lesson.completed ? (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      ) : (
                        <button className="bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] px-3 py-1 rounded-lg text-xs font-semibold transition-colors">
                          Continue
                        </button>
                      )}
                    </div>
                  ))}
                </div>

                {/* Video Placeholder */}
                <div className="bg-gray-900 rounded-xl h-48 flex flex-col items-center justify-center mb-6 relative">
                  <PlayCircle className="w-16 h-16 text-white/30 mb-2" />
                  <p className="text-white/50 text-sm">Lesson 3: Secure Communication Tools</p>
                  <p className="text-white/30 text-xs mt-1">18 minutes</p>
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700 rounded-b-xl">
                    <div className="h-full bg-[#E8A317] rounded-b-xl" style={{ width: "45%" }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Practice Quiz */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                <h2 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#E8A317]" /> Module Quiz (Practice)
                </h2>
                <Badge variant="secondary" className="text-[10px]">
                  {quizQuestions.length} Questions
                </Badge>
              </div>
              <div className="p-6 space-y-6">
                {quizQuestions.map((q, qi) => (
                  <div key={q.id}>
                    <p className="text-sm font-medium text-gray-900 mb-3">
                      <span className="text-[#E8A317] font-bold">{qi + 1}.</span> {q.question}
                    </p>
                    <div className="space-y-2">
                      {q.options.map((opt, oi) => (
                        <label
                          key={oi}
                          className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                            selectedAnswers[q.id] === oi
                              ? "border-[#E8A317] bg-[#E8A317]/5"
                              : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                          }`}
                        >
                          <input
                            type="radio"
                            name={`q-${q.id}`}
                            checked={selectedAnswers[q.id] === oi}
                            onChange={() => setSelectedAnswers({ ...selectedAnswers, [q.id]: oi })}
                            className="accent-[#E8A317]"
                          />
                          <span className="text-sm text-gray-700">{opt}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <p className="text-xs text-gray-400">
                    Answer all questions to submit. Minimum 70% required to pass.
                  </p>
                  <button className="bg-[#0B1D3A] hover:bg-[#152C50] text-white px-5 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2">
                    Submit Quiz <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Retake Notice */}
            <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-amber-800 text-sm">
                  Exam Retake Policy
                </h4>
                <p className="text-xs text-amber-700 mt-1 leading-relaxed">
                  If you score below 70% on the final exam, you can re-enroll
                  after 3 months. Practice quizzes are unlimited and don&apos;t
                  count toward your final grade.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import {
  Newspaper,
  Menu,
  Search,
  Bell,
  User,
  LogIn,
  Camera,
  GraduationCap,
  Shield,
  ChevronDown,
} from "lucide-react";

const categories = [
  "Politics",
  "Crime & Justice",
  "Education",
  "Health",
  "Agriculture",
  "Environment",
  "Human Rights",
  "Technology",
  "Sports",
  "Culture",
];

export default function Navbar({ currentPage }: { currentPage: string }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-[#0B1D3A] shadow-lg">
      {/* Top Bar */}
      <div className="bg-[#071428] text-gray-400 text-xs py-1.5">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <span>
            Independent Citizen Journalism — Truth from the Ground
          </span>
          <div className="hidden sm:flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Shield className="w-3 h-3" /> Secure & Anonymous
            </span>
            <span>📧 contact@groundnews.com</span>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 bg-[#E8A317] rounded-lg flex items-center justify-center">
              <Newspaper className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-white font-bold text-lg leading-tight tracking-tight">
                GroundNews
              </h1>
              <p className="text-[#E8A317] text-[10px] font-medium -mt-0.5 tracking-wider uppercase">
                Citizen Reports
              </p>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {["Home", "News", "Categories", "Districts", "About"].map(
              (item) => (
                <button
                  key={item}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    currentPage === item.toLowerCase()
                      ? "text-[#E8A317] bg-white/10"
                      : "text-gray-300 hover:text-white hover:bg-white/5"
                  }`}
                >
                  {item}
                </button>
              )
            )}
            <div className="relative group">
              <button className="flex items-center gap-1 px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:text-white hover:bg-white/5 transition-colors">
                Get Involved <ChevronDown className="w-3 h-3" />
              </button>
              <div className="absolute top-full left-0 mt-1 w-52 bg-[#152C50] rounded-lg shadow-xl border border-white/10 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                <div className="p-1">
                  <a
                    href="#"
                    className="flex items-center gap-2 px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/10 rounded-md"
                  >
                    <Camera className="w-4 h-4 text-[#E8A317]" /> Become a
                    Reporter
                  </a>
                  <a
                    href="#"
                    className="flex items-center gap-2 px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/10 rounded-md"
                  >
                    <GraduationCap className="w-4 h-4 text-[#E8A317]" /> Take
                    Training Course
                  </a>
                  <a
                    href="#"
                    className="flex items-center gap-2 px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/10 rounded-md"
                  >
                    <Shield className="w-4 h-4 text-[#E8A317]" /> Partner with
                    Us
                  </a>
                </div>
              </div>
            </div>
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            {/* Search */}
            <div className="hidden md:flex items-center">
              {searchOpen ? (
                <div className="flex items-center bg-white/10 rounded-lg border border-white/20 px-3 py-1.5">
                  <Search className="w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search news..."
                    className="bg-transparent text-white text-sm ml-2 outline-none w-48 placeholder:text-gray-500"
                    autoFocus
                    onBlur={() => setSearchOpen(false)}
                  />
                </div>
              ) : (
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-gray-300 hover:text-white hover:bg-white/10"
                  onClick={() => setSearchOpen(true)}
                >
                  <Search className="w-5 h-5" />
                </Button>
              )}
            </div>

            {/* Notifications */}
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-300 hover:text-white hover:bg-white/10 relative hidden sm:flex"
            >
              <Bell className="w-5 h-5" />
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 rounded-full text-[10px] font-bold text-white flex items-center justify-center">
                3
              </span>
            </Button>

            {/* Submit News */}
            <Button className="hidden sm:flex bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] font-semibold text-sm gap-1.5">
              <Camera className="w-4 h-4" />
              Submit News
            </Button>

            {/* Auth */}
            <div className="hidden md:flex items-center gap-1">
              <Button
                variant="ghost"
                className="text-gray-300 hover:text-white hover:bg-white/10 text-sm gap-1.5"
              >
                <LogIn className="w-4 h-4" />
                Login
              </Button>
              <Button
                variant="ghost"
                className="text-[#E8A317] hover:text-[#F0B840] hover:bg-[#E8A317]/10 text-sm gap-1.5"
              >
                <User className="w-4 h-4" />
                Sign Up
              </Button>
            </div>

            {/* Mobile Menu */}
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  className="lg:hidden text-gray-300 hover:text-white hover:bg-white/10"
                >
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className="bg-[#0B1D3A] border-white/10 w-72"
              >
                <SheetTitle className="text-white">Menu</SheetTitle>
                <div className="mt-6 space-y-1">
                  {[
                    "Home",
                    "Latest News",
                    "Categories",
                    "Districts",
                    "About Us",
                  ].map((item) => (
                    <a
                      key={item}
                      href="#"
                      className="block px-4 py-2.5 text-sm text-gray-300 hover:text-white hover:bg-white/10 rounded-lg"
                    >
                      {item}
                    </a>
                  ))}
                  <hr className="border-white/10 my-3" />
                  <a
                    href="#"
                    className="flex items-center gap-2 px-4 py-2.5 text-sm text-[#E8A317] font-medium"
                  >
                    <Camera className="w-4 h-4" /> Submit News
                  </a>
                  <a
                    href="#"
                    className="flex items-center gap-2 px-4 py-2.5 text-sm text-[#E8A317] font-medium"
                  >
                    <GraduationCap className="w-4 h-4" /> Training Course
                  </a>
                  <hr className="border-white/10 my-3" />
                  <a
                    href="#"
                    className="block px-4 py-2.5 text-sm text-gray-300 hover:text-white"
                  >
                    Login
                  </a>
                  <a
                    href="#"
                    className="block px-4 py-2.5 text-sm text-gray-300 hover:text-white"
                  >
                    Sign Up
                  </a>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Category Bar */}
        <div className="flex items-center gap-1 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
          <span className="text-gray-500 text-xs font-medium mr-1 shrink-0">
            Topics:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              className="shrink-0 px-2.5 py-1 text-xs text-gray-400 hover:text-[#E8A317] hover:bg-white/5 rounded-full transition-colors"
            >
              {cat}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}

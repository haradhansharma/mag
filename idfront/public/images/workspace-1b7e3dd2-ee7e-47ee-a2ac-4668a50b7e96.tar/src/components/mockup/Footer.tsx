"use client";

import {
  Newspaper,
  Camera,
  GraduationCap,
  Shield,
  Mail,
  MapPin,
  Phone,
  Heart,
  ArrowUp,
  Facebook,
  Twitter,
  Youtube,
  Send,
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#071428] text-gray-400">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-[#E8A317] rounded-lg flex items-center justify-center">
                <Newspaper className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold text-lg leading-tight">
                  GroundNews
                </h3>
                <p className="text-[#E8A317] text-[10px] font-medium -mt-0.5 tracking-wider uppercase">
                  Citizen Reports
                </p>
              </div>
            </div>
            <p className="text-sm text-gray-500 leading-relaxed">
              An independent news organization powered by trained citizen
              journalists from rural communities. Bringing truth from the ground
              to the world.
            </p>
            <div className="flex items-center gap-3 mt-4">
              {[Facebook, Twitter, Youtube, Send].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-8 h-8 rounded-full bg-white/5 hover:bg-[#E8A317]/20 flex items-center justify-center transition-colors"
                >
                  <Icon className="w-4 h-4 text-gray-400 hover:text-[#E8A317]" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Quick Links
            </h4>
            <ul className="space-y-2 text-sm">
              {["Latest News", "Breaking News", "Categories", "Districts", "Popular Stories", "Archives"].map(
                (link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="hover:text-[#E8A317] transition-colors"
                    >
                      {link}
                    </a>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Get Involved */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Get Involved
            </h4>
            <ul className="space-y-2 text-sm">
              {[
                { icon: Camera, label: "Become a Reporter" },
                { icon: GraduationCap, label: "Training Course" },
                { icon: Shield, label: "Partner Organizations" },
                { icon: Mail, label: "Contact Us" },
              ].map(({ icon: Icon, label }) => (
                <li key={label}>
                  <a
                    href="#"
                    className="flex items-center gap-2 hover:text-[#E8A317] transition-colors"
                  >
                    <Icon className="w-3.5 h-3.5" /> {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
              Newsletter
            </h4>
            <p className="text-sm text-gray-500 mb-3">
              Get the latest citizen reports delivered to your inbox daily.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-gray-600 outline-none focus:border-[#E8A317]/50"
              />
              <button className="bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] px-4 py-2 rounded-lg text-sm font-semibold transition-colors">
                Go
              </button>
            </div>
            <div className="mt-6 space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5" />
                <span>Dhaka, Bangladesh</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5" />
                <span>contact@groundnews.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5" />
                <span>+880 1XXX-XXXXXX</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-600">
          <p>
            &copy; 2026 GroundNews — Citizen Reports. All rights reserved.
            Independent news organization.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-gray-400 transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-gray-400 transition-colors">
              Terms of Service
            </a>
            <a href="#" className="hover:text-gray-400 transition-colors">
              Editorial Policy
            </a>
            <span className="flex items-center gap-1">
              Made with <Heart className="w-3 h-3 text-red-500" /> for truth
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

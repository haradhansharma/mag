"use client";

import {
  Camera,
  MapPin,
  Clock,
  Eye,
  Bookmark,
  Share2,
  Facebook,
  Twitter,
  Send,
  LinkIcon,
  MessageCircle,
  ChevronRight,
  ArrowLeft,
  Shield,
  Star,
  ThumbsUp,
  Flag,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

const article = {
  title: "Illegal Sand Mining Continues Unabated in Sylhet River Basins — Despite Government Ban",
  category: "Environment",
  district: "Sylhet",
  upazila: "Companiganj",
  date: "April 5, 2026",
  time: "4:30 PM",
  reporter: "Anonymous Citizen Reporter",
  reporterCode: "GND-SYL-047",
  views: "8,234",
  comments: 24,
  points: 85,
  status: "Verified",
};

const whContent = {
  what: "Large-scale illegal sand extraction is continuing in the Surma and Kushiyara river basins in Companiganj upazila, Sylhet. Excavators and dredging machines are operating openly despite an official government ban imposed in January 2026. The operations are causing severe riverbank erosion, threatening nearby villages and agricultural land.",
  when: "The illegal mining activities have been ongoing for the past 6 months. Our reporter documented fresh extraction activities during visits on April 2, April 4, and April 5, 2026. Operations typically occur between 10 PM and 4 AM to avoid detection.",
  where: "The primary sites are located along a 3 km stretch of the Surma River near Baluchar village and along the Kushiyara River near Itakhola. GPS coordinates of extraction sites have been recorded and submitted to editorial verification.",
  who: "The operations are reportedly run by a local syndicate working with a sand supply company based in Sylhet city. Local residents identified at least 3 individuals managing the operations. Government officials from the Upazila Nirbahi Officer's office have been informed but no action has been taken.",
  why: "Sand demand for construction projects in Sylhet city has surged, creating a lucrative black market. A truckload of river sand sells for ৳8,000-12,000 in the city. The illegal operators earn an estimated ৳5-8 lakh per week from these operations.",
  how: "Heavy excavators and dredging machines are brought in on trucks at night. The extracted sand is loaded directly onto waiting trucks and transported to construction sites. Local residents who have attempted to report the activities to authorities claim their complaints have been ignored. Riverbank erosion has already destroyed portions of the road connecting Baluchar to the upazila headquarters.",
};

const relatedNews = [
  {
    title: "Riverbank Eruption Destroys 15 Homes in Habiganj",
    district: "Habiganj",
    time: "1 day ago",
    color: "from-teal-800 to-blue-700",
  },
  {
    title: "Government Announces New Environmental Task Force",
    district: "Dhaka",
    time: "2 days ago",
    color: "from-emerald-800 to-green-700",
  },
  {
    title: "Citizen Report Leads to Arrest of Illegal Loggers",
    district: "Moulvibazar",
    time: "3 days ago",
    color: "from-amber-800 to-orange-700",
  },
];

const verificationSteps = [
  { label: "Auto-checked", icon: CheckCircle2, color: "text-green-500" },
  { label: "Editor reviewed", icon: CheckCircle2, color: "text-green-500" },
  { label: "Fact-verified", icon: CheckCircle2, color: "text-green-500" },
  { label: "Published", icon: CheckCircle2, color: "text-green-500" },
];

export default function NewsArticlePage() {
  return (
    <div className="bg-[#F8F9FC] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Article */}
          <article className="lg:col-span-2">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-xs text-gray-400 mb-4">
              <a href="#" className="hover:text-gray-600">Home</a>
              <ChevronRight className="w-3 h-3" />
              <a href="#" className="hover:text-gray-600">Environment</a>
              <ChevronRight className="w-3 h-3" />
              <span className="text-gray-600">Sylhet River Mining</span>
            </div>

            {/* Article Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              {/* Hero Image */}
              <div className="bg-gradient-to-br from-teal-800 to-blue-700 h-64 md:h-80 flex items-center justify-center relative">
                <div className="text-white/10 text-6xl">📸</div>
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(255,255,255,0.1),transparent_60%)]" />
                <div className="absolute bottom-4 left-4 flex items-center gap-2">
                  <Badge className="bg-red-600 text-white text-[10px] font-bold">
                    Photo Evidence — Citizen Submitted
                  </Badge>
                </div>
              </div>

              {/* Article Header */}
              <div className="p-6 md:p-8">
                <div className="flex items-center gap-2 mb-3 flex-wrap">
                  <Badge className="bg-emerald-100 text-emerald-700 text-[10px] font-semibold">
                    {article.category}
                  </Badge>
                  <Badge className="bg-green-100 text-green-700 text-[10px] font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> {article.status}
                  </Badge>
                  <span className="flex items-center gap-1 text-xs text-gray-500">
                    <MapPin className="w-3 h-3" /> {article.district},{" "}
                    {article.upazila}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-gray-500">
                    <Clock className="w-3 h-3" /> {article.date} at {article.time}
                  </span>
                </div>

                <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4 leading-tight">
                  {article.title}
                </h1>

                {/* Reporter Info */}
                <div className="flex items-center justify-between flex-wrap gap-3 pb-4 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                      <Shield className="w-5 h-5 text-gray-400" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-900 flex items-center gap-1.5">
                        {article.reporter}
                        <Shield className="w-3.5 h-3.5 text-green-500" />
                      </p>
                      <p className="text-[11px] text-gray-400">
                        ID: {article.reporterCode} · Verified Contributor
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] border-[#E8A317]/30 text-[#E8A317] bg-[#E8A317]/5">
                      <Star className="w-3 h-3 mr-1 fill-[#E8A317]" /> {article.points} points earned
                    </Badge>
                  </div>
                </div>

                {/* Verification Steps */}
                <div className="flex items-center gap-1 py-4 border-b border-gray-100">
                  {verificationSteps.map((step, i) => (
                    <div key={i} className="flex items-center gap-1">
                      <step.icon className={`w-4 h-4 ${step.color}`} />
                      <span className="text-[11px] text-gray-500 hidden sm:inline">
                        {step.label}
                      </span>
                      {i < verificationSteps.length - 1 && (
                        <ChevronRight className="w-3 h-3 text-gray-300 mx-0.5" />
                      )}
                    </div>
                  ))}
                </div>

                {/* WH Content */}
                <div className="mt-6 space-y-6">
                  {[
                    { key: "What Happened", content: whContent.what, color: "bg-blue-50 border-blue-100 text-blue-800" },
                    { key: "When", content: whContent.when, color: "bg-purple-50 border-purple-100 text-purple-800" },
                    { key: "Where", content: whContent.where, color: "bg-emerald-50 border-emerald-100 text-emerald-800" },
                    { key: "Who is Involved", content: whContent.who, color: "bg-amber-50 border-amber-100 text-amber-800" },
                    { key: "Why It Matters", content: whContent.why, color: "bg-rose-50 border-rose-100 text-rose-800" },
                    { key: "How It's Happening", content: whContent.how, color: "bg-cyan-50 border-cyan-100 text-cyan-800" },
                  ].map(({ key, content, color }) => (
                    <div key={key} className={`rounded-lg border p-4 ${color}`}>
                      <h3 className="font-bold text-sm mb-2 uppercase tracking-wide">
                        {key}
                      </h3>
                      <p className="text-sm leading-relaxed opacity-90">{content}</p>
                    </div>
                  ))}
                </div>

                {/* Action Bar */}
                <div className="flex items-center justify-between mt-6 pt-4 border-t border-gray-100 flex-wrap gap-3">
                  <div className="flex items-center gap-3">
                    <button className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-[#E8A317] bg-gray-50 hover:bg-[#E8A317]/10 px-3 py-1.5 rounded-full transition-colors">
                      <ThumbsUp className="w-4 h-4" /> 142
                    </button>
                    <button className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-blue-600 bg-gray-50 hover:bg-blue-50 px-3 py-1.5 rounded-full transition-colors">
                      <MessageCircle className="w-4 h-4" /> {article.comments}
                    </button>
                    <button className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-red-600 bg-gray-50 hover:bg-red-50 px-3 py-1.5 rounded-full transition-colors">
                      <Flag className="w-4 h-4" /> Report
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-blue-600 bg-gray-50 hover:bg-blue-50 px-3 py-1.5 rounded-full transition-colors">
                      <Bookmark className="w-4 h-4" /> Save
                    </button>
                    <button className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-blue-600 bg-gray-50 hover:bg-blue-50 px-3 py-1.5 rounded-full transition-colors">
                      <Share2 className="w-4 h-4" /> Share
                    </button>
                  </div>
                </div>

                {/* Share Options */}
                <div className="flex items-center gap-2 mt-3">
                  <span className="text-xs text-gray-400">Share on:</span>
                  {[Facebook, Twitter, Send, LinkIcon].map((Icon, i) => (
                    <button
                      key={i}
                      className="w-8 h-8 rounded-full bg-gray-50 hover:bg-gray-100 flex items-center justify-center transition-colors"
                    >
                      <Icon className="w-3.5 h-3.5 text-gray-400" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Comments Section */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 mt-6 p-6">
              <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#E8A317]" /> Comments
                ({article.comments})
              </h3>
              <div className="flex gap-3 mb-4">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center shrink-0">
                  <span className="text-xs text-gray-400">U</span>
                </div>
                <div className="flex-1">
                  <textarea
                    placeholder="Share your thoughts..."
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#E8A317] resize-none h-20 transition-colors"
                  />
                  <div className="flex justify-end mt-1">
                    <button className="bg-[#0B1D3A] hover:bg-[#152C50] text-white px-4 py-1.5 rounded-lg text-xs font-medium transition-colors">
                      Post Comment
                    </button>
                  </div>
                </div>
              </div>
              {[
                {
                  user: "Rahim Ahmed",
                  time: "2 hours ago",
                  text: "This is a serious issue. I live nearby and have seen the river changing shape dramatically. The government must take immediate action before more homes are lost.",
                },
                {
                  user: "Nasreen Begum",
                  time: "1 hour ago",
                  text: "Thank you to the citizen reporter for bringing this to light. Mainstream media has completely ignored this story. This is exactly why this platform matters.",
                },
              ].map((comment, i) => (
                <div key={i} className="flex gap-3 py-3 border-t border-gray-50">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-400 to-purple-400 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-white text-xs font-bold">
                      {comment.user[0]}
                    </span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-900">
                        {comment.user}
                      </span>
                      <span className="text-[11px] text-gray-400">
                        {comment.time}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mt-1 leading-relaxed">
                      {comment.text}
                    </p>
                    <button className="flex items-center gap-1 text-[11px] text-gray-400 hover:text-[#E8A317] mt-1">
                      <ThumbsUp className="w-3 h-3" /> Like
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </article>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Related News */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-4 text-sm">
                Related Stories
              </h3>
              <div className="space-y-3">
                {relatedNews.map((item, i) => (
                  <div
                    key={i}
                    className="flex gap-3 group cursor-pointer pb-3 border-b border-gray-50 last:border-0 last:pb-0"
                  >
                    <div
                      className={`w-16 h-16 rounded-lg bg-gradient-to-br ${item.color} shrink-0 flex items-center justify-center`}
                    >
                      <Camera className="w-6 h-6 text-white/30" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-gray-800 leading-snug group-hover:text-[#0B6BCB] transition-colors">
                        {item.title}
                      </h4>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-gray-400">
                        <span className="flex items-center gap-0.5">
                          <MapPin className="w-2.5 h-2.5" /> {item.district}
                        </span>
                        <span>{item.time}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Verification Notice */}
            <div className="bg-green-50 border border-green-100 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-green-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-green-800 text-sm">
                    Editorial Verification
                  </h4>
                  <p className="text-xs text-green-700 mt-1 leading-relaxed">
                    This report has been verified by our editorial team. Photos
                    were cross-checked, and facts were independently confirmed.
                    GPS data and timestamps have been validated.
                  </p>
                </div>
              </div>
            </div>

            {/* Safety Warning */}
            <div className="bg-amber-50 border border-amber-100 rounded-xl p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-amber-800 text-sm">
                    Reporter Safety
                  </h4>
                  <p className="text-xs text-amber-700 mt-1 leading-relaxed">
                    The identity of the citizen reporter is protected. All
                    submissions are encrypted and anonymized before reaching our
                    editorial team.
                  </p>
                </div>
              </div>
            </div>

            {/* More from District */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-3 text-sm">
                More from Sylhet
              </h3>
              {[
                "Tea Garden Workers Demand Fair Wages",
                "New Highway Construction Faces Delays",
                "Flash Flood Warning Issued for Low-Lying Areas",
              ].map((title, i) => (
                <a
                  key={i}
                  href="#"
                  className="block py-2 border-b border-gray-50 last:border-0 text-sm text-gray-600 hover:text-[#0B6BCB] transition-colors"
                >
                  {title}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

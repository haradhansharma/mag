"use client";

import {
  Star,
  Camera,
  Eye,
  Clock,
  TrendingUp,
  Award,
  Wallet,
  Bell,
  Settings,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle2,
  AlertCircle,
  FileText,
  MapPin,
  Shield,
  BadgeCheck,
  Trophy,
  Target,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

const stats = [
  {
    label: "Total Submissions",
    value: "47",
    icon: Camera,
    change: "+5 this week",
    changeType: "up",
    color: "bg-blue-50 text-blue-600",
  },
  {
    label: "Published",
    value: "38",
    icon: CheckCircle2,
    change: "81% rate",
    changeType: "up",
    color: "bg-green-50 text-green-600",
  },
  {
    label: "Points Earned",
    value: "3,240",
    icon: Star,
    change: "+420 this month",
    changeType: "up",
    color: "bg-amber-50 text-amber-600",
  },
  {
    label: "Total Earnings",
    value: "৳8,100",
    icon: Wallet,
    change: "৳1,050 pending",
    changeType: "neutral",
    color: "bg-purple-50 text-purple-600",
  },
];

const recentSubmissions = [
  {
    title: "Flood relief supplies being diverted by local officials",
    status: "Published",
    statusColor: "bg-green-100 text-green-700",
    points: 85,
    date: "Apr 5, 2026",
    district: "Gaibandha",
    views: "2.1K",
  },
  {
    title: "School building collapse risk reported in Chapainawabganj",
    status: "Under Review",
    statusColor: "bg-yellow-100 text-yellow-700",
    points: "Pending",
    date: "Apr 4, 2026",
    district: "Chapainawabganj",
    views: "-",
  },
  {
    title: "Illegal fishing trawlers operating in protected mangrove area",
    status: "Published",
    statusColor: "bg-green-100 text-green-700",
    points: 75,
    date: "Apr 3, 2026",
    district: "Bagerhat",
    views: "1.8K",
  },
  {
    title: "Community clinic doctor absent for two months",
    status: "Needs Revision",
    statusColor: "bg-orange-100 text-orange-700",
    points: "-",
    date: "Apr 2, 2026",
    district: "Bogra",
    views: "-",
  },
  {
    title: "New irrigation canal benefits 200 farmers in Rangpur",
    status: "Published",
    statusColor: "bg-green-100 text-green-700",
    points: 60,
    date: "Apr 1, 2026",
    district: "Rangpur",
    views: "1.2K",
  },
  {
    title: "Child marriage prevented through community intervention",
    status: "Published",
    statusColor: "bg-green-100 text-green-700",
    points: 90,
    date: "Mar 30, 2026",
    district: "Dinajpur",
    views: "3.5K",
  },
];

const monthlyPoints = [
  { month: "Oct", points: 320 },
  { month: "Nov", points: 480 },
  { month: "Dec", points: 390 },
  { month: "Jan", points: 520 },
  { month: "Feb", points: 610 },
  { month: "Mar", points: 580 },
  { month: "Apr", points: 420 },
];

const achievements = [
  { icon: BadgeCheck, label: "Verified Reporter", unlocked: true },
  { icon: Trophy, label: "50 Reports", unlocked: true },
  { icon: Target, label: "90%+ Accuracy", unlocked: true },
  { icon: Zap, label: "Breaking News Pro", unlocked: false },
  { icon: Award, label: "100 Reports", unlocked: false },
];

export default function ContributorDashboard() {
  return (
    <div className="bg-[#F8F9FC] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Welcome Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 gap-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[#0B1D3A] to-[#152C50] rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-[#E8A317]" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">
                Welcome back, Reporter!
              </h1>
              <p className="text-sm text-gray-500 flex items-center gap-1">
                <BadgeCheck className="w-3.5 h-3.5 text-green-500" />
                Verified Contributor · Level 3 · Member since Oct 2025
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 bg-white border border-gray-200 px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50 transition-colors">
              <Bell className="w-4 h-4" /> Notifications
              <span className="w-4 h-4 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center">
                3
              </span>
            </button>
            <button className="flex items-center gap-1.5 bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] px-4 py-2 rounded-lg text-sm font-semibold transition-colors">
              <Camera className="w-4 h-4" /> Submit News
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {stats.map(({ label, value, icon: Icon, change, changeType, color }) => (
            <div
              key={label}
              className="bg-white rounded-xl shadow-sm border border-gray-100 p-4"
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-9 h-9 rounded-lg ${color} flex items-center justify-center`}>
                  <Icon className="w-4.5 h-4.5" />
                </div>
                {changeType === "up" ? (
                  <ArrowUpRight className="w-4 h-4 text-green-500" />
                ) : changeType === "down" ? (
                  <ArrowDownRight className="w-4 h-4 text-red-500" />
                ) : null}
              </div>
              <p className="text-2xl font-bold text-gray-900">{value}</p>
              <p className="text-xs text-gray-500 mt-0.5">{label}</p>
              <p className={`text-[11px] mt-1 ${changeType === "up" ? "text-green-600" : "text-gray-400"}`}>
                {change}
              </p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Recent Submissions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b border-gray-100">
                <h2 className="font-bold text-gray-900 flex items-center gap-2 text-sm">
                  <FileText className="w-4 h-4 text-[#E8A317]" /> Recent
                  Submissions
                </h2>
                <a
                  href="#"
                  className="text-xs text-[#0B6BCB] hover:text-[#0B5AAF] font-medium flex items-center gap-1"
                >
                  View All <ChevronRight className="w-3 h-3" />
                </a>
              </div>
              <div className="divide-y divide-gray-50">
                {recentSubmissions.map((sub, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 p-4 hover:bg-gray-50/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-medium text-gray-900 truncate">
                        {sub.title}
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="flex items-center gap-0.5 text-[11px] text-gray-400">
                          <MapPin className="w-2.5 h-2.5" /> {sub.district}
                        </span>
                        <span className="text-[11px] text-gray-400">
                          {sub.date}
                        </span>
                        {sub.views !== "-" && (
                          <span className="flex items-center gap-0.5 text-[11px] text-gray-400">
                            <Eye className="w-2.5 h-2.5" /> {sub.views}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span
                        className={`inline-block text-[10px] font-semibold px-2 py-0.5 rounded-full ${sub.statusColor}`}
                      >
                        {sub.status}
                      </span>
                      {sub.points !== "Pending" && sub.points !== "-" && (
                        <p className="text-xs text-[#E8A317] font-semibold mt-1 flex items-center gap-0.5 justify-end">
                          <Star className="w-3 h-3 fill-[#E8A317]" />{" "}
                          {sub.points} pts
                        </p>
                      )}
                      {sub.status === "Needs Revision" && (
                        <p className="text-[11px] text-orange-600 mt-1">
                          Editor feedback
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Points History */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b border-gray-100">
                <h2 className="font-bold text-gray-900 flex items-center gap-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-[#E8A317]" /> Monthly
                  Points
                </h2>
                <select className="text-xs bg-gray-50 border border-gray-200 rounded-lg px-2 py-1 text-gray-600">
                  <option>Last 7 months</option>
                  <option>Last 12 months</option>
                </select>
              </div>
              <div className="p-4">
                <div className="flex items-end gap-2 h-40">
                  {monthlyPoints.map(({ month, points }, i) => {
                    const maxPoints = Math.max(...monthlyPoints.map((p) => p.points));
                    const height = (points / maxPoints) * 100;
                    const isLast = i === monthlyPoints.length - 1;
                    return (
                      <div key={month} className="flex-1 flex flex-col items-center gap-1">
                        <span className="text-[10px] text-gray-500 font-medium">
                          {points}
                        </span>
                        <div
                          className={`w-full rounded-t-md transition-all ${
                            isLast
                              ? "bg-[#E8A317]"
                              : "bg-[#0B1D3A]/20 hover:bg-[#0B1D3A]/30"
                          }`}
                          style={{ height: `${height}%` }}
                        />
                        <span className="text-[10px] text-gray-400">{month}</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Payout Card */}
            <div className="bg-gradient-to-br from-[#0B1D3A] to-[#152C50] rounded-xl p-5 text-white">
              <div className="flex items-center gap-2 mb-3">
                <Wallet className="w-5 h-5 text-[#E8A317]" />
                <h3 className="font-bold text-sm">Earnings Summary</h3>
              </div>
              <p className="text-3xl font-bold mb-1">৳8,100</p>
              <p className="text-xs text-gray-400 mb-4">Total earned</p>
              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Available</span>
                  <span className="font-semibold text-green-400">৳7,050</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Pending</span>
                  <span className="font-semibold text-yellow-400">৳1,050</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Point Rate</span>
                  <span className="font-semibold">৳2.50 / pt</span>
                </div>
              </div>
              <button className="w-full bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] font-semibold py-2.5 rounded-lg text-sm transition-colors">
                Request Payout (৳7,050)
              </button>
            </div>

            {/* Achievements */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-3 text-sm flex items-center gap-2">
                <Award className="w-4 h-4 text-[#E8A317]" /> Achievements
              </h3>
              <div className="space-y-2">
                {achievements.map(({ icon: Icon, label, unlocked }) => (
                  <div
                    key={label}
                    className={`flex items-center gap-3 p-2 rounded-lg ${
                      unlocked ? "bg-amber-50" : "bg-gray-50 opacity-50"
                    }`}
                  >
                    <Icon
                      className={`w-5 h-5 ${
                        unlocked ? "text-[#E8A317]" : "text-gray-300"
                      }`}
                    />
                    <span
                      className={`text-sm font-medium ${
                        unlocked ? "text-gray-900" : "text-gray-400"
                      }`}
                    >
                      {label}
                    </span>
                    {unlocked && (
                      <CheckCircle2 className="w-4 h-4 text-green-500 ml-auto" />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Level Progress */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
              <h3 className="font-bold text-gray-900 mb-3 text-sm">
                Reporter Level
              </h3>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-gradient-to-br from-[#E8A317] to-[#D4940F] rounded-xl flex items-center justify-center text-white font-bold">
                  3
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-900">
                    Senior Reporter
                  </p>
                  <p className="text-[11px] text-gray-400">
                    3,240 / 5,000 points to Level 4
                  </p>
                </div>
              </div>
              <Progress value={64.8} className="h-2" />
              <p className="text-[11px] text-gray-400 mt-2">
                Level 4 unlocks: Higher point multiplier + Priority editorial
                review
              </p>
            </div>

            {/* Quick Tips */}
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
              <h3 className="font-bold text-blue-800 text-sm mb-2">
                Tips to Earn More Points
              </h3>
              <ul className="space-y-1.5 text-xs text-blue-700">
                <li className="flex items-start gap-1.5">
                  <ChevronRight className="w-3 h-3 shrink-0 mt-0.5" />
                  Breaking news with photos: 100+ points
                </li>
                <li className="flex items-start gap-1.5">
                  <ChevronRight className="w-3 h-3 shrink-0 mt-0.5" />
                  Crime reports with evidence: 75-95 points
                </li>
                <li className="flex items-start gap-1.5">
                  <ChevronRight className="w-3 h-3 shrink-0 mt-0.5" />
                  Follow-up on published stories: bonus 20 points
                </li>
                <li className="flex items-start gap-1.5">
                  <ChevronRight className="w-3 h-3 shrink-0 mt-0.5" />
                  Maintain 80%+ accuracy for level bonuses
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

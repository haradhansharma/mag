"use client";

import { useState } from "react";
import {
  Camera,
  Upload,
  MapPin,
  Clock,
  Shield,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  X,
  Image as ImageIcon,
  Video,
  FileText,
  Info,
  Lock,
  Star,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";

const steps = [
  { label: "Category", icon: FileText },
  { label: "WH Details", icon: FileText },
  { label: "Photos", icon: Camera },
  { label: "Review", icon: CheckCircle2 },
];

const categories = [
  "Crime & Justice",
  "Politics",
  "Education",
  "Health",
  "Agriculture",
  "Environment",
  "Human Rights",
  "Development",
  "Technology",
  "Sports",
  "Culture",
  "Accident",
  "Corruption",
  "Other",
];

const uploadedPhotos = [
  { name: "incident_scene_1.jpg", size: "2.4 MB", status: "uploaded" },
  { name: "damage_close_up.jpg", size: "1.8 MB", status: "uploaded" },
  { name: "location_wide.jpg", size: "3.1 MB", status: "uploading" },
];

export default function NewsSubmissionPage() {
  const [currentStep, setCurrentStep] = useState(0);
  const [priority, setPriority] = useState("routine");

  return (
    <div className="bg-[#F8F9FC] min-h-screen">
      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 bg-[#E8A317] rounded-2xl flex items-center justify-center mx-auto mb-3">
            <Camera className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">
            Submit a News Report
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Share what&apos;s happening in your area. Your identity is always
            protected.
          </p>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center mb-8">
          {steps.map((step, i) => (
            <div key={i} className="flex items-center">
              <div
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  i === currentStep
                    ? "bg-[#0B1D3A] text-white"
                    : i < currentStep
                    ? "bg-green-100 text-green-700"
                    : "bg-gray-100 text-gray-400"
                }`}
              >
                {i < currentStep ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <step.icon className="w-4 h-4" />
                )}
                <span className="hidden sm:inline">{step.label}</span>
              </div>
              {i < steps.length - 1 && (
                <ChevronRight className="w-4 h-4 text-gray-300 mx-1" />
              )}
            </div>
          ))}
        </div>

        {/* Security Notice */}
        <div className="bg-blue-50 border border-blue-100 rounded-xl p-3 mb-6 flex items-start gap-3">
          <Lock className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <p className="text-xs text-blue-700 leading-relaxed">
            <strong>Secure Submission:</strong> All reports are encrypted
            end-to-end. Your identity is never revealed. Our editorial team only
            sees the content, not your personal details.
          </p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          {/* Step 1: Category & Basic Info */}
          {currentStep === 0 && (
            <div className="space-y-5">
              <h2 className="text-lg font-bold text-gray-900">
                Basic Information
              </h2>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      className="text-left px-3 py-2 text-sm border border-gray-200 rounded-lg hover:border-[#E8A317] hover:bg-[#E8A317]/5 transition-colors text-gray-600"
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Priority */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Priority Level
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    {
                      value: "routine",
                      label: "Routine",
                      desc: "Regular event",
                      color: "border-gray-300 text-gray-600",
                    },
                    {
                      value: "breaking",
                      label: "Breaking",
                      desc: "Happening now",
                      color: "border-red-300 text-red-600 bg-red-50",
                    },
                    {
                      value: "crime",
                      label: "Crime",
                      desc: "Illegal activity",
                      color: "border-orange-300 text-orange-600 bg-orange-50",
                    },
                    {
                      value: "followup",
                      label: "Follow-up",
                      desc: "Previous story",
                      color: "border-blue-300 text-blue-600 bg-blue-50",
                    },
                  ].map((p) => (
                    <button
                      key={p.value}
                      onClick={() => setPriority(p.value)}
                      className={`px-3 py-2.5 rounded-lg border text-center transition-all ${
                        priority === p.value
                          ? `${p.color} ring-2 ring-offset-1 ring-current`
                          : "border-gray-200 text-gray-500 hover:border-gray-300"
                      }`}
                    >
                      <span className="block text-sm font-semibold">
                        {p.label}
                      </span>
                      <span className="block text-[10px] mt-0.5">{p.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* District */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  District <span className="text-red-500">*</span>
                </label>
                <select className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 text-sm text-gray-700 outline-none focus:border-[#E8A317]">
                  <option value="">Select your district</option>
                  <option>Dhaka</option>
                  <option>Chittagong</option>
                  <option>Sylhet</option>
                  <option>Rajshahi</option>
                  <option>Khulna</option>
                  <option>Barisal</option>
                  <option>Rangpur</option>
                  <option>Mymensingh</option>
                </select>
              </div>

              {/* Upazila */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Upazila / Thana
                </label>
                <input
                  type="text"
                  placeholder="Enter upazila or thana name"
                  className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#E8A317]"
                />
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Date of Incident
                  </label>
                  <input
                    type="date"
                    defaultValue="2026-04-05"
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#E8A317]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Time of Incident
                  </label>
                  <input
                    type="time"
                    defaultValue="16:30"
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#E8A317]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 2: WH Questions */}
          {currentStep === 1 && (
            <div className="space-y-5">
              <h2 className="text-lg font-bold text-gray-900">
                Report Details (WH Questions)
              </h2>
              <p className="text-xs text-gray-500">
                Answer each question with as much detail as possible. This helps
                our editors verify and publish your report faster.
              </p>

              {[
                {
                  question: "What happened?",
                  placeholder:
                    "Describe the event in detail. What exactly occurred? Be specific and factual.",
                  hint: "Avoid opinions. Stick to what you saw or confirmed.",
                  color: "bg-blue-50 text-blue-700",
                  required: true,
                },
                {
                  question: "When did it happen?",
                  placeholder:
                    "Exact date and time if possible. If approximate, mention the time range.",
                  hint: "e.g., 'Around 10 PM on April 4th' or 'Between April 2-4'",
                  color: "bg-purple-50 text-purple-700",
                  required: true,
                },
                {
                  question: "Where exactly?",
                  placeholder:
                    "Be as specific as possible. Mention landmarks, village names, road names, etc.",
                  hint: "GPS will be auto-captured from your photos if location services are enabled.",
                  color: "bg-emerald-50 text-emerald-700",
                  required: true,
                },
                {
                  question: "Who is involved?",
                  placeholder:
                    "Names, descriptions, or identifying information of people involved.",
                  hint: "If unknown, describe physical appearance or roles.",
                  color: "bg-amber-50 text-amber-700",
                  required: false,
                },
                {
                  question: "Why does this matter?",
                  placeholder:
                    "Why is this newsworthy? What's the impact on the community?",
                  hint: "Think about who is affected and why readers should care.",
                  color: "bg-rose-50 text-rose-700",
                  required: false,
                },
                {
                  question: "How is it happening?",
                  placeholder:
                    "Describe the process, methods, or circumstances in detail.",
                  hint: "Include any background information that provides context.",
                  color: "bg-cyan-50 text-cyan-700",
                  required: false,
                },
              ].map((q, i) => (
                <div key={i}>
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${q.color}`}
                    >
                      {q.question.split(" ")[0].toUpperCase()}
                    </span>
                    <label className="text-sm font-medium text-gray-700">
                      {q.question}
                      {q.required && <span className="text-red-500"> *</span>}
                    </label>
                  </div>
                  <textarea
                    placeholder={q.placeholder}
                    rows={3}
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-[#E8A317] resize-none transition-colors"
                  />
                  <p className="text-[11px] text-gray-400 mt-1 flex items-center gap-1">
                    <Info className="w-3 h-3" /> {q.hint}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Step 3: Photos */}
          {currentStep === 2 && (
            <div className="space-y-5">
              <h2 className="text-lg font-bold text-gray-900">
                Photo & Media Evidence
              </h2>
              <p className="text-xs text-gray-500">
                Upload photos or videos from the scene. Clear, well-lit photos
                help your report get published faster and earn more points.
              </p>

              {/* Upload Zone */}
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-[#E8A317]/50 hover:bg-[#E8A317]/5 transition-colors cursor-pointer">
                <Upload className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                <p className="text-sm font-medium text-gray-600">
                  Drag & drop photos here
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  or click to browse. JPG, PNG up to 10MB each. Max 5 files.
                </p>
                <button className="mt-3 bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] px-4 py-2 rounded-lg text-sm font-semibold transition-colors">
                  Choose Files
                </button>
              </div>

              {/* Uploaded Files */}
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-700">
                  Uploaded Files ({uploadedPhotos.length}/5)
                </p>
                {uploadedPhotos.map((file, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3 bg-gray-50 rounded-lg p-3 border border-gray-100"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg flex items-center justify-center shrink-0">
                      <ImageIcon className="w-6 h-6 text-gray-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-700 truncate">
                        {file.name}
                      </p>
                      <p className="text-[11px] text-gray-400">{file.size}</p>
                      {file.status === "uploading" && (
                        <Progress value={65} className="h-1 mt-1" />
                      )}
                    </div>
                    {file.status === "uploaded" ? (
                      <CheckCircle2 className="w-5 h-5 text-green-500" />
                    ) : (
                      <span className="text-[11px] text-gray-400">65%</span>
                    )}
                    <button className="text-gray-400 hover:text-red-500">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Tips */}
              <div className="bg-amber-50 border border-amber-100 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <Star className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-xs text-amber-700">
                    <p className="font-semibold mb-1">
                      Photo Tips for Maximum Points
                    </p>
                    <ul className="space-y-0.5 list-disc ml-3">
                      <li>Include wide shot + close-up details</li>
                      <li>Capture visible faces or identifying features</li>
                      <li>Make sure location landmarks are visible</li>
                      <li>Enable GPS/location on your phone camera</li>
                      <li>Take multiple angles of the same scene</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Review & Submit */}
          {currentStep === 3 && (
            <div className="space-y-5">
              <h2 className="text-lg font-bold text-gray-900">
                Review & Submit
              </h2>

              {/* Summary */}
              <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">Category</span>
                  <Badge variant="secondary" className="text-xs">
                    Environment
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">Priority</span>
                  <Badge className="bg-orange-100 text-orange-700 text-xs">
                    Crime Report
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">District</span>
                  <span className="text-sm text-gray-900 font-medium">
                    Sylhet
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">Date/Time</span>
                  <span className="text-sm text-gray-900 font-medium">
                    April 5, 2026 at 4:30 PM
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">Photos</span>
                  <span className="text-sm text-gray-900 font-medium">
                    3 images uploaded
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">
                    Estimated Points
                  </span>
                  <span className="text-sm text-[#E8A317] font-bold flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-[#E8A317]" /> 75-90
                    points
                  </span>
                </div>
              </div>

              {/* Content Preview */}
              <div>
                <h3 className="text-sm font-semibold text-gray-700 mb-2">
                  Report Preview
                </h3>
                <div className="space-y-2 text-sm">
                  {[
                    { label: "What", color: "bg-blue-50 text-blue-800" },
                    { label: "When", color: "bg-purple-50 text-purple-800" },
                    { label: "Where", color: "bg-emerald-50 text-emerald-800" },
                  ].map(({ label, color }) => (
                    <div
                      key={label}
                      className={`${color} rounded-lg p-3 border`}
                    >
                      <span className="font-bold text-[10px] uppercase tracking-wide">
                        {label}
                      </span>
                      <p className="mt-1 text-xs leading-relaxed opacity-80">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        Sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Safety Agreement */}
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    className="mt-1 w-4 h-4 rounded border-gray-300"
                  />
                  <span className="text-xs text-blue-700 leading-relaxed">
                    I confirm that this report is truthful and based on what I
                    personally observed or verified. I understand that false
                    reports may result in account suspension. I agree to the{" "}
                    <a href="#" className="underline font-medium">
                      Contributor Agreement
                    </a>{" "}
                    and{" "}
                    <a href="#" className="underline font-medium">
                      Safety Guidelines
                    </a>
                    .
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-100">
            <button
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              className={`flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg transition-colors ${
                currentStep === 0
                  ? "opacity-0 pointer-events-none"
                  : "hover:bg-gray-100"
              }`}
            >
              <ChevronLeft className="w-4 h-4" /> Previous
            </button>

            <div className="flex items-center gap-2">
              <button className="text-sm text-gray-500 hover:text-gray-700 px-4 py-2 rounded-lg transition-colors">
                Save Draft
              </button>
              {currentStep < steps.length - 1 ? (
                <button
                  onClick={() =>
                    setCurrentStep(
                      Math.min(steps.length - 1, currentStep + 1)
                    )
                  }
                  className="bg-[#E8A317] hover:bg-[#D4940F] text-[#0B1D3A] px-6 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2"
                >
                  Next <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg text-sm font-semibold transition-colors flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Submit Report
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Auto-save notice */}
        <p className="text-center text-[11px] text-gray-400 mt-4 flex items-center justify-center gap-1">
          <Shield className="w-3 h-3" /> Draft auto-saved · Your identity is
          encrypted and never revealed
        </p>
      </div>
    </div>
  );
}

"use client";

import { useState } from "react";
import Navbar from "@/components/mockup/Navbar";
import Footer from "@/components/mockup/Footer";
import HomePage from "@/components/mockup/HomePage";
import NewsArticlePage from "@/components/mockup/NewsArticlePage";
import NewsSubmissionPage from "@/components/mockup/NewsSubmissionPage";
import ContributorDashboard from "@/components/mockup/ContributorDashboard";
import TrainingLMS from "@/components/mockup/TrainingLMS";
import LoginPage from "@/components/mockup/LoginPage";
import AdminEditorialPage from "@/components/mockup/AdminEditorialPage";
import {
  Home,
  FileText,
  Camera,
  LayoutDashboard,
  GraduationCap,
  LogIn,
  Shield,
  ChevronDown,
  Eye,
  EyeOff,
  X,
} from "lucide-react";

type PageKey =
  | "home"
  | "article"
  | "submit"
  | "dashboard"
  | "training"
  | "login"
  | "admin";

const pages: { key: PageKey; label: string; icon: React.ElementType; group: string }[] = [
  { key: "home", label: "Homepage", icon: Home, group: "Public" },
  { key: "article", label: "News Article", icon: FileText, group: "Public" },
  { key: "login", label: "Login / Register", icon: LogIn, group: "Public" },
  { key: "submit", label: "News Submission", icon: Camera, group: "Contributor" },
  { key: "dashboard", label: "Dashboard", icon: LayoutDashboard, group: "Contributor" },
  { key: "training", label: "Training Course", icon: GraduationCap, group: "Contributor" },
  { key: "admin", label: "Admin Editorial", icon: Shield, group: "Admin" },
];

export default function MockupShowcase() {
  const [activePage, setActivePage] = useState<PageKey>("home");
  const [showNav, setShowNav] = useState(true);

  const currentPage = pages.find((p) => p.key === activePage);
  const needsNavbar = !["login", "admin"].includes(activePage);
  const needsFooter = !["login", "admin"].includes(activePage);

  return (
    <div className="relative">
      {/* Floating Page Selector */}
      <div className="fixed top-3 right-3 z-[100]">
        <div className="bg-[#0B1D3A] rounded-xl shadow-2xl border border-white/10 overflow-hidden min-w-[220px]">
          {/* Selector Header */}
          <div className="px-4 py-2.5 border-b border-white/10 flex items-center justify-between">
            <span className="text-white text-xs font-semibold flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-[#E8A317]" /> Page Preview
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setShowNav(!showNav)}
                className={`text-[10px] px-2 py-0.5 rounded font-medium transition-colors ${
                  showNav
                    ? "bg-green-500/20 text-green-400"
                    : "bg-gray-500/20 text-gray-400"
                }`}
                title={showNav ? "Hide navbar/footer" : "Show navbar/footer"}
              >
                {showNav ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
              </button>
            </div>
          </div>

          {/* Page Buttons */}
          <div className="p-1.5 space-y-0.5 max-h-[400px] overflow-y-auto">
            {["Public", "Contributor", "Admin"].map((group) => (
              <div key={group}>
                <p className="text-[9px] text-gray-500 font-semibold uppercase tracking-wider px-2 py-1">
                  {group}
                </p>
                {pages
                  .filter((p) => p.group === group)
                  .map(({ key, label, icon: Icon }) => (
                    <button
                      key={key}
                      onClick={() => setActivePage(key)}
                      className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
                        activePage === key
                          ? "bg-[#E8A317] text-[#0B1D3A] font-semibold"
                          : "text-gray-300 hover:text-white hover:bg-white/10"
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {label}
                    </button>
                  ))}
              </div>
            ))}
          </div>

          {/* Current Page Label */}
          <div className="px-4 py-2 border-t border-white/10">
            <p className="text-[10px] text-gray-500">
              Viewing: <span className="text-[#E8A317] font-medium">{currentPage?.label}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Render Active Page */}
      {activePage === "login" && <LoginPage />}

      {activePage === "admin" && <AdminEditorialPage />}

      {!["login", "admin"].includes(activePage) && (
        <div>
          {showNav && <Navbar currentPage={activePage} />}
          <main>
            {activePage === "home" && <HomePage />}
            {activePage === "article" && <NewsArticlePage />}
            {activePage === "submit" && <NewsSubmissionPage />}
            {activePage === "dashboard" && <ContributorDashboard />}
            {activePage === "training" && <TrainingLMS />}
          </main>
          {showNav && <Footer />}
        </div>
      )}
    </div>
  );
}

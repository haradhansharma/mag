#!/usr/bin/env python3
"""
Generate Frontend Web Plan PDF for Citizen Journalism Platform.
Uses reportlab for professional PDF output.
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch, mm
from reportlab.lib.colors import HexColor, black, white, Color
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, HRFlowable, ListFlowable, ListItem,
    Frame, PageTemplate, BaseDocTemplate, NextPageTemplate
)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
import os

# ─── COLOR PALETTE ───
NAVY = HexColor('#1B2A4A')
DARK_BLUE = HexColor('#1E3A5F')
MED_BLUE = HexColor('#2E6B9E')
LIGHT_BLUE = HexColor('#4A90D9')
ACCENT_WARM = HexColor('#E8A838')
ACCENT_ORANGE = HexColor('#D4762C')
BG_LIGHT = HexColor('#F5F7FA')
TEXT_DARK = HexColor('#1A1A2E')
TEXT_MEDIUM = HexColor('#4A4A5A')
TEXT_LIGHT = HexColor('#6B7280')
SUCCESS = HexColor('#10B981')
WARNING = HexColor('#F59E0B')
ERROR = HexColor('#EF4444')
INFO = HexColor('#3B82F6')
BORDER = HexColor('#E5E7EB')
CODE_BG = HexColor('#1E293B')
CODE_TEXT = HexColor('#E2E8F0')

PAGE_W, PAGE_H = letter
MARGIN = 0.85 * inch

# ─── STYLES ───
styles = getSampleStyleSheet()

def make_styles():
    s = {}
    s['body'] = ParagraphStyle(
        'BodyCustom', parent=styles['Normal'],
        fontName='Helvetica', fontSize=10, leading=14.5,
        textColor=TEXT_DARK, alignment=TA_JUSTIFY,
        spaceAfter=6, spaceBefore=2,
    )
    s['body_small'] = ParagraphStyle(
        'BodySmall', parent=s['body'],
        fontSize=9, leading=13,
    )
    s['h1'] = ParagraphStyle(
        'H1Custom', parent=styles['Heading1'],
        fontName='Helvetica-Bold', fontSize=22, leading=28,
        textColor=NAVY, spaceBefore=24, spaceAfter=12,
        borderWidth=0, borderPadding=0,
    )
    s['h2'] = ParagraphStyle(
        'H2Custom', parent=styles['Heading2'],
        fontName='Helvetica-Bold', fontSize=16, leading=21,
        textColor=DARK_BLUE, spaceBefore=18, spaceAfter=8,
    )
    s['h3'] = ParagraphStyle(
        'H3Custom', parent=styles['Heading3'],
        fontName='Helvetica-Bold', fontSize=13, leading=17,
        textColor=MED_BLUE, spaceBefore=14, spaceAfter=6,
    )
    s['h4'] = ParagraphStyle(
        'H4Custom', parent=styles['Heading4'],
        fontName='Helvetica-Bold', fontSize=11, leading=15,
        textColor=DARK_BLUE, spaceBefore=10, spaceAfter=4,
    )
    s['code'] = ParagraphStyle(
        'CodeCustom', parent=styles['Code'],
        fontName='Courier', fontSize=7.5, leading=10.5,
        textColor=CODE_TEXT, backColor=CODE_BG,
        borderWidth=1, borderColor=HexColor('#334155'),
        borderPadding=6, spaceBefore=6, spaceAfter=6,
        leftIndent=12, rightIndent=12,
    )
    s['code_inline'] = ParagraphStyle(
        'CodeInline', parent=s['body'],
        fontName='Courier', fontSize=8.5, leading=12,
        textColor=DARK_BLUE, backColor=HexColor('#EFF6FF'),
        borderWidth=0.5, borderColor=LIGHT_BLUE,
        borderPadding=2, leftIndent=2, rightIndent=2,
    )
    s['bullet'] = ParagraphStyle(
        'BulletCustom', parent=s['body'],
        leftIndent=20, bulletIndent=8,
        spaceBefore=2, spaceAfter=2,
    )
    s['sub_bullet'] = ParagraphStyle(
        'SubBullet', parent=s['bullet'],
        leftIndent=36, bulletIndent=24,
        fontSize=9.5, leading=13.5,
    )
    s['toc_h1'] = ParagraphStyle(
        'TOC_H1', parent=styles['Normal'],
        fontName='Helvetica-Bold', fontSize=13, leading=20,
        textColor=NAVY, leftIndent=0,
    )
    s['toc_h2'] = ParagraphStyle(
        'TOC_H2', parent=styles['Normal'],
        fontName='Helvetica', fontSize=11, leading=17,
        textColor=TEXT_DARK, leftIndent=20,
    )
    s['table_header'] = ParagraphStyle(
        'TableHeader', parent=styles['Normal'],
        fontName='Helvetica-Bold', fontSize=8.5, leading=11,
        textColor=white, alignment=TA_CENTER,
    )
    s['table_cell'] = ParagraphStyle(
        'TableCell', parent=styles['Normal'],
        fontName='Helvetica', fontSize=8, leading=10.5,
        textColor=TEXT_DARK,
    )
    s['table_cell_center'] = ParagraphStyle(
        'TableCellCenter', parent=s['table_cell'],
        alignment=TA_CENTER,
    )
    s['table_cell_small'] = ParagraphStyle(
        'TableCellSmall', parent=s['table_cell'],
        fontSize=7.5, leading=10,
    )
    s['cover_title'] = ParagraphStyle(
        'CoverTitle', fontName='Helvetica-Bold', fontSize=36,
        leading=44, textColor=white, alignment=TA_CENTER,
    )
    s['cover_sub'] = ParagraphStyle(
        'CoverSub', fontName='Helvetica', fontSize=16,
        leading=22, textColor=HexColor('#CBD5E1'), alignment=TA_CENTER,
    )
    s['cover_detail'] = ParagraphStyle(
        'CoverDetail', fontName='Helvetica', fontSize=12,
        leading=17, textColor=HexColor('#94A3B8'), alignment=TA_CENTER,
    )
    s['footer'] = ParagraphStyle(
        'Footer', fontName='Helvetica', fontSize=8,
        leading=10, textColor=TEXT_LIGHT, alignment=TA_CENTER,
    )
    s['note'] = ParagraphStyle(
        'Note', parent=s['body'],
        fontName='Helvetica-Oblique', fontSize=9, leading=13,
        textColor=TEXT_MEDIUM, backColor=HexColor('#FFF7ED'),
        borderWidth=1, borderColor=ACCENT_WARM,
        borderPadding=8, leftIndent=12, rightIndent=12,
        spaceBefore=8, spaceAfter=8,
    )
    return s

S = make_styles()

# ─── HELPER FUNCTIONS ───
def heading1(text):
    return Paragraph(text, S['h1'])

def heading2(text):
    return Paragraph(text, S['h2'])

def heading3(text):
    return Paragraph(text, S['h3'])

def heading4(text):
    return Paragraph(text, S['h4'])

def body(text):
    return Paragraph(text, S['body'])

def body_small(text):
    return Paragraph(text, S['body_small'])

def bullet(text):
    return Paragraph(f"\u2022  {text}", S['bullet'])

def sub_bullet(text):
    return Paragraph(f"\u2022  {text}", S['sub_bullet'])

def code_block(text):
    # Escape XML characters
    text = text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    text = text.replace('\n', '<br/>')
    # Replace leading spaces with &nbsp;
    lines = text.split('<br/>')
    formatted_lines = []
    for line in lines:
        stripped = line.lstrip(' ')
        indent = len(line) - len(stripped)
        formatted_lines.append('&nbsp;' * indent + stripped)
    text = '<br/>'.join(formatted_lines)
    return Paragraph(text, S['code'])

def note(text):
    return Paragraph(text, S['note'])

def spacer(h=6):
    return Spacer(1, h)

def hr():
    return HRFlowable(width="100%", thickness=1, color=BORDER, spaceBefore=6, spaceAfter=6)

def make_table(headers, rows, col_widths=None):
    """Create a styled table."""
    header_paras = [Paragraph(h, S['table_header']) for h in headers]
    table_data = [header_paras]
    for row in rows:
        table_data.append([Paragraph(str(c), S['table_cell_small']) if not isinstance(c, Paragraph) else c for c in row])
    
    if col_widths is None:
        available = PAGE_W - 2 * MARGIN
        col_widths = [available / len(headers)] * len(headers)
    
    t = Table(table_data, colWidths=col_widths, repeatRows=1)
    style_cmds = [
        ('BACKGROUND', (0, 0), (-1, 0), NAVY),
        ('TEXTCOLOR', (0, 0), (-1, 0), white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 8.5),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
        ('TOPPADDING', (0, 0), (-1, 0), 8),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
        ('TOPPADDING', (0, 1), (-1, -1), 6),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('GRID', (0, 0), (-1, -1), 0.5, BORDER),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, BG_LIGHT]),
    ]
    t.setStyle(TableStyle(style_cmds))
    return t


# ─── PAGE NUMBERING ───
class NumberedCanvas:
    def __init__(self, doc):
        self.doc = doc

def add_page_number(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica', 8)
    canvas.setFillColor(TEXT_LIGHT)
    page_num = canvas.getPageNumber()
    text = f"Frontend Web Plan  |  Citizen Journalism Platform  |  Page {page_num}"
    canvas.drawCentredString(PAGE_W / 2, 0.45 * inch, text)
    # Top line
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(MARGIN, PAGE_H - 0.55 * inch, PAGE_W - MARGIN, PAGE_H - 0.55 * inch)
    canvas.restoreState()


# ─── BUILD DOCUMENT ───
def build_pdf(filepath):
    doc = SimpleDocTemplate(
        filepath,
        pagesize=letter,
        leftMargin=MARGIN, rightMargin=MARGIN,
        topMargin=0.75 * inch, bottomMargin=0.7 * inch,
        title="Frontend Web Plan - Citizen Journalism Platform",
        author="Platform Architecture Team",
    )
    story = []
    avail_w = PAGE_W - 2 * MARGIN

    # ══════════════════════════════════════════════
    # COVER PAGE
    # ══════════════════════════════════════════════
    # Full-page colored background via a table
    cover_content = []
    cover_content.append(Spacer(1, 1.2 * inch))
    cover_content.append(Paragraph("FRONTEND WEB PLAN", S['cover_title']))
    cover_content.append(Spacer(1, 0.12 * inch))
    cover_content.append(HRFlowable(width="40%", thickness=3, color=ACCENT_WARM, spaceBefore=0, spaceAfter=0))
    cover_content.append(Spacer(1, 0.2 * inch))
    cover_content.append(Paragraph("Citizen Journalism Platform", S['cover_sub']))
    cover_content.append(Spacer(1, 0.5 * inch))
    cover_content.append(Paragraph("Architecture  |  Design System  |  Component Library  |  Roadmap", S['cover_detail']))
    cover_content.append(Spacer(1, 0.25 * inch))
    cover_content.append(Paragraph("Tech Stack: Astro 5.x + Vue 3 + Tailwind CSS 4.x", S['cover_detail']))
    cover_content.append(Spacer(1, 1.5 * inch))
    cover_content.append(Paragraph("Version 1.0  |  June 2025", S['cover_detail']))
    cover_content.append(Paragraph("Confidential  |  For Internal Development Use", S['cover_detail']))

    # Create cover as a full-page table
    cover_table = Table([[cover_content]], colWidths=[avail_w], rowHeights=[670])
    cover_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), NAVY),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('LEFTPADDING', (0, 0), (-1, -1), 0),
        ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ('TOPPADDING', (0, 0), (-1, -1), 0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ('BOX', (0, 0), (-1, -1), 0, NAVY),
    ]))
    story.append(cover_table)
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # TABLE OF CONTENTS
    # ══════════════════════════════════════════════
    story.append(heading1("Table of Contents"))
    story.append(hr())
    story.append(spacer(4))
    
    toc_items = [
        ("1.", "Architecture Overview", ""),
        ("2.", "Page Inventory & Rendering Strategy", ""),
        ("3.", "Design System & UI Specifications", ""),
        ("4.", "Key Page Designs", ""),
        ("", "4.1  Homepage", ""),
        ("", "4.2  News Article Page", ""),
        ("", "4.3  News Submission Form", ""),
        ("", "4.4  Contributor Dashboard", ""),
        ("", "4.5  Training Course / LMS", ""),
        ("5.", "Component Hierarchy & Data Flow", ""),
        ("6.", "Performance Optimization", ""),
        ("7.", "Security on Frontend", ""),
        ("8.", "Deployment & Infrastructure", ""),
        ("9.", "Development Roadmap", ""),
        ("10.", "NPM Packages & Dependencies List", ""),
    ]
    for num, title, _ in toc_items:
        if num and num[0].isdigit() and '.' == num[-1]:
            story.append(Paragraph(f"<b>{num}</b>&nbsp;&nbsp;&nbsp;{title}", S['toc_h1']))
        else:
            story.append(Paragraph(f"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{title}", S['toc_h2']))
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 1: ARCHITECTURE OVERVIEW
    # ══════════════════════════════════════════════
    story.append(heading1("1. Architecture Overview"))
    story.append(hr())

    story.append(heading2("1.1 Astro Islands Architecture"))
    story.append(body(
        "This citizen journalism platform adopts the <b>Astro Islands Architecture</b> as its foundational "
        "rendering paradigm. The core philosophy of Astro is to ship zero JavaScript by default, delivering "
        "static HTML to the browser for maximum performance. Interactive components are then selectively "
        "\"hydrated\" as independent islands within an otherwise static ocean of HTML. This approach is "
        "particularly well-suited for a news platform where the majority of content is read-only and does "
        "not require client-side interactivity."
    ))
    story.append(body(
        "In the context of this project, the Astro Islands architecture provides several strategic advantages. "
        "First, public-facing pages such as the homepage, news listing, article pages, and category pages can "
        "be pre-rendered at build time (SSG) or server-rendered on demand (SSR), ensuring they load almost "
        "instantly for readers. This is critical for a news organization where page load time directly impacts "
        "reader engagement and SEO rankings. Second, interactive features such as the news submission form, "
        "comment sections, contributor dashboard, and training LMS are implemented as Vue 3 island components "
        "that hydrate only when needed. This means a reader browsing the homepage downloads zero Vue JavaScript, "
        "while a contributor visiting the submission page downloads only the Vue code for that specific form."
    ))
    story.append(body(
        "The architecture is divided into three distinct rendering tiers:"
    ))
    story.append(bullet("<b>Tier 1 — Pure Static/SSR Pages:</b> Built with Astro components only. These include the homepage, "
        "news listing, article pages, category pages, about/contact pages, and SEO-critical landing pages. "
        "These pages are pre-rendered at build time (SSG) for stable content or server-rendered (SSR) via "
        "Astro's hybrid mode for frequently updated content like the homepage and news listing. No client-side "
        "JavaScript framework is shipped for these pages."))
    story.append(bullet("<b>Tier 2 — Astro Pages with Vue Islands:</b> Astro pages that embed one or more Vue 3 components "
        "as interactive islands. For example, the article page is primarily static Astro markup, but includes "
        "a Vue island for the comment section and a Vue island for the share/bookmark widget. The news "
        "submission page is an Astro wrapper with a large Vue island form component. These islands hydrate "
        "independently using Astro's <font face='Courier'>client:load</font>, <font face='Courier'>client:idle</font>, "
        "or <font face='Courier'>client:visible</font> directives."))
    story.append(bullet("<b>Tier 3 — Full Vue SPA Pages:</b> For complex, highly interactive sections of the application "
        "such as the Contributor Dashboard, Training LMS, and Admin Panel, the application delegates entirely "
        "to Vue 3 with Pinia state management and Vue Router. These are mounted as a single large island "
        "using <font face='Courier'>client:load</font> and handle their own routing internally. This provides "
        "a seamless single-page app experience within the Astro shell."))

    story.append(heading2("1.2 Coexistence Strategy: Static, Islands, and SPA"))
    story.append(body(
        "The three tiers coexist through Astro's flexible routing and integration system. Astro's file-based "
        "routing (<font face='Courier'>src/pages/</font>) handles all URL paths. For Tier 1 pages, the "
        "<font face='Courier'>.astro</font> files contain only Astro components and return pure HTML. For "
        "Tier 2 pages, the <font face='Courier'>.astro</font> files import and render Vue components using "
        "Astro's component syntax with hydration directives. For Tier 3 pages, a catch-all or specific route "
        "renders a single Vue app mount point that bootstraps the full SPA with Vue Router."
    ))
    story.append(body(
        "The transition between tiers is seamless to the user. Astro View Transitions provide animated page "
        "navigations that work across all three tiers. When a user clicks a link from a static article page "
        "to the contributor dashboard, the View Transitions API animates the transition, the old page unmounts, "
        "and the new SPA island mounts with its own router. The Astro shell (layout, header, footer) remains "
        "consistent across all tiers, providing a unified user experience."
    ))
    story.append(body(
        "Data fetching follows a clear separation of concerns. Astro pages fetch data at build time or request "
        "time using Astro's <font face='Courier'>getStaticPaths()</font> or server-side <font face='Courier'>Astro.fetch()</font> "
        "to call the Django Ninja API. Vue islands receive their initial data via props passed from the Astro "
        "parent component. Full SPA pages fetch all data client-side using Pinia store actions that call the "
        "Django Ninja API directly. This ensures that SEO-critical content is pre-rendered on the server while "
        "interactive features load their data asynchronously on the client."
    ))

    story.append(heading2("1.3 Project File/Folder Structure"))
    story.append(body("Below is the complete directory tree for the Astro project:"))
    
    dir_tree = """<font face="Courier" size="8.5">
src/<br/>
├── components/<br/>
│   ├── astro/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Pure Astro components (static)<br/>
│   │   ├── Header.astro<br/>
│   │   ├── Footer.astro<br/>
│   │   ├── SEOHead.astro<br/>
│   │   ├── NewsCard.astro<br/>
│   │   ├── CategoryNav.astro<br/>
│   │   ├── HeroSection.astro<br/>
│   │   ├── Breadcrumbs.astro<br/>
│   │   ├── Pagination.astro<br/>
│   │   ├── NewsletterSignup.astro<br/>
│   │   └── ContributorCard.astro<br/>
│   ├── vue/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Vue 3 island components<br/>
│   │   ├── CommentSection.vue<br/>
│   │   ├── ShareWidget.vue<br/>
│   │   ├── NewsSubmitForm.vue<br/>
│   │   ├── SearchBar.vue<br/>
│   │   ├── NotificationBell.vue<br/>
│   │   ├── LikeBookmark.vue<br/>
│   │   └── PhotoGallery.vue<br/>
│   ├── vue-spa/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Full SPA app components<br/>
│   │   ├── App.vue<br/>
│   │   ├── router.ts<br/>
│   │   ├── layouts/<br/>
│   │   │   ├── DashboardLayout.vue<br/>
│   │   │   ├── AdminLayout.vue<br/>
│   │   │   └── CourseLayout.vue<br/>
│   │   ├── views/<br/>
│   │   │   ├── dashboard/<br/>
│   │   │   │   ├── DashboardHome.vue<br/>
│   │   │   │   ├── MySubmissions.vue<br/>
│   │   │   │   ├── EarningsDetail.vue<br/>
│   │   │   │   └── ProfileSettings.vue<br/>
│   │   │   ├── course/<br/>
│   │   │   │   ├── CourseOverview.vue<br/>
│   │   │   │   ├── ModuleView.vue<br/>
│   │   │   │   ├── QuizView.vue<br/>
│   │   │   │   └── CertificateView.vue<br/>
│   │   │   └── admin/<br/>
│   │   │       ├── AdminDashboard.vue<br/>
│   │   │       ├── EditorialQueue.vue<br/>
│   │   │       ├── UserManagement.vue<br/>
│   │   │       ├── CourseManagement.vue<br/>
│   │   │       ├── PayoutManagement.vue<br/>
│   │   │       └── Analytics.vue<br/>
│   │   └── shared/<br/>
│   │       ├── DataTable.vue<br/>
│   │       ├── StatCard.vue<br/>
│   │       ├── ChartWidget.vue<br/>
│   │       └── AdminSidebar.vue<br/>
│   └── ui/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Shared Vue UI primitives<br/>
│       ├── BaseButton.vue<br/>
│       ├── BaseInput.vue<br/>
│       ├── BaseSelect.vue<br/>
│       ├── BaseModal.vue<br/>
│       ├── BaseBadge.vue<br/>
│       ├── BaseCard.vue<br/>
│       ├── BaseToast.vue<br/>
│       ├── BaseDropdown.vue<br/>
│       ├── BaseTooltip.vue<br/>
│       ├── ProgressBar.vue<br/>
│       ├── BaseAvatar.vue<br/>
│       ├── BaseSkeleton.vue<br/>
│       ├── EmptyState.vue<br/>
│       └── BasePagination.vue<br/>
├── layouts/<br/>
│   ├── BaseLayout.astro&nbsp;&nbsp;&nbsp;&nbsp;# Main layout (header+footer)<br/>
│   ├── ArticleLayout.astro&nbsp;&nbsp;# News article layout<br/>
│   ├── DashboardLayout.astro # SPA shell for dashboard<br/>
│   ├── AdminLayout.astro&nbsp;&nbsp;&nbsp;&nbsp;# SPA shell for admin<br/>
│   └── CourseLayout.astro&nbsp;&nbsp;&nbsp;&nbsp;# SPA shell for LMS<br/>
├── pages/<br/>
│   ├── index.astro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Homepage (SSR)<br/>
│   ├── news/<br/>
│   │   ├── index.astro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# News listing (SSR)<br/>
│   │   └── [slug].astro&nbsp;&nbsp;&nbsp;&nbsp;# Article page (SSG)<br/>
│   ├── category/<br/>
│   │   └── [slug].astro&nbsp;&nbsp;&nbsp;&nbsp;# Category page (SSG)<br/>
│   ├── district/<br/>
│   │   └── [slug].astro&nbsp;&nbsp;&nbsp;&nbsp;# District page (SSG)<br/>
│   ├── search.astro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Search results (SSR)<br/>
│   ├── contributor/<br/>
│   │   └── [id].astro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Public profile (SSG)<br/>
│   ├── about.astro<br/>
│   ├── contact.astro<br/>
│   ├── contribute.astro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Join program info (SSG)<br/>
│   ├── auth/<br/>
│   │   ├── login.astro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Login (SSR + Vue island)<br/>
│   │   └── register.astro&nbsp;&nbsp;&nbsp;# Register (SSR + Vue island)<br/>
│   ├── submit.astro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# News submit (SSR + Vue island)<br/>
│   ├── profile.astro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# User profile (SSR + Vue island)<br/>
│   ├── notifications.astro&nbsp;&nbsp;# Notifications (SSR + Vue island)<br/>
│   ├── dashboard/<br/>
│   │   └── [...slug].astro&nbsp;&nbsp;# SPA catch-all for dashboard<br/>
│   ├── course/<br/>
│   │   └── [...slug].astro&nbsp;&nbsp;# SPA catch-all for LMS<br/>
│   └── admin/<br/>
│       └── [...slug].astro&nbsp;&nbsp;# SPA catch-all for admin<br/>
├── stores/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Pinia stores (shared by islands + SPA)<br/>
│   ├── auth.ts<br/>
│   ├── news.ts<br/>
│   ├── contributor.ts<br/>
│   ├── course.ts<br/>
│   ├── admin.ts<br/>
│   └── ui.ts<br/>
├── lib/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Shared utilities<br/>
│   ├── api.ts&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# HTTP client (ky/ofetch wrapper)<br/>
│   ├── constants.ts<br/>
│   ├── utils.ts<br/>
│   ├── validators.ts&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Zod schemas<br/>
│   └── formatters.ts<br/>
├── styles/<br/>
│   ├── global.css&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Tailwind imports + global styles<br/>
│   ├── fonts.css&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Google Fonts import<br/>
│   └── animations.css&nbsp;&nbsp;&nbsp;&nbsp;# Custom animations<br/>
├── assets/<br/>
│   ├── images/<br/>
│   └── icons/<br/>
├── content/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Astro Content Collections<br/>
│   ├── config.ts<br/>
│   └── static-pages/<br/>
├── i18n/&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# Internationalization (future)<br/>
│   ├── en.json<br/>
│   └── bn.json<br/>
└── env.d.ts<br/>
</font>"""
    story.append(Paragraph(dir_tree, S['code']))
    story.append(spacer(4))

    story.append(heading2("1.4 Django Ninja API Integration"))
    story.append(body(
        "The frontend communicates exclusively with the Django Ninja REST API. All API endpoints are prefixed "
        "with <font face='Courier'>/api/v1/</font> and return JSON. The integration points are as follows:"
    ))
    story.append(bullet("<b>Astro Server-Side Fetching:</b> Astro pages use <font face='Courier'>fetch()</font> in their frontmatter "
        "to call API endpoints during build or SSR. This data is passed to components as props. For example, "
        "<font face='Courier'>news/[slug].astro</font> fetches article data from <font face='Courier'>GET /api/v1/news/{slug}/</font> "
        "at request time."))
    story.append(bullet("<b>Vue Island Client-Side Fetching:</b> Vue island components use the shared "
        "<font face='Courier'>lib/api.ts</font> HTTP client (wrapping ky or ofetch) to call API endpoints "
        "after hydration. The HTTP client automatically includes authentication headers, CSRF tokens, and "
        "handles token refresh."))
    story.append(bullet("<b>SPA Data Layer:</b> Full SPA pages use Pinia stores to manage API data. Each store "
        "contains actions that call API endpoints and mutations to update state. Components dispatch actions "
        "and react to state changes."))
    story.append(body(
        "Authentication uses httpOnly cookies for access and refresh tokens. The API client intercepts 401 "
        "responses, attempts a token refresh via <font face='Courier'>POST /api/v1/auth/refresh/</font>, and "
        "retries the failed request. CSRF tokens are obtained from the Django backend and included in the "
        "<font face='Courier'>X-CSRFToken</font> header for all mutating requests."
    ))

    story.append(heading2("1.5 Routing Strategy"))
    story.append(body(
        "Routing is split between Astro and Vue Router. Astro handles all top-level routes via file-based routing "
        "in <font face='Courier'>src/pages/</font>. For public and semi-public pages, Astro routes directly to "
        "the corresponding <font face='Courier'>.astro</font> file. For SPA sections (dashboard, course, admin), "
        "Astro uses a catch-all route <font face='Courier'>[...slug].astro</font> that renders the Vue SPA "
        "mount point. Vue Router then takes over, handling nested routes within the SPA using hash-based or "
        "history-based routing. View Transitions are disabled for SPA navigation to avoid conflicts, but the "
        "Astro-to-SPA transition is handled by a smooth loading indicator."
    ))
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 2: PAGE INVENTORY & RENDERING STRATEGY
    # ══════════════════════════════════════════════
    story.append(heading1("2. Page Inventory & Rendering Strategy"))
    story.append(hr())
    story.append(body(
        "This section provides a comprehensive inventory of every page in the application, along with its rendering "
        "strategy, access level, key components, and a brief description. The rendering types are: <b>Static (SSG)</b> "
        "for pre-built content pages, <b>Server (SSR)</b> for dynamic pages rendered at request time, <b>Island</b> "
        "for Astro pages with embedded Vue interactive components, and <b>SPA</b> for full Vue single-page application pages."
    ))
    story.append(spacer(6))

    # Public Pages Table
    story.append(heading2("2.1 Public Pages"))
    pub_headers = ["Page", "URL Path", "Render", "Components", "Description"]
    pub_rows = [
        ["Homepage", "/", "SSR", "HeroSection, NewsCard,\nCategoryNav, SearchBar", "Featured news, category navigation,\ntrending stories, contributor spotlight,\n'Become a Contributor' CTA"],
        ["News Listing", "/news", "SSR", "NewsCard, Pagination,\nFilterPanel(Vue island)", "Paginated news with filters by\ncategory, district, date range"],
        ["Article Page", "/news/[slug]", "SSG", "PhotoGallery(Vue),\nCommentSection(Vue),\nShareWidget(Vue)", "Full article with structured WH\nformat, images, related stories,\ncomments, share buttons"],
        ["Category Page", "/category/[slug]", "SSG", "NewsCard, Breadcrumbs,\nPagination", "All news in a specific category\n(politics, crime, education, etc.)"],
        ["District Page", "/district/[slug]", "SSG", "NewsCard, Breadcrumbs,\nPagination, DistrictMap", "All news from a specific district\nor region"],
        ["Search Results", "/search", "SSR", "SearchBar(Vue), NewsCard,\nPagination, FilterPanel(Vue)", "Full-text search results with\nfaceted filters"],
        ["Contributor\nProfile", "/contributor/[id]", "SSG", "ContributorCard, NewsCard,\nStatCard", "Public profile showing contributor\nstats, bio, published articles"],
        ["About Us", "/about", "SSG", "StaticContent", "Organization info, mission,\nteam, contact details"],
        ["Contact", "/contact", "SSR", "ContactForm(Vue island)", "Contact form, office locations,\nmap embed"],
        ["Contribute\n(Join Info)", "/contribute", "SSG", "CTASection, FAQ,\nBenefitCards", "Program info: how to join,\nbenefits, training overview, FAQ"],
    ]
    t = make_table(pub_headers, pub_rows, col_widths=[0.85*inch, 0.95*inch, 0.5*inch, 1.6*inch, 2.65*inch])
    story.append(t)
    story.append(spacer(8))

    # Auth Required Pages Table
    story.append(heading2("2.2 Authentication Required Pages"))
    auth_headers = ["Page", "URL Path", "Render", "Components", "Description"]
    auth_rows = [
        ["Login", "/auth/login", "SSR+\nIsland", "LoginForm(Vue island)", "Email/password login, social login\noptions, forgot password link"],
        ["Register", "/auth/register", "SSR+\nIsland", "RegisterForm(Vue island)", "Account creation with name, email,\nphone, password, role selection"],
        ["News\nSubmission", "/submit", "SSR+\nIsland", "NewsSubmitForm(Vue island),\nPhotoUpload(Vue)", "WH-question wizard form, photo\nupload with geotagging, preview"],
        ["User Profile\n& Settings", "/profile", "SSR+\nIsland", "ProfileForm(Vue island),\nAvatarUpload(Vue)", "Edit name, bio, avatar, phone,\nnotification preferences, password"],
        ["Notification\nCenter", "/notifications", "SSR+\nIsland", "NotificationList(Vue island)", "List of notifications with read/\nunread status, mark all read, filter"],
    ]
    t = make_table(auth_headers, auth_rows, col_widths=[0.85*inch, 0.95*inch, 0.5*inch, 1.7*inch, 2.55*inch])
    story.append(t)
    story.append(spacer(8))

    # Contributor Only Pages
    story.append(heading2("2.3 Contributor-Only Pages (Full SPA)"))
    contrib_headers = ["Page", "URL Path", "Render", "Components", "Description"]
    contrib_rows = [
        ["Contributor\nDashboard", "/dashboard/", "SPA", "StatCard, ChartWidget,\nRecentList, QuickSubmit", "Overview: total submissions,\npublished, pending, points,\nearnings, recent activity"],
        ["My\nSubmissions", "/dashboard/\nsubmissions", "SPA", "DataTable, StatusBadge,\nFilterPanel, SearchBar", "List of all submissions with\nstatus (pending/reviewed/\npublished/rejected), filters"],
        ["Submission\nDetail", "/dashboard/\nsubmissions/[id]", "SPA", "ArticlePreview, EditorNotes,\nStatusTimeline", "View submission details,\neditor feedback, status history"],
        ["Earnings\nDetail", "/dashboard/\nearnings", "SPA", "EarningsChart,\nTransactionTable,\nPayoutRequest", "Monthly earnings chart,\ntransaction history, payout\nrequest form, bank details"],
        ["Points\nHistory", "/dashboard/\npoints", "SPA", "PointsChart,\nPointsHistoryTable,\nLevelProgress", "Points earned breakdown,\nlevel progress bar, redemption\noptions, history"],
    ]
    t = make_table(contrib_headers, contrib_rows, col_widths=[0.85*inch, 1.0*inch, 0.5*inch, 1.55*inch, 2.65*inch])
    story.append(t)
    story.append(spacer(8))

    # Training / LMS Pages
    story.append(heading2("2.4 Training Course / LMS Pages (Full SPA)"))
    lms_headers = ["Page", "URL Path", "Render", "Components", "Description"]
    lms_rows = [
        ["Course\nOverview", "/course/", "SPA", "ModuleList, ProgressBar,\nCourseInfoCard", "All 6 modules listed with\nstatus, overall progress %,\ncourse description"],
        ["Module\nView", "/course/\nmodule/[id]", "SPA", "VideoPlayer, TextContent,\nNavigationButtons,\nMarkdownRenderer", "Video lesson, text content,\nexamples, previous/next\nnavigation"],
        ["Quiz", "/course/\nquiz/[id]", "SPA", "QuizQuestion,\nMultipleChoice, WHInput,\nTimerDisplay, ScoreCard", "Quiz with MCQ + WH practice\nquestions, timer, auto-grading,\nretry option"],
        ["Certificate", "/course/\ncertificate", "SPA", "CertificateCard,\nDownloadButton,\nShareButtons", "Completion certificate view\nwith download (PDF), share\non social media"],
    ]
    t = make_table(lms_headers, lms_rows, col_widths=[0.85*inch, 1.0*inch, 0.5*inch, 1.6*inch, 2.6*inch])
    story.append(t)
    story.append(spacer(8))

    # Admin Only Pages
    story.append(heading2("2.5 Admin-Only Pages (Full SPA)"))
    admin_headers = ["Page", "URL Path", "Render", "Components", "Description"]
    admin_rows = [
        ["Admin\nDashboard", "/admin/", "SPA", "StatCard, ChartWidget,\nPendingQueue,\nActivityFeed", "Stats overview: pending reviews,\nactive contributors, published\ntoday, revenue, alerts"],
        ["Editorial\nQueue", "/admin/\nqueue", "SPA", "DataTable, ReviewPanel,\nEditToolbar,\nApproveRejectBtns", "Pending submissions list with\ninline review, edit, approve,\nreject, publish controls"],
        ["User\nManagement", "/admin/\nusers", "SPA", "DataTable, UserCard,\nRoleSelector,\nBanToggle", "All users list, role management,\nban/unban, search, filter by\nrole/status"],
        ["Course\nManagement", "/admin/\ncourses", "SPA", "ModuleEditor,\nQuizBuilder,\nContentUploader,\nDragDropList", "Create/edit course modules,\nquizzes, upload video content,\nreorder modules"],
        ["Payout\nManagement", "/admin/\npayouts", "SPA", "PayoutTable,\nApproveRejectBtns,\nBulkActions,\nExportBtn", "Pending payout requests,\napprove/reject, bulk process,\nexport to CSV"],
        ["Content\nManagement", "/admin/\ncontent", "SPA", "CategoryEditor,\nDistrictEditor,\nSettingsForm,\nTagManager", "Manage categories, districts,\ntags, platform settings,\nhomepage configuration"],
        ["Reports &\nAnalytics", "/admin/\nanalytics", "SPA", "AnalyticsChart,\nDateRangePicker,\nMetricCards,\nDataExport", "Traffic, submissions, contributor\nactivity, revenue reports,\ndownloadable CSV/PDF"],
    ]
    t = make_table(admin_headers, admin_rows, col_widths=[0.85*inch, 0.95*inch, 0.5*inch, 1.55*inch, 2.7*inch])
    story.append(t)
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 3: DESIGN SYSTEM & UI SPECIFICATIONS
    # ══════════════════════════════════════════════
    story.append(heading1("3. Design System & UI Specifications"))
    story.append(hr())
    story.append(body(
        "The design system establishes a consistent visual language across the entire platform. Given that this "
        "is a citizen journalism platform — a serious news organization — the design must convey trustworthiness, "
        "credibility, and professionalism while remaining approachable for rural contributors. The color palette "
        "draws from authoritative news organizations: deep navy blues for trust, warm amber accents for energy "
        "and engagement, and clean neutral backgrounds for readability."
    ))

    story.append(heading2("3.1 Color Palette"))
    story.append(body("The primary color palette uses deep navy as the authoritative base, with warm amber as the "
        "engagement accent. A comprehensive set of semantic colors supports status communication, form validation, "
        "and feedback throughout the application."))

    color_headers = ["Role", "Token Name", "Light Mode", "Dark Mode", "Usage"]
    color_rows = [
        ["Primary", "--color-primary-500", "#1B2A4A (Navy)", "#4A6FA5", "Headers, nav, primary buttons"],
        ["Primary\nLight", "--color-primary-300", "#2E6B9E", "#5B8EC9", "Hover states, secondary accents"],
        ["Primary\nPale", "--color-primary-100", "#DBEAFE", "#1E3A5F", "Backgrounds, selected states"],
        ["Accent", "--color-accent-500", "#E8A838 (Amber)", "#F0C060", "CTAs, highlights, badges"],
        ["Accent\nDark", "--color-accent-700", "#D4762C (Orange)", "#E8944A", "Hover states, urgent items"],
        ["Success", "--color-success-500", "#10B981", "#34D399", "Approved, published, earned"],
        ["Warning", "--color-warning-500", "#F59E0B", "#FBBF24", "Pending, caution states"],
        ["Error", "--color-error-500", "#EF4444", "#F87171", "Rejected, validation errors"],
        ["Info", "--color-info-500", "#3B82F6", "#60A5FA", "Informational, tooltips"],
        ["Neutral 900", "--color-neutral-900", "#111827", "#F9FAFB", "Primary text / bg (inverted)"],
        ["Neutral 700", "--color-neutral-700", "#374151", "#D1D5DB", "Secondary text / borders"],
        ["Neutral 400", "--color-neutral-400", "#9CA3AF", "#6B7280", "Disabled, placeholders"],
        ["Neutral 100", "--color-neutral-100", "#F3F4F6", "#1F2937", "Page backgrounds"],
        ["Surface", "--color-surface", "#FFFFFF", "#111827", "Card backgrounds"],
        ["Surface\nAlt", "--color-surface-alt", "#F9FAFB", "#1F2937", "Alternate row, sidebar"],
    ]
    t = make_table(color_headers, color_rows, col_widths=[0.7*inch, 1.15*inch, 1.2*inch, 1.0*inch, 2.5*inch])
    story.append(t)
    story.append(spacer(4))
    story.append(note(
        "<b>Note:</b> Dark mode is toggled via a user preference stored in localStorage and applied through "
        "a <font face='Courier'>.dark</font> class on the HTML root element. Tailwind CSS 4.x dark variant "
        "(<font face='Courier'>dark:</font>) handles all color switching."
    ))

    story.append(heading2("3.2 Typography"))
    story.append(body(
        "Typography is designed for maximum readability across news articles, forms, and dashboards. We use "
        "Google Fonts with a professional serif for headlines and a clean sans-serif for body text."
    ))
    story.append(heading3("Font Families"))
    story.append(bullet("<b>Headlines (Serif):</b> <font face='Courier'>Merriweather</font> — classic editorial feel, "
        "excellent for news headlines and article titles. Weights: 400, 700, 900."))
    story.append(bullet("<b>Body Text (Sans-Serif):</b> <font face='Courier'>Inter</font> — highly readable at all sizes, "
        "excellent for UI text, forms, and body copy. Weights: 400, 500, 600, 700."))
    story.append(bullet("<b>Mono (Code):</b> <font face='Courier'>JetBrains Mono</font> — for code snippets and data tables."))
    
    story.append(heading3("Type Scale (Tailwind Classes)"))
    type_headers = ["Element", "Tailwind Class", "Size", "Weight", "Line Height"]
    type_rows = [
        ["Page Title (h1)", "text-4xl md:text-5xl", "36/48px", "900 (Black)", "1.2"],
        ["Section Title (h2)", "text-2xl md:text-3xl", "24/30px", "700 (Bold)", "1.3"],
        ["Subsection (h3)", "text-xl md:text-2xl", "20/24px", "700 (Bold)", "1.35"],
        ["Card Title (h4)", "text-lg", "18px", "600 (Semi)", "1.4"],
        ["Subtitle", "text-base md:text-lg", "16/18px", "500 (Medium)", "1.5"],
        ["Body Text", "text-sm md:text-base", "14/16px", "400 (Regular)", "1.6"],
        ["Small Text", "text-xs md:text-sm", "12/14px", "400 (Regular)", "1.5"],
        ["Caption/Label", "text-xs", "12px", "500 (Medium)", "1.4"],
        ["Overline", "text-[10px] uppercase\ntracking-wider", "10px", "600 (Semi)", "1.3"],
    ]
    t = make_table(type_headers, type_rows, col_widths=[1.2*inch, 1.5*inch, 1.0*inch, 1.1*inch, 1.0*inch])
    story.append(t)

    story.append(heading2("3.3 Spacing System"))
    story.append(body(
        "The spacing system is based on Tailwind CSS 4.x's default spacing scale, which uses a 4px base unit. "
        "All spacing in the application adheres to this scale for visual consistency."
    ))
    story.append(bullet("<b>Section Spacing:</b> <font face='Courier'>py-12 md:py-16 lg:py-20</font> between major page sections."))
    story.append(bullet("<b>Card Padding:</b> <font face='Courier'>p-4 md:p-6</font> for content cards."))
    story.append(bullet("<b>Form Group Spacing:</b> <font face='Courier'>space-y-4</font> between form fields."))
    story.append(bullet("<b>Component Gaps:</b> <font face='Courier'>gap-4</font> for grid layouts, <font face='Courier'>gap-2</font> for inline items."))
    story.append(bullet("<b>Container Max Width:</b> <font face='Courier'>max-w-7xl mx-auto px-4 sm:px-6 lg:px-8</font> for page containers."))

    story.append(heading2("3.4 Component Library"))
    story.append(body(
        "The following tables enumerate every reusable UI component required for the platform. Each component is "
        "built as a Vue 3 SFC using the Composition API and <font face='Courier'>&lt;script setup&gt;</font> "
        "syntax. All components follow the design tokens defined above and support dark mode."
    ))

    story.append(heading3("3.4.1 Buttons"))
    btn_headers = ["Component", "Variants", "Sizes", "States", "Tailwind Classes"]
    btn_rows = [
        ["BaseButton", "primary, secondary,\nghost, danger, outline", "sm, md, lg", "default, hover,\nfocus, active,\ndisabled, loading", "rounded-lg font-medium\ntransition-all\nduration-200"],
        ["IconButton", "primary, ghost", "sm, md, lg", "default, hover,\ndisabled, loading", "rounded-full or\nrounded-lg"],
    ]
    t = make_table(btn_headers, btn_rows, col_widths=[0.9*inch, 1.2*inch, 0.9*inch, 1.1*inch, 2.4*inch])
    story.append(t)
    story.append(spacer(4))

    story.append(heading3("3.4.2 Cards"))
    card_headers = ["Component", "Props", "Description"]
    card_rows = [
        ["NewsCard", "title, excerpt, image,\ncategory, district,\ndate, slug", "Main news article card with image,\ntitle, excerpt, metadata badges.\nVariants: horizontal, vertical, compact"],
        ["ContributorCard", "name, avatar, district,\narticles, points, level", "Public contributor profile card with\navatar, stats, and link to full profile"],
        ["CourseCard", "title, description,\nmoduleCount, progress,\nthumbnail, status", "Training course module card showing\nprogress, status, and estimated time"],
        ["StatCard", "label, value, icon,\ntrend, trendValue,\ncolor", "Dashboard statistics card with\nicon, main value, trend indicator"],
        ["CategoryPill", "name, icon, slug,\ncount", "Clickable category badge/pill with\ncount, used in navigation and filters"],
    ]
    t = make_table(card_headers, card_rows, col_widths=[1.2*inch, 1.6*inch, 3.7*inch])
    story.append(t)
    story.append(spacer(4))

    story.append(heading3("3.4.3 Navigation"))
    nav_headers = ["Component", "Features"]
    nav_rows = [
        ["TopNavbar", "Logo, main nav links (Home, News, Categories, About), search icon, notification bell (auth),\nlogin/register buttons (anon), user avatar dropdown (auth). Sticky, glass-morphism background.\nResponsive: hamburger menu on mobile with slide-in drawer."],
        ["MobileDrawer", "Slide-in menu from left. Contains all nav links, category list, auth actions.\nClose on outside click or escape key. Animated with Tailwind transitions."],
        ["AdminSidebar", "Collapsible sidebar for admin/dashboard. Icons + labels. Active state indicator.\nNested items for sub-pages. Collapses to icon-only on smaller screens."],
        ["Breadcrumbs", "Auto-generated from route. Schema.org structured data for SEO. Truncation for deep paths."],
    ]
    t = make_table(nav_headers, nav_rows, col_widths=[1.2*inch, 5.3*inch])
    story.append(t)
    story.append(spacer(4))

    story.append(heading3("3.4.4 Form Components"))
    form_headers = ["Component", "Features"]
    form_rows = [
        ["BaseInput", "Text input with label, placeholder, helper text, error message. Variants: default,\nfilled, outline. Sizes: sm, md, lg. Supports prefix/suffix icons (e.g., search icon)."],
        ["BaseTextarea", "Multi-line input with character count, auto-resize option, label, error state."],
        ["BaseSelect", "Dropdown select with search/filter, multi-select mode, custom option rendering.\nAsync option loading for large datasets."],
        ["FileUpload", "Drag-and-drop zone, click-to-browse. Preview thumbnails. Multiple file support.\nProgress indicator per file. File type/size validation. Geotagging support for photos."],
        ["DatePicker", "Date input with calendar dropdown. Range selection support. Min/max date constraints.\nLocale-aware formatting."],
        ["WHQuestionForm", "Structured form with 6 fields: What, When, Where, Who, Why, How. Each field\nhas placeholder guidance text. Connected to Zod validation. Preview mode."],
        ["BaseCheckbox", "Custom styled checkbox with label, indeterminate state, group with 'select all'."],
        ["BaseRadio", "Custom styled radio buttons with label and description text."],
        ["FormError", "Inline error message below field. Animated appearance. Links to field via aria-describedby."],
    ]
    t = make_table(form_headers, form_rows, col_widths=[1.3*inch, 5.2*inch])
    story.append(t)
    story.append(spacer(4))

    story.append(heading3("3.4.5 Status & Display Components"))
    status_headers = ["Component", "Variants/Features"]
    status_rows = [
        ["StatusBadge", "pending (yellow), approved (green), published (blue), rejected (red),\nreviewing (orange). Pill shape with dot indicator. Animated state changes."],
        ["CategoryBadge", "Color-coded by category. Clickable link. Small pill with icon."],
        ["PointsDisplay", "Animated counter. Shows point value with icon. Supports +N animation\nfor new points earned."],
        ["LevelBadge", "Contributor level indicator (Bronze, Silver, Gold, Platinum).\nShield icon with color gradient."],
        ["ProgressBar", "Linear progress bar with percentage label. Animated fill.\nColors: primary (default), success, warning. Used for course progress."],
        ["Avatar", "Image avatar with fallback initials. Size variants: xs, sm, md, lg, xl.\nOnline status indicator (green dot). Border ring option."],
        ["Tooltip", "Positioned tooltip (top, right, bottom, left). Hover or click trigger.\nDark background with arrow. Delay option."],
    ]
    t = make_table(status_headers, status_rows, col_widths=[1.2*inch, 5.3*inch])
    story.append(t)
    story.append(spacer(4))

    story.append(heading3("3.4.6 Overlay & Feedback Components"))
    overlay_headers = ["Component", "Features"]
    overlay_rows = [
        ["BaseModal", "Centered overlay modal. Header, body, footer slots. Close on backdrop click,\nEscape key, or X button. Focus trap. Animated scale+fade entrance. Size variants."],
        ["BaseDropdown", "Positioned dropdown menu. Keyboard navigation. Trigger element + menu.\nDivider items, disabled items, icons per item."],
        ["BaseToast", "Toast notification system. Variants: success, error, warning, info.\nAuto-dismiss with timer. Stack from top-right. Animated slide-in/out.\nAction button support."],
        ["ConfirmDialog", "Confirmation modal with icon, title, message, confirm/cancel buttons.\nDanger variant with red styling."],
        ["LoadingSkeleton", "Animated pulse placeholder matching component shape. Variants: text line,\nimage, card, table row, heading. Shimmer animation."],
        ["EmptyState", "Illustration + title + description + action button. Used when lists/tables\nhave no data."],
        ["PhotoGallery", "Grid of thumbnails. Click to open lightbox. Swipe navigation.\nZoom support. Caption display. Counter (1/N)."],
        ["Pagination", "Previous/next buttons, page numbers, ellipsis for large page counts.\nURL-based for SEO pages, client-side for SPA."],
    ]
    t = make_table(overlay_headers, overlay_rows, col_widths=[1.2*inch, 5.3*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("3.5 Responsive Breakpoints"))
    story.append(body(
        "The platform follows a mobile-first responsive strategy. All components are designed for the smallest "
        "screen first, then enhanced for larger screens using Tailwind's responsive prefixes."
    ))
    bp_headers = ["Breakpoint", "Tailwind Prefix", "Min Width", "Target Devices", "Layout Notes"]
    bp_rows = [
        ["Default", "(none)", "0px", "Mobile phones (< 640px)", "Single column, full-width cards,\nhamburger nav, stacked forms"],
        ["Small", "sm:", "640px", "Large phones in landscape", "Two-column grids, expanded nav"],
        ["Medium", "md:", "768px", "Tablets (portrait)", "Sidebar visible, multi-column grids"],
        ["Large", "lg:", "1024px", "Tablets (landscape), laptops", "Full layout, sidebars, 3-col grids"],
        ["Extra Large", "xl:", "1280px", "Desktops", "Max container width, 4-col grids"],
        ["2X Large", "2xl:", "1536px", "Large desktops/monitors", "Extended content width"],
    ]
    t = make_table(bp_headers, bp_rows, col_widths=[0.85*inch, 1.0*inch, 0.7*inch, 1.8*inch, 2.2*inch])
    story.append(t)

    story.append(heading2("3.6 Accessibility (WCAG 2.1 AA)"))
    story.append(body("The platform must meet WCAG 2.1 AA accessibility standards. Key considerations include:"))
    story.append(bullet("<b>Color Contrast:</b> All text meets a minimum 4.5:1 contrast ratio against its background. "
        "Large text (18px+) meets 3:1. All interactive elements have visible focus indicators (2px outline)."))
    story.append(bullet("<b>Keyboard Navigation:</b> All interactive elements are reachable via Tab key and operable "
        "via Enter/Space. Modals implement focus trapping. Skip-to-content link at the top of every page."))
    story.append(bullet("<b>Screen Readers:</b> Semantic HTML elements throughout. ARIA labels on interactive "
        "elements. ARIA live regions for dynamic content (toasts, form errors). Alt text on all images."))
    story.append(bullet("<b>Forms:</b> All inputs have associated labels. Error messages linked via "
        "<font face='Courier'>aria-describedby</font>. Required fields indicated. Group related fields with "
        "<font face='Courier'>fieldset</font> and <font face='Courier'>legend</font>."))
    story.append(bullet("<b>Motion:</b> All animations respect <font face='Courier'>prefers-reduced-motion</font> "
        "media query. Essential state changes do not rely solely on animation."))
    story.append(bullet("<b>Touch Targets:</b> Minimum 44x44px touch targets for mobile. Adequate spacing "
        "between clickable elements to prevent mis-taps."))
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 4: KEY PAGE DESIGNS
    # ══════════════════════════════════════════════
    story.append(heading1("4. Key Page Designs"))
    story.append(hr())
    story.append(body(
        "This section provides detailed layout and UX specifications for the five most important pages in the "
        "application. Each page design includes the visual structure, component composition, and key UX considerations."
    ))

    # 4.1 Homepage
    story.append(heading2("4.1 Homepage"))
    story.append(body(
        "The homepage is the primary entry point for general readers and the most critical page for SEO and "
        "first impressions. It must communicate the platform's authority, showcase the latest news, and encourage "
        "visitors to become contributors."
    ))
    story.append(heading3("Layout Structure (Top to Bottom)"))
    story.append(body("<b>1. Top Navigation Bar (Sticky)</b>"))
    story.append(bullet("Platform logo (left) — links to homepage."))
    story.append(bullet("Main navigation links: Home, News, Categories (dropdown), Districts, About, Contact."))
    story.append(bullet("Right side: Search icon (opens search overlay), notification bell (if authenticated), "
        "Login/Register buttons (if anonymous) or User avatar dropdown (if authenticated)."))
    story.append(bullet("Mobile: Hamburger icon opens a slide-in drawer with all nav links and auth actions."))

    story.append(body("<b>2. Hero Section (Full-Width)</b>"))
    story.append(bullet("Large featured/breaking news story with a full-width background image (16:9 aspect ratio)."))
    story.append(bullet("Gradient overlay (dark, bottom-to-top) for text readability."))
    story.append(bullet("Overlay content: 'BREAKING' or 'FEATURED' badge, article headline (large, white, serif), "
        "district tag, short excerpt, 'Read More' button (accent color)."))
    story.append(bullet("Auto-rotates through top 3-5 featured stories every 8 seconds with a fade transition."))
    story.append(bullet("Navigation dots at the bottom for manual selection."))

    story.append(body("<b>3. Category Navigation Strip</b>"))
    story.append(bullet("Horizontal scrollable row of category pills: Politics, Crime, Education, Health, "
        "Agriculture, Infrastructure, Sports, Culture, Technology, Environment."))
    story.append(bullet("Active category highlighted with primary color. Clicking filters the latest news section below."))

    story.append(body("<b>4. Latest News Grid</b>"))
    story.append(bullet("Section heading: 'Latest News' with 'View All' link."))
    story.append(bullet("Responsive grid: 1 column on mobile, 2 on tablet, 3 on desktop."))
    story.append(bullet("Each NewsCard shows: image (4:3), category badge (top-left), district tag (bottom), "
        "headline (2-line clamp), excerpt (2-line clamp), timestamp (relative: '2 hours ago'), author display "
        "(anonymous 'Citizen Reporter' or district name)."))
    story.append(bullet("Pagination or 'Load More' button at the bottom."))

    story.append(body("<b>5. Trending Stories Sidebar (Desktop) / Section (Mobile)</b>"))
    story.append(bullet("On desktop: right sidebar with numbered list of top 5 trending stories."))
    story.append(bullet("On mobile: horizontal section below the news grid."))
    story.append(bullet("Each item: rank number (large, accent color), headline (2-line), view count."))

    story.append(body("<b>6. 'Become a Contributor' CTA Banner</b>"))
    story.append(bullet("Full-width section with a warm background gradient (amber tones)."))
    story.append(bullet("Heading: 'Your Community Needs Your Voice.'"))
    story.append(bullet("Subheading: 'Join our network of trained citizen journalists. Report local news, earn "
        "points, and make a difference in your community.'"))
    story.append(bullet("Two buttons: 'Learn More' (outline) and 'Join Now' (primary, accent background)."))
    story.append(bullet("Illustration of diverse contributors on the right side."))

    story.append(body("<b>7. Regional News Section</b>"))
    story.append(bullet("Section heading: 'News from Your Region.'"))
    story.append(bullet("District selector (dropdown or horizontal scroll of district cards)."))
    story.append(bullet("Grid of 4-6 latest news cards from the selected district."))
    story.append(bullet("Link: 'View All [District] News.'"))

    story.append(body("<b>8. Footer</b>"))
    story.append(bullet("Four-column layout on desktop, stacked on mobile."))
    story.append(bullet("Column 1: Logo, brief description, social media icons (Facebook, Twitter, YouTube, Instagram)."))
    story.append(bullet("Column 2: Quick Links — News, Categories, About, Contact, Contribute."))
    story.append(bullet("Column 3: Legal — Privacy Policy, Terms of Service, Cookie Policy, Contributor Agreement."))
    story.append(bullet("Column 4: Newsletter signup — email input + Subscribe button."))
    story.append(bullet("Bottom bar: Copyright notice, 'Powered by [Platform Name]', language selector."))

    # 4.2 News Article Page
    story.append(heading2("4.2 News Article Page"))
    story.append(body(
        "The article page is where readers consume content. It is optimized for readability, social sharing, "
        "and engagement. The page is server-rendered (SSG) for SEO, with Vue islands for interactive elements."
    ))
    story.append(heading3("Layout Structure"))
    story.append(body("<b>1. Article Header</b>"))
    story.append(bullet("Breadcrumbs: Home > Category > Article Title."))
    story.append(bullet("Category badge (color-coded pill, e.g., 'Crime' in red)."))
    story.append(bullet("Article headline: <font face='Courier'>text-3xl md:text-4xl</font>, Merriweather Bold."))
    story.append(bullet("Metadata row: publication date, district tag, reading time estimate."))
    story.append(bullet("Author line: 'Reported by Citizen Reporter from [District]' (anonymized for safety)."))

    story.append(body("<b>2. Hero Image / Photo Gallery</b>"))
    story.append(bullet("Featured image (full-width, max-height 500px, object-cover)."))
    story.append(bullet("If multiple photos: PhotoGallery Vue island with thumbnail strip below the main image."))
    story.append(bullet("Image captions sourced from contributor submission."))
    story.append(bullet("Lightbox on click (Vue island with keyboard navigation, zoom)."))

    story.append(body("<b>3. Article Body</b>"))
    story.append(bullet("WH-question structured format, rendered with clear sub-headings:"))
    story.append(sub_bullet("<b>What Happened:</b> The main event description."))
    story.append(sub_bullet("<b>When:</b> Date and time of the incident."))
    story.append(sub_bullet("<b>Where:</b> Specific location, village, road, landmark."))
    story.append(sub_bullet("<b>Who Was Involved:</b> People mentioned (anonymized if sensitive)."))
    story.append(sub_bullet("<b>Why:</b> Context and background."))
    story.append(sub_bullet("<b>How:</b> Detailed account of events."))
    story.append(bullet("Rich text rendering: paragraphs, lists, blockquotes."))
    story.append(bullet("In-article inline images with captions."))
    story.append(bullet("Maximum content width: <font face='Courier'>max-w-3xl</font> (768px) for optimal readability."))

    story.append(body("<b>4. Share & Engage Bar</b>"))
    story.append(bullet("Sticky bar below the article (or floating on mobile)."))
    story.append(bullet("Share buttons: Facebook, Twitter, WhatsApp, Copy Link."))
    story.append(bullet("Bookmark/Save button (auth required)."))
    story.append(bullet("React/emoji reaction buttons (optional)."))

    story.append(body("<b>5. Comment Section (Vue Island, client:visible)</b>"))
    story.append(bullet("Comment count heading."))
    story.append(bullet("Sort options: Newest, Oldest, Most Liked."))
    story.append(bullet("Comment input: textarea + Submit button (auth required, login prompt for anon users)."))
    story.append(bullet("Comment list: avatar, username (anonymized option), timestamp, text, like/reply buttons."))
    story.append(bullet("Nested replies (1 level deep). Pagination for many comments."))

    story.append(body("<b>6. Sidebar (Desktop Only)</b>"))
    story.append(bullet("'More from [Category]' — 4-5 related articles."))
    story.append(bullet("'More from [District]' — 4-5 local articles."))
    story.append(bullet("'Trending Now' — 3-5 trending stories."))
    story.append(bullet("Newsletter signup mini-form."))

    # 4.3 News Submission Form
    story.append(heading2("4.3 News Submission Form"))
    story.append(body(
        "The news submission form is the core interactive feature for contributors. It must be intuitive for "
        "rural users who may not be technically savvy, while maintaining structured data quality through the "
        "WH-question format. This is implemented as a Vue 3 island component (<font face='Courier'>client:load</font>) "
        "within an Astro page."
    ))
    story.append(heading3("Form Design"))
    story.append(body("<b>Step 1: Basic Information</b>"))
    story.append(bullet("Category selection (required): Dropdown with all active categories."))
    story.append(bullet("Priority selector (required): Radio buttons — Routine, Breaking, Crime, Follow-up, Feature."))
    story.append(bullet("District / Location (required): Cascading selects — Division > District > Upazila. "
        "Option to enter custom location description."))
    story.append(bullet("Headline (required): Text input with character limit (150 chars). Auto-suggested from 'What Happened' field."))
    story.append(bullet("Summary / Excerpt (optional): Textarea with 300 char limit."))

    story.append(body("<b>Step 2: WH Questions</b>"))
    story.append(bullet("<b>What Happened?</b> (required, min 50 chars) — Large textarea with placeholder: "
        "'Describe the event clearly. What occurred? What was the outcome?'"))
    story.append(bullet("<b>When Did It Happen?</b> (required) — Date picker + time picker + option for 'Approximate' (e.g., 'Yesterday evening')."))
    story.append(bullet("<b>Where Exactly?</b> (required) — Text input for specific address/landmark. "
        "Map pin drop integration (optional)."))
    story.append(bullet("<b>Who Was Involved?</b> (required) — Textarea. Safety notice: 'Do not include names of "
        "minors or victims of sensitive crimes.'"))
    story.append(bullet("<b>Why Does This Matter?</b> (optional) — Textarea for context and significance."))
    story.append(bullet("<b>How Did It Happen?</b> (optional) — Textarea for detailed process account."))

    story.append(body("<b>Step 3: Media Upload</b>"))
    story.append(bullet("<b>Photo Upload:</b> Drag-and-drop zone. Multiple images (max 10). Auto-compress on client side. "
        "Accept: JPEG, PNG, WebP. Max 5MB per image. Thumbnail preview grid with delete option."))
    story.append(bullet("<b>Geotagging:</b> 'Add Location' button requests GPS permission and embeds coordinates in EXIF data."))
    story.append(bullet("<b>Video Upload (optional):</b> Single video file. Max 50MB. Accept: MP4, MOV. Upload progress bar."))
    story.append(bullet("<b>Captions:</b> Add caption to each uploaded photo."))

    story.append(body("<b>Step 4: Preview & Submit</b>"))
    story.append(bullet("Full preview of the article as it will appear to readers."))
    story.append(bullet("Edit button to go back and modify any section."))
    story.append(bullet("Safety reminder: 'Please ensure all information is accurate. Your identity is protected as a Citizen Reporter.'"))
    story.append(bullet("Terms acknowledgment checkbox: 'I confirm this is original reporting and I have the right to share these photos.'"))
    story.append(bullet("Submit button (accent color, large). Loading state with spinner on submit."))
    story.append(bullet("Success modal: 'Your report has been submitted! Our editors will review it within 24 hours. You earned +10 points for submission.'"))

    story.append(heading3("Additional Features"))
    story.append(bullet("<b>Auto-Save Draft:</b> Form data saved to localStorage every 30 seconds. 'Draft saved' indicator. "
        "Resume draft on next visit."))
    story.append(bullet("<b>Validation:</b> VeeValidate + Zod schema validates each field. Inline error messages appear below fields. "
        "Cannot proceed to next step until current step validates."))
    story.append(bullet("<b>Step Indicator:</b> Horizontal progress stepper at the top showing current step and completed steps."))

    # 4.4 Contributor Dashboard
    story.append(heading2("4.4 Contributor Dashboard"))
    story.append(body(
        "The contributor dashboard is a full Vue SPA page that provides contributors with an at-a-glance overview "
        "of their performance, earnings, and activity. It is the 'home base' for logged-in contributors."
    ))
    story.append(heading3("Layout Structure"))
    story.append(body("<b>1. Layout Shell</b>"))
    story.append(bullet("Left sidebar (collapsible): Navigation — Dashboard, My Submissions, Earnings, Points, Training, Profile, Settings."))
    story.append(bullet("Top bar: Page title, Quick Submit button (accent, opens submission form), Notification bell with unread count badge, User avatar dropdown."))
    story.append(bullet("Main content area: Changes based on active route (Vue Router)."))

    story.append(body("<b>2. Dashboard Home (Default View)</b>"))
    story.append(bullet("<b>Welcome Banner:</b> 'Welcome back, [Name]! You've published [N] stories this month.' Motivational message if inactive."))
    story.append(bullet("<b>Stats Cards Row (4 cards):</b>"))
    story.append(sub_bullet("Total Submissions: number + trend arrow (vs last month)."))
    story.append(sub_bullet("Published: number + percentage of total."))
    story.append(sub_bullet("Points Earned: number + level indicator (e.g., 'Gold — 350/500 to Platinum')."))
    story.append(sub_bullet("Total Earnings: formatted currency + 'Withdraw' button."))
    story.append(bullet("<b>Earnings Chart:</b> Bar/line chart showing monthly earnings for the last 6 months. Toggle between earnings and submissions."))
    story.append(bullet("<b>Recent Submissions:</b> Table with last 5 submissions — Title, Status (badge), Date, Points Earned, Actions (View/Edit)."))
    story.append(bullet("<b>Profile Completion Progress:</b> Progress bar showing completion % (avatar, bio, phone, bank details). "
        "'Complete your profile' CTA if incomplete."))
    story.append(bullet("<b>Activity Feed:</b> Recent events — 'Your article was published (+50 pts)', 'New comment on your article', 'Payment of $X processed'."))

    story.append(body("<b>3. My Submissions View</b>"))
    story.append(bullet("Data table with columns: Title, Category, Status, Date, Points, Actions."))
    story.append(bullet("Filter by: Status (All, Pending, Published, Rejected), Category, Date Range."))
    story.append(bullet("Search by title. Pagination (20 per page)."))
    story.append(bullet("Clicking a row opens Submission Detail slide-over panel showing: full article preview, editor notes, status timeline."))

    story.append(body("<b>4. Earnings View</b>"))
    story.append(bullet("Summary cards: This Month, Last Month, Total Earned, Available for Withdrawal."))
    story.append(bullet("Earnings chart (line chart, 12 months)."))
    story.append(bullet("Transaction history table: Date, Description (e.g., 'Article: Flood in Gazipur'), Amount, Status (Paid/Pending)."))
    story.append(bullet("'Request Payout' button: Opens modal with bank details form and minimum amount notice."))

    # 4.5 Training Course / LMS
    story.append(heading2("4.5 Training Course / LMS"))
    story.append(body(
        "The Training Course (LMS) is a full Vue SPA that trains new contributors in responsible journalism "
        "practices. Completion is required before a user can submit news. The course consists of 6 modules, "
        "each with video content, text lessons, and a quiz."
    ))
    story.append(heading3("Course Structure (6 Modules)"))
    story.append(bullet("<b>Module 1:</b> Introduction to Citizen Journalism — What it is, why it matters, ethics."))
    story.append(bullet("<b>Module 2:</b> News Gathering & the WH Method — How to report events using What/When/Where/Who/Why/How."))
    story.append(bullet("<b>Module 3:</b> Photography & Media — Taking good photos, video basics, geotagging, consent."))
    story.append(bullet("<b>Module 4:</b> Writing for News — Clear, concise writing, headlines, avoiding bias, fact-checking."))
    story.append(bullet("<b>Module 5:</b> Safety & Legal Considerations — Personal safety, legal risks, defamation, privacy."))
    story.append(bullet("<b>Module 6:</b> Platform Usage & Guidelines — How to use the submission form, points system, payouts."))

    story.append(heading3("Course Overview Page"))
    story.append(bullet("Course header with title, description, total duration estimate, instructor info."))
    story.append(bullet("Overall progress bar (e.g., '3 of 6 modules complete — 50%')."))
    story.append(bullet("Module list: Each module shown as a card with:"))
    story.append(sub_bullet("Module number and title."))
    story.append(sub_bullet("Estimated duration (e.g., '45 min')."))
    story.append(sub_bullet("Status icon: Locked (gray), In Progress (amber), Completed (green checkmark)."))
    story.append(sub_bullet("Progress bar within the module (video watched %, quiz score)."))
    story.append(bullet("'Continue Learning' button linking to the next incomplete module."))

    story.append(heading3("Module View Page"))
    story.append(bullet("<b>Video Section:</b> Embedded video player (Vimeo/YouTube embed or self-hosted via Mux). "
        "Progress tracking: auto-save video position, resume from last position."))
    story.append(bullet("<b>Text Content:</b> Markdown-rendered lesson content below the video. Images, bullet points, code examples."))
    story.append(bullet("<b>Key Takeaways Box:</b> Highlighted summary box at the end of each lesson."))
    story.append(bullet("<b>Navigation:</b> 'Previous Lesson' / 'Next Lesson' buttons. Module progress indicator (Step 2 of 5)."))
    story.append(bullet("<b>Mark as Complete:</b> Button to manually mark lesson complete (in addition to video progress)."))

    story.append(heading3("Quiz System"))
    story.append(bullet("10-15 questions per module quiz. Mix of:"))
    story.append(sub_bullet("Multiple Choice (single correct answer)."))
    story.append(sub_bullet("Multiple Select (multiple correct answers)."))
    story.append(sub_bullet("WH-Question Practice (fill in the blank for What/When/Where/Who/Why/How given a scenario)."))
    story.append(bullet("Timer: 20 minutes per quiz. Countdown display with warning at 5 minutes."))
    story.append(bullet("Question navigation: Sidebar with numbered buttons (answered, current, unanswered states)."))
    story.append(bullet("Auto-submit when timer expires."))
    story.append(bullet("Results page: Score (percentage), pass/fail (70% pass threshold), correct answers review, explanation for each answer."))
    story.append(bullet("Retake option: Up to 3 attempts. Must wait 24 hours between retakes."))
    story.append(bullet("On passing all 6 module quizzes: Certificate generated and available for download."))

    story.append(heading3("Certificate"))
    story.append(bullet("Beautiful certificate layout with: contributor name (full name, not anonymous), course title, completion date, unique certificate ID."))
    story.append(bullet("PDF download via client-side generation (jsPDF) or server-side API."))
    story.append(bullet("Share on social media: pre-populated share text with certificate image."))
    story.append(bullet("Certificate verification: Public URL to verify certificate authenticity."))
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 5: COMPONENT HIERARCHY & DATA FLOW
    # ══════════════════════════════════════════════
    story.append(heading1("5. Component Hierarchy & Data Flow"))
    story.append(hr())

    story.append(heading2("5.1 Astro to Vue Island Data Passing"))
    story.append(body(
        "Astro pages serve as the server-rendered shell, and Vue islands receive their initial data through props. "
        "This is a fundamental pattern in the Islands Architecture. The Astro component fetches data server-side "
        "and passes it as serializable props to the Vue island component."
    ))
    story.append(heading3("Example: Article Page with Comment Island"))
    story.append(code_block(
        "---\n"
        "// src/pages/news/[slug].astro\n"
        "import CommentSection from '../components/vue/CommentSection.vue';\n"
        "import PhotoGallery from '../components/vue/PhotoGallery.vue';\n"
        "\n"
        "const { slug } = Astro.params;\n"
        "const response = await fetch(`${API_BASE}/news/${slug}/`);\n"
        "const article = await response.json();\n"
        "\n"
        "export function getHead() {\n"
        "  return { title: `${article.title} | Platform Name` };\n"
        "}\n"
        "---\n"
        "\n"
        "<BaseLayout>\n"
        "  <article>\n"
        "    <h1>{article.title}</h1>\n"
        "    <p>{article.excerpt}</p>\n"
        "    <div>{article.body}</div>\n"
        "    <!-- Vue Island: hydrates on visible -->\n"
        "    <PhotoGallery\n"
        "      client:visible\n"
        "      images={article.images}\n"
        "      articleSlug={slug}\n"
        "    />\n"
        "    <!-- Vue Island: hydrates on visible -->\n"
        "    <CommentSection\n"
        "      client:visible\n"
        "      articleId={article.id}\n"
        "      initialComments={article.comments}\n"
        "      commentCount={article.comment_count}\n"
        "    />\n"
        "  </article>\n"
        "</BaseLayout>"
    ))
    story.append(body(
        "In this pattern, <font face='Courier'>article</font> data is fetched server-side and passed to both Astro "
        "template expressions and Vue island props. The <font face='Courier'>client:visible</font> directive ensures "
        "the Vue components only hydrate when they scroll into the viewport, saving initial JavaScript payload."
    ))

    story.append(heading2("5.2 Pinia Store Design"))
    story.append(body(
        "Pinia stores manage client-side state for Vue islands and SPA pages. Each store corresponds to a domain "
        "area and communicates with the Django Ninja API through the shared HTTP client."
    ))
    story.append(heading3("Store Inventory"))
    store_headers = ["Store", "File", "State", "Actions", "Used By"]
    store_rows = [
        ["Auth Store", "stores/auth.ts", "user, isAuthenticated,\ntoken, loading", "login, logout, register,\nrefreshToken, fetchProfile,\nupdateProfile", "All auth-required\npages and islands"],
        ["News Store", "stores/news.ts", "articles[], currentArticle,\npagination, filters,\nloading", "fetchArticles, fetchArticle,\nsearchNews, submitArticle,\nuploadPhotos", "News listing, article\npage, submission form"],
        ["Contributor\nStore", "stores/\ncontributor.ts", "profile, stats, submissions[],\nearnings, points, level,\nnotifications[]", "fetchDashboard, fetchSubmissions,\nrequestPayout, fetchPoints,\nmarkNotificationRead", "Contributor\ndashboard SPA"],
        ["Course Store", "stores/course.ts", "modules[], currentModule,\nprogress, quizResults[],\ncertificate", "fetchModules, startModule,\ncompleteLesson, submitQuiz,\ndownloadCertificate", "Training LMS SPA"],
        ["Admin Store", "stores/admin.ts", "dashboardStats, queue[],\nusers[], courses[],\npayouts[], analytics", "fetchQueue, approveArticle,\nrejectArticle, fetchUsers,\nmanageCourse, processPayout", "Admin panel SPA"],
        ["UI Store", "stores/ui.ts", "sidebarOpen, theme,\ntoast[], modal, searchOpen", "toggleSidebar, setTheme,\nshowToast, openModal,\ncloseModal", "Global — layout\nand overlays"],
    ]
    t = make_table(store_headers, store_rows, col_widths=[0.8*inch, 0.95*inch, 1.45*inch, 1.5*inch, 1.0*inch])
    story.append(t)

    story.append(heading2("5.3 Pinia Store Example"))
    story.append(code_block(
        "// src/stores/contributor.ts\n"
        "import { defineStore } from 'pinia';\n"
        "import { api } from '../lib/api';\n"
        "\n"
        "interface ContributorState {\n"
        "  stats: {\n"
        "    totalSubmissions: number;\n"
        "    published: number;\n"
        "    pending: number;\n"
        "    points: number;\n"
        "    earnings: number;\n"
        "  } | null;\n"
        "  submissions: Submission[];\n"
        "  loading: boolean;\n"
        "}\n"
        "\n"
        "export const useContributorStore = defineStore('contributor', {\n"
        "  state: (): ContributorState => ({\n"
        "    stats: null,\n"
        "    submissions: [],\n"
        "    loading: false,\n"
        "  }),\n"
        "  actions: {\n"
        "    async fetchDashboard() {\n"
        "      this.loading = true;\n"
        "      try {\n"
        "        const [statsRes, submissionsRes] = await Promise.all([\n"
        "          api.get('contributor/dashboard/stats/'),\n"
        "          api.get('contributor/submissions/?page=1'),\n"
        "        ]);\n"
        "        this.stats = statsRes.data;\n"
        "        this.submissions = submissionsRes.data.results;\n"
        "      } finally {\n"
        "        this.loading = false;\n"
        "      }\n"
        "    },\n"
        "  },\n"
        "});"
    ))

    story.append(heading2("5.4 API Integration Pattern"))
    story.append(body(
        "All API calls go through a centralized HTTP client (<font face='Courier'>src/lib/api.ts</font>) built on "
        "top of ky or ofetch. The client handles authentication, CSRF, error transformation, and request/response "
        "interceptors."
    ))
    story.append(code_block(
        "// src/lib/api.ts\n"
        "import ky from 'ky';\n"
        "\n"
        "export const api = ky.create({\n"
        "  prefixUrl: import.meta.env.PUBLIC_API_URL || '/api/v1',\n"
        "  timeout: 30000,\n"
        "  hooks: {\n"
        "    beforeRequest: [\n"
        "      (request) => {\n"
        "        // Attach CSRF token from cookie\n"
        "        const csrf = document.cookie\n"
        "          .match(/csrftoken=([^;]+)/)?.[1];\n"
        "        if (csrf) request.headers.set('X-CSRFToken', csrf);\n"
        "      },\n"
        "    ],\n"
        "    afterResponse: [\n"
        "      async (request, _opts, response) => {\n"
        "        if (response.status === 401) {\n"
        "          // Attempt token refresh\n"
        "          const refreshed = await refreshToken();\n"
        "          if (refreshed) return ky(request);\n"
        "        }\n"
        "      },\n"
        "    ],\n"
        "  },\n"
        "});"
    ))

    story.append(heading2("5.5 Error Handling Strategy"))
    story.append(bullet("<b>API Errors:</b> The HTTP client intercepts non-2xx responses and throws typed error objects "
        "with status code, message, and field-level validation errors. Components catch these in try/catch blocks "
        "and display appropriate user feedback via the toast system."))
    story.append(bullet("<b>Form Validation Errors:</b> VeeValidate + Zod handle client-side validation before submission. "
        "Server-side validation errors (422) are mapped back to form fields and displayed inline."))
    story.append(bullet("<b>Network Errors:</b> A global error boundary catches unexpected errors and shows a user-friendly "
        "error page with a retry button. Offline state is detected and a 'You are offline' banner is displayed."))
    story.append(bullet("<b>Toast Notifications:</b> The UI store manages a toast queue. Success messages auto-dismiss after 5s, "
        "error messages persist until dismissed. Maximum 3 toasts visible simultaneously."))

    story.append(heading2("5.6 Loading States Strategy"))
    story.append(bullet("<b>Skeleton Screens:</b> Content areas show animated skeleton placeholders while data is loading. "
        "Each major component has a corresponding skeleton variant (NewsCardSkeleton, TableSkeleton, etc.)."))
    story.append(bullet("<b>Button Loading:</b> Submit/action buttons show a spinner icon and disable further clicks during async operations."))
    story.append(bullet("<b>Route Loading:</b> The SPA router shows a top progress bar (NProgress-style) during navigation."))
    story.append(bullet("<b>Optimistic Updates:</b> For non-critical actions (like, bookmark), the UI updates immediately and "
        "rolls back if the API call fails."))
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 6: PERFORMANCE OPTIMIZATION
    # ══════════════════════════════════════════════
    story.append(heading1("6. Performance Optimization"))
    story.append(hr())
    story.append(body(
        "Performance is critical for a news platform. Readers expect instant page loads, and search engines "
        "prioritize fast sites. The Astro Islands Architecture already provides a strong foundation by shipping "
        "zero JavaScript by default. This section outlines additional optimization strategies."
    ))

    story.append(heading2("6.1 Image Optimization"))
    story.append(bullet("<b>Astro Image Component:</b> Use <font face='Courier'>&lt;Image /&gt;</font> from "
        "<font face='Courier'>astro:assets</font> for automatic format conversion (WebP/AVIF), responsive srcset, "
        "and lazy loading. All images are optimized at build time."))
    story.append(bullet("<b>Responsive Images:</b> Every image includes srcset with sizes for 320w, 640w, 768w, 1024w, 1280w. "
        "The sizes attribute is set based on the image's layout context."))
    story.append(bullet("<b>Lazy Loading:</b> Images below the fold use <font face='Courier'>loading='lazy'</font>. "
        "Above-the-fold hero images use <font face='Courier'>loading='eager'</font> with explicit width/height to prevent CLS."))
    story.append(bullet("<b>User-Uploaded Images:</b> Contributor photos are processed server-side (Django) to generate "
        "multiple sizes and WebP/AVIF formats. The CDN serves the appropriate variant based on the client's Accept header."))
    story.append(bullet("<b>Blur Placeholder:</b> Low-quality image placeholders (LQIP) — 20px blurred base64 — are "
        "embedded inline for above-the-fold images to eliminate layout shift."))

    story.append(heading2("6.2 Code Splitting"))
    story.append(bullet("<b>Astro Automatic:</b> Astro automatically code-splits Vue island components. Each island is "
        "a separate chunk that loads independently. Only the islands present on the current page are downloaded."))
    story.append(bullet("<b>Vue Router Lazy Loading:</b> SPA route components use <font face='Courier'>() => import('./views/...')</font> "
        "for dynamic imports. Admin, dashboard, and course routes are split into separate chunks."))
    story.append(bullet("<b>Third-Party Splitting:</b> Heavy dependencies (chart libraries, PDF generators, rich text editors) "
        "are loaded asynchronously only when needed."))
    story.append(bullet("<b>Shared Chunk Deduplication:</b> Vue, Pinia, and other shared dependencies are extracted into "
        "a common chunk that is cached long-term."))

    story.append(heading2("6.3 Font Loading Strategy"))
    story.append(bullet("<b>Font Display: Swap:</b> All Google Fonts use <font face='Courier'>font-display: swap</font> "
        "to prevent invisible text during font loading."))
    story.append(bullet("<b>Preconnect:</b> <font face='Courier'>&lt;link rel='preconnect' href='https://fonts.googleapis.com'&gt;</font> "
        "and <font face='Courier'>&lt;link rel='preconnect' href='https://fonts.gstatic.com' crossorigin&gt;</font> in the head."))
    story.append(bullet("<b>Subset:</b> Load only Latin and Bengali character subsets to reduce font file size."))
    story.append(bullet("<b>Self-Hosting (Optional):</b> For maximum performance, self-host font files and serve them "
        "from the CDN with appropriate cache headers."))

    story.append(heading2("6.4 Caching Strategy"))
    story.append(bullet("<b>Static Assets:</b> Hashed filenames with <font face='Courier'>Cache-Control: public, max-age=31536000, immutable</font>."))
    story.append(bullet("<b>HTML Pages:</b> <font face='Courier'>Cache-Control: public, max-age=0, s-maxage=300, stale-while-revalidate=600</font> "
        "for SSR pages. Edge cache serves stale content while revalidating."))
    story.append(bullet("<b>API Responses:</b> Browser does not cache API responses (authenticated). CDN caching is disabled for API routes."))
    story.append(bullet("<b>Service Worker (PWA):</b> Consider a service worker for offline caching of read content "
        "and form drafts. This is a future enhancement, not in the initial scope."))

    story.append(heading2("6.5 Bundle Size Targets"))
    bundle_headers = ["Metric", "Target", "Measurement"]
    bundle_rows = [
        ["Homepage JS (total)", "< 50 KB gzipped", "Lighthouse / WebPageTest"],
        ["Individual Island JS", "< 30 KB gzipped", "Astro build output"],
        ["SPA Initial Bundle", "< 120 KB gzipped", "Webpack Analyzer"],
        ["Full SPA (all routes)", "< 300 KB gzipped (lazy)", "Build output analysis"],
        ["CSS (total, critical)", "< 20 KB gzipped", "Tailwind purge + critical extraction"],
        ["Font Files (total)", "< 100 KB", "Google Fonts (subset)"],
        ["Largest Contentful Paint", "< 2.5 seconds", "Lighthouse (mobile)"],
        ["First Input Delay", "< 100 ms", "Lighthouse (mobile)"],
        ["Cumulative Layout Shift", "< 0.1", "Lighthouse (mobile)"],
    ]
    t = make_table(bundle_headers, bundle_rows, col_widths=[1.8*inch, 1.6*inch, 2.1*inch])
    story.append(t)
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 7: SECURITY ON FRONTEND
    # ══════════════════════════════════════════════
    story.append(heading1("7. Security on Frontend"))
    story.append(hr())
    story.append(body(
        "While the Django backend is the primary security boundary, the frontend must implement several "
        "security measures to protect users and the platform. This is especially important for a citizen "
        "journalism platform where contributor safety and content integrity are paramount."
    ))

    story.append(heading2("7.1 CSRF Protection"))
    story.append(body(
        "All mutating API requests (POST, PUT, PATCH, DELETE) must include a CSRF token in the "
        "<font face='Courier'>X-CSRFToken</font> header. The Django backend sets the CSRF token as a cookie "
        "(<font face='Courier'>csrftoken</font>). The centralized API client reads this cookie and attaches "
        "the token to every request. For SSR pages, Astro reads the cookie from the request and passes it to "
        "the client via a secure mechanism (e.g., a meta tag or inline script in the head)."
    ))

    story.append(heading2("7.2 XSS Prevention"))
    story.append(bullet("<b>Template Escaping:</b> Astro templates auto-escape HTML by default. Vue's "
        "<font face='Courier'>{{ }}</font> interpolation also auto-escapes. Raw HTML is only rendered via "
        "<font face='Courier'>v-html</font> with explicit sanitization using DOMPurify."))
    story.append(bullet("<b>Content Sanitization:</b> All user-generated content (article body, comments, form input) "
        "is sanitized with DOMPurify before rendering. The sanitizer allows only a whitelist of safe HTML tags "
        "(p, br, strong, em, ul, ol, li, blockquote, img, a) and strips all attributes except src, href, and alt."))
    story.append(bullet("<b>URL Sanitization:</b> All user-provided URLs (links, image sources) are validated against a "
        " whitelist of allowed protocols (http, https) and domains. JavaScript: URLs are rejected."))
    story.append(bullet("<b>CSP Headers:</b> Content Security Policy headers restrict script sources, style sources, "
        "image sources, and connect sources. Inline scripts are disallowed (nonce-based exceptions for Astro)."))

    story.append(heading2("7.3 Secure File Upload (Client Side)"))
    story.append(bullet("<b>File Type Validation:</b> Client-side MIME type checking and file extension whitelist. "
        "Accepted image types: image/jpeg, image/png, image/webp. Accepted video types: video/mp4, video/quicktime."))
    story.append(bullet("<b>File Size Limits:</b> Client-side validation: images max 5MB, videos max 50MB. The upload "
        "component rejects files exceeding the limit before upload."))
    story.append(bullet("<b>Image Compression:</b> Client-side image compression using the browser's Canvas API or "
        "a library like browser-image-compression. Reduces file size by up to 70% before upload."))
    story.append(bullet("<b>EXIF Stripping:</b> GPS coordinates from EXIF data are extracted for geotagging (if user opts in) "
        "and then stripped before upload to protect contributor location privacy."))
    story.append(bullet("<b>Virus Scanning:</b> Not possible client-side, but the backend API performs virus scanning on all uploads."))

    story.append(heading2("7.4 Content Security Policy"))
    story.append(body(
        "A strict Content Security Policy is enforced via HTTP headers (set by the backend or CDN):"
    ))
    story.append(code_block(
        "Content-Security-Policy:\n"
        "  default-src 'self';\n"
        "  script-src 'self' 'nonce-{random}' https://cdn.jsdelivr.net;\n"
        "  style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;\n"
        "  img-src 'self' data: https: blob:;\n"
        "  font-src 'self' https://fonts.gstatic.com;\n"
        "  connect-src 'self' https://api.example.com;\n"
        "  frame-src https://player.vimeo.com https://www.youtube.com;\n"
        "  object-src 'none';\n"
        "  base-uri 'self';\n"
        "  form-action 'self';"
    ))

    story.append(heading2("7.5 Authentication Token Management"))
    story.append(bullet("<b>httpOnly Cookies:</b> Access and refresh tokens are stored as httpOnly, Secure, SameSite=Strict "
        "cookies. JavaScript cannot access them, preventing XSS-based token theft."))
    story.append(bullet("<b>Token Refresh:</b> The API client transparently handles access token expiry. On a 401 response, "
        "it calls the refresh endpoint using the refresh token cookie. If refresh fails, the user is redirected to login."))
    story.append(bullet("<b>Session Timeout:</b> Access tokens expire after 15 minutes. Refresh tokens expire after 7 days "
        "(configurable). Inactive users are logged out after 30 days."))
    story.append(bullet("<b>Concurrent Sessions:</b> Backend manages session invalidation. Only one active session per user. "
        "Login from a new device invalidates the previous session."))

    story.append(heading2("7.6 Contributor Identity Protection"))
    story.append(body(
        "Protecting the identity of citizen journalists is a core safety requirement:"
    ))
    story.append(bullet("Articles display 'Citizen Reporter from [District]' instead of real names by default."))
    story.append(bullet("Contributors can opt in to display their public profile name."))
    story.append(bullet("EXIF GPS data from uploaded photos is stripped before storage."))
    story.append(bullet("IP addresses are never exposed to other users, even admins (only shown for security purposes)."))
    story.append(bullet("The submission form includes a safety reminder about not including identifying information."))
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 8: DEPLOYMENT & INFRASTRUCTURE
    # ══════════════════════════════════════════════
    story.append(heading1("8. Deployment & Infrastructure"))
    story.append(hr())

    story.append(heading2("8.1 Build Process"))
    story.append(body(
        "The Astro build process generates both static assets and server-rendered pages. The build is configured "
        "in <font face='Courier'>astro.config.mjs</font> with hybrid rendering mode."
    ))
    story.append(code_block(
        "// astro.config.mjs\n"
        "import { defineConfig } from 'astro/config';\n"
        "import vue from '@astrojs/vue';\n"
        "import tailwind from '@astrojs/tailwind';\n"
        "\n"
        "export default defineConfig({\n"
        "  output: 'hybrid',    // Static + Server\n"
        "  adapter: 'vercel',   // or 'netlify', '@astrojs/cloudflare'\n"
        "  integrations: [\n"
        "    vue(),\n"
        "    tailwind(),\n"
        "  ],\n"
        "  build: {\n"
        "    inlineStylesheets: 'auto',\n"
        "  },\n"
        "  vite: {\n"
        "    build: {\n"
        "      rollupOptions: {\n"
        "        output: {\n"
        "          manualChunks: {\n"
        "            'vue-vendor': ['vue', 'vue-router', 'pinia'],\n"
        "          },\n"
        "        },\n"
        "      },\n"
        "    },\n"
        "  },\n"
        "});"
    ))
    story.append(body("<b>Build Outputs:</b>"))
    story.append(bullet("Static HTML files for SSG pages (articles, categories, districts)."))
    story.append(bullet("Serverless functions for SSR pages (homepage, news listing, search)."))
    story.append(bullet("JavaScript chunks for Vue islands and SPA routes (hashed filenames)."))
    story.append(bullet("CSS bundle (Tailwind purged, critical CSS extracted)."))
    story.append(bullet("Optimized images (WebP/AVIF variants, responsive srcset)."))

    story.append(heading2("8.2 Recommended Hosting"))
    story.append(body(
        "The frontend is deployed as a serverless application. The recommended hosting options are:"
    ))
    host_headers = ["Provider", "Adapter", "Pros", "Cons", "Recommendation"]
    host_rows = [
        ["Vercel", "@astrojs/vercel", "Excellent Astro support,\nEdge functions, preview\ndeployments, fast CDN", "Vendor lock-in, cold\nstarts on hobby plan", "Primary choice —\nbest Astro DX"],
        ["Netlify", "@astrojs/netlify", "Good Astro support,\nform handling, edge\nfunctions, deploy previews", "Slightly slower build\ntimes than Vercel", "Excellent\nalternative"],
        ["Cloudflare\nPages", "@astrojs/cloudflare", "Global edge network,\nvery fast, Workers\nintegration, generous free tier", "Newer Astro adapter,\nless mature tooling", "Best for global\nreach / cost"],
    ]
    t = make_table(host_headers, host_rows, col_widths=[0.85*inch, 1.15*inch, 1.55*inch, 1.35*inch, 1.15*inch])
    story.append(t)

    story.append(heading2("8.3 CDN Strategy"))
    story.append(bullet("<b>Static Assets:</b> Hosted on the platform's CDN (Vercel/Netlify/Cloudflare). Global edge caching with immutable headers."))
    story.append(bullet("<b>User Images:</b> Stored in cloud storage (AWS S3 or Cloudflare R2) behind a CDN. Processed images served via an image CDN (Cloudinary or imgix) for on-the-fly resizing and format conversion."))
    story.append(bullet("<b>API:</b> Django backend deployed behind a separate CDN/reverse proxy (Cloudflare or AWS CloudFront). API routes are not cached by the frontend CDN."))

    story.append(heading2("8.4 Environment Variables"))
    story.append(body("Environment variables are managed through the hosting platform's dashboard and CLI. "
        "Key variables include:"))
    story.append(bullet("<font face='Courier'>PUBLIC_API_URL</font> — Django Ninja API base URL."))
    story.append(bullet("<font face='Courier'>PUBLIC_SITE_URL</font> — Frontend base URL (for SEO, sitemap)."))
    story.append(bullet("<font face='Courier'>PUBLIC_GOOGLE_MAPS_KEY</font> — Google Maps API key (for district map)."))
    story.append(bullet("<font face='Courier'>PUBLIC_VIMEO_TOKEN</font> — Vimeo API token (for course videos)."))
    story.append(bullet("<font face='Courier'>PUBLIC_ANALYTICS_ID</font> — Google Analytics / Plausible analytics ID."))
    story.append(note(
        "<b>Important:</b> Variables prefixed with <font face='Courier'>PUBLIC_</font> are exposed to the client. "
        "Secret values (API keys, secrets) must NEVER have the <font face='Courier'>PUBLIC_</font> prefix and "
        "are only available server-side in Astro's SSR context."
    ))

    story.append(heading2("8.5 CI/CD Pipeline"))
    story.append(body("The CI/CD pipeline is automated via GitHub Actions:"))
    story.append(bullet("<b>On Pull Request:</b> Lint (ESLint + Prettier), type check (vue-tsc), unit tests (Vitest), "
        "build verification, Lighthouse CI audit (performance, accessibility, SEO, best practices)."))
    story.append(bullet("<b>On Merge to main:</b> All PR checks + deploy to production."))
    story.append(bullet("<b>Preview Deployments:</b> Every PR gets a unique preview URL (e.g., <font face='Courier'>pr-123.platform.com</font>) "
        "for review and testing."))
    story.append(bullet("<b>Staging Environment:</b> The <font face='Courier'>develop</font> branch auto-deploys to a staging environment "
        "that mirrors production configuration."))

    story.append(heading2("8.6 Monitoring & Observability"))
    story.append(bullet("<b>Error Tracking:</b> Sentry integration for client-side and server-side error monitoring. Source maps uploaded for readable stack traces."))
    story.append(bullet("<b>Analytics:</b> Plausible Analytics (privacy-focused) or Google Analytics for traffic analysis."))
    story.append(bullet("<b>Performance:</b> Vercel/Netlify Analytics or Web Vitals library for Core Web Vitals monitoring."))
    story.append(bullet("<b>Uptime:</b> UptimeRobot or BetterUptime for availability monitoring with Slack alerts."))
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 9: DEVELOPMENT ROADMAP
    # ══════════════════════════════════════════════
    story.append(heading1("9. Development Roadmap"))
    story.append(hr())
    story.append(body(
        "The development roadmap is organized into 7 phases spanning 24 weeks. Each phase includes specific "
        "deliverables, dependencies, and success criteria. The roadmap follows an incremental delivery model, "
        "ensuring that each phase produces a functional, testable increment of the platform."
    ))
    story.append(spacer(6))

    story.append(heading2("Phase 1: Foundation (Weeks 1-3)"))
    phase1_headers = ["Week", "Task", "Deliverable", "Dependencies"]
    phase1_rows = [
        ["1", "Project setup: Astro 5.x + Vue 3 +\nTailwind 4.x + Vite + Pinia", "Running project with dev server,\nHello World page", "None"],
        ["1", "Design system: color tokens, typography,\nspacing, global CSS", "Tailwind config, global.css,\nfont imports", "None"],
        ["1-2", "Base UI components: Button, Input, Card,\nBadge, Modal, Toast, Skeleton", "Component library with\nstorybook/docs", "Design system"],
        ["2", "Layouts: BaseLayout (header+footer),\nDashboardLayout, AdminLayout", "Reusable page layouts\nwith responsive nav", "UI components"],
        ["2-3", "API client: ky/ofetch wrapper, auth\ninterceptors, error handling", "lib/api.ts with login,\nrefresh, error types", "None"],
        ["3", "Pinia stores: auth, news, UI stores\nwith TypeScript interfaces", "Type-safe stores with\nAPI integration", "API client"],
        ["3", "CI/CD: GitHub Actions, linting,\ntesting setup, preview deploys", "Automated pipeline on\npull requests", "Project setup"],
    ]
    t = make_table(phase1_headers, phase1_rows, col_widths=[0.5*inch, 2.2*inch, 1.8*inch, 1.5*inch])
    story.append(t)
    story.append(spacer(8))

    story.append(heading2("Phase 2: Public Pages (Weeks 4-6)"))
    phase2_headers = ["Week", "Task", "Deliverable", "Dependencies"]
    phase2_rows = [
        ["4", "Homepage: hero, news grid, category nav,\ntrending, CTA banner, footer", "Fully functional homepage\nwith mock data", "Phase 1"],
        ["4-5", "News listing page: pagination, filters\n(category/district/date), search", "Filterable, paginated\nnews listing", "Homepage"],
        ["5", "Single article page: full content,\nphoto gallery, related stories", "Article page with Vue\nislands (gallery, share)", "News listing"],
        ["5-6", "Category and district pages with\nnews grids and breadcrumbs", "Dynamic category/district\npages (SSG)", "Article page"],
        ["6", "Search page: full-text search UI with\nresults and filters", "Search page (Vue island\nfor search bar)", "News listing"],
        ["6", "About, Contact, Contribute pages\n(static content + contact form island)", "Informational pages\nwith contact form", "Phase 1"],
    ]
    t = make_table(phase2_headers, phase2_rows, col_widths=[0.5*inch, 2.2*inch, 1.8*inch, 1.5*inch])
    story.append(t)
    story.append(spacer(8))

    story.append(heading2("Phase 3: Auth & Submission (Weeks 7-9)"))
    phase3_headers = ["Week", "Task", "Deliverable", "Dependencies"]
    phase3_rows = [
        ["7", "Login page: email/password form, social\nlogin, forgot password, error states", "Functional login with\ntoken management", "Phase 1, Backend API"],
        ["7", "Register page: multi-step form, role\nselection, validation, email verification", "Registration flow with\nemail verification", "Auth system"],
        ["7-8", "Auth middleware: route guards,\nprotected routes, session management", "Auth-aware routing for\nall protected pages", "Login/Register"],
        ["8", "News submission form: WH-question\nwizard, step indicator, validation", "4-step submission form\nwith draft auto-save", "Auth, API client"],
        ["8-9", "Photo upload: drag-and-drop, multiple\nfiles, compression, preview, captions", "Integrated photo upload\nwith EXIF handling", "Submission form"],
        ["9", "User profile page: edit profile,\navatar upload, notification preferences", "Profile management page\nwith all settings", "Auth system"],
        ["9", "Notification center: notification list,\nread/unread, mark all read, filters", "Functional notification\nsystem", "Auth, Backend API"],
    ]
    t = make_table(phase3_headers, phase3_rows, col_widths=[0.5*inch, 2.2*inch, 1.8*inch, 1.5*inch])
    story.append(t)
    story.append(spacer(8))

    story.append(heading2("Phase 4: Contributor Features (Weeks 10-13)"))
    phase4_headers = ["Week", "Task", "Deliverable", "Dependencies"]
    phase4_rows = [
        ["10", "SPA shell: dashboard layout with sidebar,\nVue Router setup, route guards", "Dashboard SPA mounted\nand navigable", "Phase 1, Auth"],
        ["10-11", "Dashboard home: stat cards, earnings\nchart, recent submissions, activity feed", "Dashboard overview with\nlive data from API", "SPA shell, Backend API"],
        ["11", "My Submissions: data table with status\nbadges, filters, search, pagination", "Submissions management\npage", "Dashboard home"],
        ["11-12", "Submission detail: slide-over panel,\neditor notes, status timeline", "Detailed submission view\nwith history", "My Submissions"],
        ["12", "Earnings page: summary cards, chart,\ntransaction history, payout request", "Earnings management\nwith payout flow", "Dashboard home, API"],
        ["12-13", "Points system: points history, level\nprogress, animation, gamification UI", "Points and gamification\ndisplay", "Dashboard home"],
        ["13", "Contributor public profile page:\nstats, bio, published articles list", "Public profile URL\nfor contributors", "Phase 2"],
    ]
    t = make_table(phase4_headers, phase4_rows, col_widths=[0.5*inch, 2.2*inch, 1.8*inch, 1.5*inch])
    story.append(t)
    story.append(spacer(8))

    story.append(heading2("Phase 5: LMS (Weeks 14-17)"))
    phase5_headers = ["Week", "Task", "Deliverable", "Dependencies"]
    phase5_rows = [
        ["14", "SPA shell: course layout with progress\nsidebar, Vue Router, module routing", "Course SPA with\nmodule navigation", "Phase 1, Auth"],
        ["14-15", "Course overview: module list, progress\nbars, status indicators, continue button", "Course overview page\nwith progress tracking", "SPA shell, Backend"],
        ["15", "Module view: video player (Vimeo/Mux),\ntext content, markdown rendering", "Module lesson page\nwith video player", "Course overview"],
        ["15-16", "Progress tracking: video position,\nlesson completion, auto-save", "Lesson progress persistence\nacross sessions", "Module view, API"],
        ["16-17", "Quiz system: MCQ, WH-practice, timer,\nauto-grading, results, retake logic", "Full quiz engine with\nscoring and feedback", "Module view, API"],
        ["17", "Certificate: PDF generation, download,\nsocial sharing, verification URL", "Certificate generation\nand sharing", "Quiz system, API"],
    ]
    t = make_table(phase5_headers, phase5_rows, col_widths=[0.5*inch, 2.2*inch, 1.8*inch, 1.5*inch])
    story.append(t)
    story.append(spacer(8))

    story.append(heading2("Phase 6: Admin Panel (Weeks 18-21)"))
    phase6_headers = ["Week", "Task", "Deliverable", "Dependencies"]
    phase6_rows = [
        ["18", "SPA shell: admin layout with sidebar,\nVue Router, admin auth guard", "Admin SPA with\nrole-based access", "Phase 1, Auth"],
        ["18-19", "Admin dashboard: stats cards, charts,\npending queue preview, activity feed", "Admin overview with\nreal-time metrics", "SPA shell, API"],
        ["19", "Editorial queue: submissions list,\ninline review, edit, approve/reject", "Content review workflow", "Admin dashboard"],
        ["19-20", "User management: user list, roles,\nban/unban, search, filter", "User administration\ninterface", "Admin dashboard"],
        ["20", "Course management: module editor,\nquiz builder, content upload, reorder", "Course authoring\ninterface", "Admin SPA, LMS data"],
        ["20-21", "Payout management: pending requests,\napprove/reject, bulk actions, export", "Financial admin\ninterface", "Admin dashboard"],
        ["21", "Reports & Analytics: traffic charts,\nsubmission stats, revenue, export", "Analytics dashboard\nwith data export", "Admin dashboard, API"],
        ["21", "Content management: categories, districts,\ntags, platform settings", "Platform configuration\ninterface", "Admin SPA"],
    ]
    t = make_table(phase6_headers, phase6_rows, col_widths=[0.5*inch, 2.2*inch, 1.8*inch, 1.5*inch])
    story.append(t)
    story.append(spacer(8))

    story.append(heading2("Phase 7: Polish & Launch (Weeks 22-24)"))
    phase7_headers = ["Week", "Task", "Deliverable", "Dependencies"]
    phase7_rows = [
        ["22", "Performance optimization: image audit,\nbundle analysis, lazy loading, caching", "Lighthouse score > 90\nall categories", "All phases"],
        ["22", "Accessibility audit: WCAG 2.1 AA\ncompliance check, screen reader testing", "A11y audit report,\ncritical issues fixed", "All pages"],
        ["23", "SEO finalization: meta tags, structured\ndata, sitemap, robots.txt, OG images", "Complete SEO setup\nwith schema markup", "All public pages"],
        ["23", "Dark mode: full dark theme\nimplementation across all components", "Toggle-able dark mode\nwith persistence", "Design system"],
        ["23-24", "E2E testing: Playwright tests for\ncritical user flows (browse, submit,\nreview, manage)", "Automated E2E test\nsuite (> 80% coverage)", "All features"],
        ["24", "Security review: CSP headers, XSS audit,\nauth flow review, penetration testing", "Security audit report,\ncritical fixes applied", "All phases"],
        ["24", "Launch preparation: production deploy,\nmonitoring setup, runbook, team training", "Production-ready\nplatform launch", "All phases"],
    ]
    t = make_table(phase7_headers, phase7_rows, col_widths=[0.5*inch, 2.2*inch, 1.8*inch, 1.5*inch])
    story.append(t)
    story.append(PageBreak())

    # ══════════════════════════════════════════════
    # SECTION 10: NPM PACKAGES & DEPENDENCIES
    # ══════════════════════════════════════════════
    story.append(heading1("10. NPM Packages & Dependencies List"))
    story.append(hr())
    story.append(body(
        "The following table lists all npm packages required for the frontend, organized by category. "
        "Version numbers target the latest stable release as of June 2025."
    ))
    story.append(spacer(4))

    story.append(heading2("10.1 Core Framework"))
    core_headers = ["Package", "Version", "Purpose"]
    core_rows = [
        ["astro", "^5.x", "Static site generator / SSR framework"],
        ["@astrojs/vue", "^5.x", "Vue 3 integration for Astro"],
        ["@astrojs/tailwind", "^6.x", "Tailwind CSS integration for Astro"],
        ["@astrojs/vercel (or netlify/cloudflare)", "^8.x", "Deployment adapter for hosting platform"],
        ["vue", "^3.5.x", "Progressive JavaScript framework for interactive UI"],
        ["@vue/compiler-sfc", "^3.5.x", "Single File Component compiler (peer dep)"],
    ]
    t = make_table(core_headers, core_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.2 State Management & Routing"))
    state_headers = ["Package", "Version", "Purpose"]
    state_rows = [
        ["vue-router", "^4.5.x", "Client-side routing for SPA pages"],
        ["pinia", "^3.x", "State management for Vue islands and SPA"],
    ]
    t = make_table(state_headers, state_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.3 Styling"))
    style_headers = ["Package", "Version", "Purpose"]
    style_rows = [
        ["tailwindcss", "^4.x", "Utility-first CSS framework"],
        ["@tailwindcss/typography", "^0.5.x", "Prose styles for article text content"],
        ["@tailwindcss/forms", "^0.5.x", "Form element reset and styling"],
    ]
    t = make_table(style_headers, style_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.4 Forms & Validation"))
    form_pkg_headers = ["Package", "Version", "Purpose"]
    form_pkg_rows = [
        ["vee-validate", "^4.x", "Form validation framework for Vue 3"],
        ["@vee-validate/zod", "^4.x", "Zod schema integration for vee-validate"],
        ["zod", "^3.25.x", "TypeScript-first schema validation"],
    ]
    t = make_table(form_pkg_headers, form_pkg_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.5 HTTP Client"))
    http_headers = ["Package", "Version", "Purpose"]
    http_rows = [
        ["ky", "^1.x", "Lightweight HTTP client with hooks, retry, timeout"],
        ["ofetch", "^1.x", "Alternative: fetch wrapper from the UnJS ecosystem"],
    ]
    t = make_table(http_headers, http_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.6 UI Enhancement"))
    ui_headers = ["Package", "Version", "Purpose"]
    ui_rows = [
        ["@astrojs/icon", "^1.x", "SVG icon component with icon sets"],
        ["@iconify-json/mdi", "^1.x", "Material Design Icons icon set"],
        ["astro-icon", "^1.x", "Optimized SVG icon loading for Astro"],
        ["swiper", "^11.x", "Touch slider/carousel for hero and galleries"],
        ["@vueuse/core", "^12.x", "Composable Vue utilities (localStorage, intersection, etc.)"],
        ["@vueuse/head", "^2.x", "Document head management for SPA"],
        ["nprogress", "^0.2.x", "Slim progress bar for SPA navigation"],
    ]
    t = make_table(ui_headers, ui_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.7 Security & Sanitization"))
    sec_headers = ["Package", "Version", "Purpose"]
    sec_rows = [
        ["dompurify", "^3.x", "HTML sanitization to prevent XSS attacks"],
        ["@types/dompurify", "^3.x", "TypeScript definitions for DOMPurify"],
    ]
    t = make_table(sec_headers, sec_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.8 Media & File Handling"))
    media_headers = ["Package", "Version", "Purpose"]
    media_rows = [
        ["browser-image-compression", "^2.x", "Client-side image compression before upload"],
        ["lightgallery", "^2.x", "Lightbox gallery for photo viewing"],
        ["vue3-dropzone", "^1.x", "Drag-and-drop file upload component"],
    ]
    t = make_table(media_headers, media_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.9 Charts & Data Visualization"))
    chart_headers = ["Package", "Version", "Purpose"]
    chart_rows = [
        ["chart.js", "^4.x", "Canvas-based charting library"],
        ["vue-chartjs", "^5.x", "Vue 3 wrapper for Chart.js"],
    ]
    t = make_table(chart_headers, chart_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.10 Rich Text & Content"))
    rtf_headers = ["Package", "Version", "Purpose"]
    rtf_rows = [
        ["marked", "^15.x", "Markdown parser for course content"],
        ["vue3-tiptap", "^2.x", "Rich text editor (for admin content editing)"],
    ]
    t = make_table(rtf_headers, rtf_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.11 PDF Generation (Client)"))
    pdf_headers = ["Package", "Version", "Purpose"]
    pdf_rows = [
        ["jspdf", "^2.x", "Client-side PDF generation for certificates"],
        ["html2canvas", "^1.x", "Screenshot HTML to canvas for PDF conversion"],
    ]
    t = make_table(pdf_headers, pdf_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.12 Testing"))
    test_headers = ["Package", "Version", "Purpose"]
    test_rows = [
        ["vitest", "^3.x", "Unit and integration testing framework"],
        ["@vue/test-utils", "^2.x", "Vue component testing utilities"],
        ["playwright", "^1.x", "End-to-end testing framework"],
        ["@playwright/test", "^1.x", "Playwright test runner"],
        ["happy-dom", "^17.x", "DOM implementation for Vitest"],
    ]
    t = make_table(test_headers, test_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.13 Linting & Code Quality"))
    lint_headers = ["Package", "Version", "Purpose"]
    lint_rows = [
        ["eslint", "^9.x", "JavaScript/TypeScript linter"],
        ["@astrojs/eslint-config", "^1.x", "Astro ESLint configuration"],
        ["eslint-plugin-vue", "^9.x", "Vue-specific ESLint rules"],
        ["typescript-eslint", "^8.x", "TypeScript ESLint parser and plugin"],
        ["prettier", "^3.x", "Code formatter"],
        ["prettier-plugin-tailwindcss", "^0.6.x", "Tailwind class sorting for Prettier"],
    ]
    t = make_table(lint_headers, lint_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.14 Analytics & Monitoring"))
    analytics_headers = ["Package", "Version", "Purpose"]
    analytics_rows = [
        ["@sentry/vue", "^9.x", "Error tracking and performance monitoring"],
        ["@sentry/astro", "^9.x", "Sentry SDK for Astro SSR"],
        ["web-vitals", "^4.x", "Core Web Vitals measurement library"],
    ]
    t = make_table(analytics_headers, analytics_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.15 SEO & Meta Tags"))
    seo_headers = ["Package", "Version", "Purpose"]
    seo_rows = [
        ["@astrojs/sitemap", "^3.x", "Automatic sitemap.xml generation"],
        ["astro-seo", "^3.x", "SEO meta tag helpers for Astro pages"],
    ]
    t = make_table(seo_headers, seo_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)
    story.append(spacer(6))

    story.append(heading2("10.16 Development Utilities"))
    dev_headers = ["Package", "Version", "Purpose"]
    dev_rows = [
        ["typescript", "^5.7.x", "TypeScript compiler"],
        ["vite", "^6.x", "Build tool (Astro's underlying bundler)"],
        ["postcss", "^8.x", "CSS processing (required by Tailwind)"],
    ]
    t = make_table(dev_headers, dev_rows, col_widths=[2.5*inch, 0.8*inch, 3.25*inch])
    story.append(t)

    # Final page
    story.append(spacer(30))
    story.append(hr())
    story.append(spacer(10))
    story.append(Paragraph(
        "<b>End of Frontend Web Plan Document</b>",
        ParagraphStyle('EndNote', parent=S['body'], alignment=TA_CENTER, fontSize=12, textColor=NAVY)
    ))
    story.append(spacer(8))
    story.append(Paragraph(
        "This document serves as the comprehensive blueprint for building the citizen journalism platform's "
        "frontend. All team members should reference this document during development. Updates should be "
        "versioned and communicated to all stakeholders.",
        ParagraphStyle('EndBody', parent=S['body'], alignment=TA_CENTER, fontSize=10, textColor=TEXT_MEDIUM)
    ))
    story.append(spacer(6))
    story.append(Paragraph(
        "Version 1.0  |  June 2025  |  Confidential",
        ParagraphStyle('EndVersion', parent=S['body'], alignment=TA_CENTER, fontSize=9, textColor=TEXT_LIGHT)
    ))

    # ─── BUILD ───
    doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
    print(f"PDF generated successfully: {filepath}")

if __name__ == "__main__":
    output_path = "/home/z/my-project/download/Frontend_Web_Plan.pdf"
    build_pdf(output_path)

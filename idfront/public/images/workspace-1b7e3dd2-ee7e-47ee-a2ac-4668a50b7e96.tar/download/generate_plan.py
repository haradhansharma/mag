#!/usr/bin/env python3
"""
Comprehensive Business Plan PDF Generator
Decentralized Citizen Journalism Network
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, mm
from reportlab.lib.colors import HexColor, black, white, grey
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, KeepTogether, ListFlowable, ListItem, HRFlowable
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY, TA_RIGHT
from reportlab.platypus.flowables import Flowable
from reportlab.lib import colors
import datetime

# ─── Colors ───
PRIMARY = HexColor("#1a365d")
SECONDARY = HexColor("#2c5282")
ACCENT = HexColor("#2b6cb0")
LIGHT_BG = HexColor("#ebf8ff")
DARK_TEXT = HexColor("#1a202c")
MEDIUM_TEXT = HexColor("#4a5568")
LIGHT_LINE = HexColor("#cbd5e0")
TABLE_HEADER_BG = HexColor("#2c5282")
TABLE_ALT_BG = HexColor("#f7fafc")

# ─── Custom Flowable for colored box ───
class ColoredBox(Flowable):
    def __init__(self, width, height, color):
        Flowable.__init__(self)
        self.width = width
        self.height = height
        self.color = color
    def draw(self):
        self.canv.setFillColor(self.color)
        self.canv.rect(0, 0, self.width, self.height, fill=1, stroke=0)

# ─── Page number handler ───
def add_page_number(canvas, doc):
    page_num = canvas.getPageNumber()
    if page_num > 1:
        text = f"Page {page_num}"
        canvas.saveState()
        canvas.setFont('Helvetica', 8)
        canvas.setFillColor(MEDIUM_TEXT)
        canvas.drawCentredString(letter[0]/2, 0.5*inch, text)
        # Header line
        canvas.setStrokeColor(LIGHT_LINE)
        canvas.setLineWidth(0.5)
        canvas.line(0.75*inch, letter[1]-0.55*inch, letter[0]-0.75*inch, letter[1]-0.55*inch)
        # Footer line
        canvas.line(0.75*inch, 0.65*inch, letter[0]-0.75*inch, 0.65*inch)
        canvas.restoreState()

# ─── Build Document ───
OUTPUT = "/home/z/my-project/download/Citizen_Journalism_Comprehensive_Business_Plan.pdf"
doc = SimpleDocTemplate(
    OUTPUT,
    pagesize=letter,
    topMargin=0.75*inch,
    bottomMargin=0.75*inch,
    leftMargin=0.75*inch,
    rightMargin=0.75*inch,
)

styles = getSampleStyleSheet()

# Custom styles
styles.add(ParagraphStyle(
    name='CoverTitle', fontName='Helvetica-Bold', fontSize=28,
    leading=34, alignment=TA_CENTER, textColor=PRIMARY, spaceAfter=12
))
styles.add(ParagraphStyle(
    name='CoverSubtitle', fontName='Helvetica', fontSize=16,
    leading=22, alignment=TA_CENTER, textColor=SECONDARY, spaceAfter=8
))
styles.add(ParagraphStyle(
    name='SectionHeading', fontName='Helvetica-Bold', fontSize=20,
    leading=26, textColor=PRIMARY, spaceBefore=24, spaceAfter=12,
    borderWidth=0, borderPadding=0
))
styles.add(ParagraphStyle(
    name='SubHeading', fontName='Helvetica-Bold', fontSize=14,
    leading=18, textColor=SECONDARY, spaceBefore=16, spaceAfter=8
))
styles.add(ParagraphStyle(
    name='SubSubHeading', fontName='Helvetica-Bold', fontSize=11.5,
    leading=15, textColor=ACCENT, spaceBefore=12, spaceAfter=6
))
styles.add(ParagraphStyle(
    name='BodyText2', fontName='Helvetica', fontSize=10,
    leading=15, alignment=TA_JUSTIFY, textColor=DARK_TEXT,
    spaceBefore=3, spaceAfter=6
))
styles.add(ParagraphStyle(
    name='BulletText', fontName='Helvetica', fontSize=10,
    leading=14.5, alignment=TA_LEFT, textColor=DARK_TEXT,
    leftIndent=24, bulletIndent=12, spaceBefore=2, spaceAfter=2,
    bulletFontName='Helvetica', bulletFontSize=10
))
styles.add(ParagraphStyle(
    name='TableHeader', fontName='Helvetica-Bold', fontSize=9.5,
    leading=12, alignment=TA_CENTER, textColor=white
))
styles.add(ParagraphStyle(
    name='TableCell', fontName='Helvetica', fontSize=9,
    leading=12, alignment=TA_LEFT, textColor=DARK_TEXT
))
styles.add(ParagraphStyle(
    name='TableCellCenter', fontName='Helvetica', fontSize=9,
    leading=12, alignment=TA_CENTER, textColor=DARK_TEXT
))
styles.add(ParagraphStyle(
    name='FooterNote', fontName='Helvetica-Oblique', fontSize=8.5,
    leading=12, alignment=TA_LEFT, textColor=MEDIUM_TEXT,
    spaceBefore=6
))
styles.add(ParagraphStyle(
    name='TOCEntry', fontName='Helvetica', fontSize=11,
    leading=20, alignment=TA_LEFT, textColor=DARK_TEXT,
    leftIndent=0
))
styles.add(ParagraphStyle(
    name='TOCSubEntry', fontName='Helvetica', fontSize=10,
    leading=18, alignment=TA_LEFT, textColor=MEDIUM_TEXT,
    leftIndent=24
))

story = []
PAGE_WIDTH = letter[0] - 1.5*inch

# ══════════════════════════════════════════════════════════════
# COVER PAGE
# ══════════════════════════════════════════════════════════════
story.append(Spacer(1, 1.2*inch))
story.append(HRFlowable(width="80%", thickness=2, color=PRIMARY, spaceAfter=20))
story.append(Paragraph("COMPREHENSIVE BUSINESS PLAN", styles['CoverTitle']))
story.append(Spacer(1, 8))
story.append(Paragraph("Decentralized Citizen Journalism Network", styles['CoverSubtitle']))
story.append(Spacer(1, 4))
story.append(Paragraph("An Independent News Organization Powered by Trained Citizen Journalists", styles['CoverSubtitle']))
story.append(Spacer(1, 6))
story.append(HRFlowable(width="80%", thickness=2, color=PRIMARY, spaceBefore=20, spaceAfter=30))

story.append(Spacer(1, 0.5*inch))

cover_data = [
    ["Prepared Date:", datetime.date.today().strftime("%B %d, %Y")],
    ["Document Version:", "1.0"],
    ["Classification:", "Confidential — Internal Use"],
    ["Project Type:", "Social Enterprise / Media Startup"],
    ["Target Markets:", "Rural & Semi-Urban Communities"],
]
cover_table = Table(cover_data, colWidths=[2.2*inch, 3.8*inch])
cover_table.setStyle(TableStyle([
    ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
    ('FONTNAME', (1,0), (1,-1), 'Helvetica'),
    ('FONTSIZE', (0,0), (-1,-1), 10),
    ('TEXTCOLOR', (0,0), (-1,-1), DARK_TEXT),
    ('ALIGN', (0,0), (0,-1), 'RIGHT'),
    ('ALIGN', (1,0), (1,-1), 'LEFT'),
    ('BOTTOMPADDING', (0,0), (-1,-1), 8),
    ('TOPPADDING', (0,0), (-1,-1), 8),
]))
story.append(cover_table)
story.append(Spacer(1, 1.5*inch))
story.append(Paragraph(
    "<i>This document contains proprietary business strategies and financial projections. "
    "Distribution is restricted to authorized personnel only.</i>",
    ParagraphStyle('CoverDisclaimer', parent=styles['BodyText2'], alignment=TA_CENTER, fontSize=9, textColor=MEDIUM_TEXT)
))
story.append(PageBreak())

# ══════════════════════════════════════════════════════════════
# TABLE OF CONTENTS
# ══════════════════════════════════════════════════════════════
story.append(Paragraph("TABLE OF CONTENTS", styles['SectionHeading']))
story.append(Spacer(1, 12))
story.append(HRFlowable(width="100%", thickness=1, color=LIGHT_LINE, spaceAfter=16))

toc_items = [
    ("A.", "Operational Plan", [
        "A.1 Training Program Design",
        "A.2 Recruitment & Enrollment Strategy",
        "A.3 News Gathering Workflow",
        "A.4 Quality Control & Editorial Process",
        "A.5 Technology Platform Requirements",
        "A.6 Security Protocols",
        "A.7 Organizational Structure & Staffing",
    ]),
    ("B.", "Finance Model", [
        "B.1 Point-Based Monetization System",
        "B.2 Revenue Streams",
        "B.3 Cost Structure",
        "B.4 Pricing Strategy for Training Course",
        "B.5 Financial Projections",
        "B.6 Break-even Analysis",
        "B.7 Funding Strategy",
    ]),
    ("C.", "NGO & Human Rights Partnership Strategy"),
    ("D.", "Legal & Ethical Framework"),
    ("E.", "Risk Management"),
    ("F.", "Growth Strategy"),
    ("G.", "Implementation Timeline"),
]

for item in toc_items:
    letter_id = item[0]
    title = item[1]
    subs = item[2] if len(item) > 2 else []
    story.append(Paragraph(f"<b>{letter_id} {title}</b>", styles['TOCEntry']))
    if subs:
        for s in subs:
            story.append(Paragraph(s, styles['TOCSubEntry']))

story.append(PageBreak())

# ══════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════
def heading(text, level='section'):
    if level == 'section':
        story.append(Spacer(1, 6))
        story.append(HRFlowable(width="100%", thickness=1.5, color=PRIMARY, spaceAfter=4))
        story.append(Paragraph(text, styles['SectionHeading']))
    elif level == 'sub':
        story.append(Paragraph(text, styles['SubHeading']))
    elif level == 'subsub':
        story.append(Paragraph(text, styles['SubSubHeading']))

def body(text):
    story.append(Paragraph(text, styles['BodyText2']))

def bullet(text):
    story.append(Paragraph(f"• {text}", styles['BulletText']))

def spacer(h=8):
    story.append(Spacer(1, h))

def make_table(data, col_widths=None, has_header=True):
    """Create a styled table."""
    t = Table(data, colWidths=col_widths, repeatRows=1 if has_header else 0)
    style_cmds = [
        ('FONTNAME', (0,0), (-1,-1), 'Helvetica'),
        ('FONTSIZE', (0,0), (-1,-1), 9),
        ('TEXTCOLOR', (0,0), (-1,-1), DARK_TEXT),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('GRID', (0,0), (-1,-1), 0.5, LIGHT_LINE),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('LEFTPADDING', (0,0), (-1,-1), 8),
        ('RIGHTPADDING', (0,0), (-1,-1), 8),
    ]
    if has_header:
        style_cmds += [
            ('BACKGROUND', (0,0), (-1,0), TABLE_HEADER_BG),
            ('TEXTCOLOR', (0,0), (-1,0), white),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,0), 9.5),
        ]
    # Alternate row shading
    for i in range(1, len(data)):
        if i % 2 == 0:
            style_cmds.append(('BACKGROUND', (0,i), (-1,i), TABLE_ALT_BG))
    t.setStyle(TableStyle(style_cmds))
    return t


# ══════════════════════════════════════════════════════════════
# A. OPERATIONAL PLAN
# ══════════════════════════════════════════════════════════════
heading("A. OPERATIONAL PLAN")
body(
    "This section outlines the comprehensive operational framework for the Decentralized Citizen Journalism Network (DCJN). "
    "The operational plan covers every aspect of the organization's day-to-day functioning, from training citizen journalists "
    "to publishing verified news content. The model is designed to be scalable, secure, and sustainable while maintaining "
    "the highest standards of journalistic integrity and contributor safety. Each subsection provides actionable detail that "
    "can be directly translated into operational procedures and team responsibilities."
)

# A.1
heading("A.1 Training Program Design", level='sub')
body(
    "The training program is the foundational pillar of the entire initiative. It transforms ordinary citizens — particularly "
    "students in rural schools and colleges — into competent, ethical news gatherers. The program is designed to be accessible, "
    "practical, and rigorous enough to ensure quality output while remaining engaging enough to retain participants. The training "
    "is delivered entirely online through a purpose-built learning management system (LMS) integrated into the DCJN website."
)

heading("A.1.1 Curriculum Structure", level='subsub')
body(
    "The curriculum is organized into five core modules, each designed to build progressively upon the previous one. The total "
    "program spans 8 weeks, requiring approximately 4-6 hours of study per week. The modular structure allows for self-paced "
    "learning while maintaining deadline-driven milestones to ensure timely completion."
)

body("<b>Module 1: Introduction to Citizen Journalism (Week 1-2)</b>")
bullet("History and importance of citizen journalism in democratic societies")
bullet("Understanding the role of citizen journalists vs. professional journalists")
bullet("The ethical responsibilities of a journalist: truth, accuracy, fairness, and independence")
bullet("Case studies of successful citizen journalism initiatives worldwide (e.g., ProPublica's Public Insight Network, GroundTruth)")
bullet("Understanding local news ecosystems and identifying gaps in rural coverage")
bullet("Introduction to the DCJN platform, contributor code of conduct, and operational expectations")

body("<b>Module 2: The WH-Question Reporting Method (Week 2-4)</b>")
bullet("Deep-dive into the 5W1H framework: Who, What, When, Where, Why, and How")
bullet("Practical exercises: writing a complete news report using WH answers format")
bullet("Identifying newsworthy events in local communities: government actions, infrastructure issues, education, health, crime, agriculture")
bullet("Observation techniques: what to look for, how to document systematically")
bullet("Conducting basic interviews: approaching sources, asking open-ended questions, recording responses ethically")
bullet("Writing concise, factual reports: avoiding opinion, speculation, and personal bias")
bullet("Minimum 10 practice exercises with automated feedback and 3 peer-reviewed assignments")

body("<b>Module 3: Mobile Photography & Evidence Gathering (Week 4-5)</b>")
bullet("Using smartphone cameras effectively: composition, lighting, angles, and framing for news photography")
bullet("Taking photos that tell a story: wide shots for context, medium shots for subjects, close-ups for detail")
bullet("Recording quality audio and video clips for supplementary evidence")
bullet("Metadata awareness: understanding EXIF data, geotagging, and timestamp documentation")
bullet("Legal considerations for photography in public spaces vs. private property")
bullet("Best practices for storing and organizing evidence securely on mobile devices")

body("<b>Module 4: Security, Safety & Secret News Gathering (Week 5-7)</b>")
bullet("Personal safety assessment: evaluating risk levels before, during, and after reporting")
bullet("Digital security fundamentals: encrypted messaging (Signal, WhatsApp), secure browsing (Tor, VPNs)")
bullet("Maintaining anonymity: why contributors must remain unidentified in their communities")
bullet("Operational security (OPSEC): compartmentalization, avoiding patterns, secure communication with editorial team")
bullet("Handling sensitive information: what to do if you witness corruption, violence, or illegal activity")
bullet("De-escalation techniques and knowing when to withdraw from dangerous situations")
bullet("Emergency protocols: who to contact, what information to share, and how to seek help")
bullet("Country-specific legal rights for journalists and citizens documenting public events")
bullet("Scenario-based training: 5 interactive simulations covering common risky situations")

body("<b>Module 5: Platform Training & Final Assessment (Week 7-8)</b>")
bullet("Hands-on training with the DCJN submission portal: creating reports, uploading photos, tagging categories")
bullet("Understanding the point-based reward system and how earnings are calculated")
bullet("Editorial guidelines review: what editors look for, common reasons for rejection")
bullet("Complete a supervised mock submission from identification to publication")
bullet("Final written examination (50 questions, minimum 70% to pass)")
bullet("Final practical assessment: submit one real news report from the participant's community for editorial review")

heading("A.1.2 Certification & Completion", level='subsub')
body(
    "Participants who achieve a minimum score of 70% on the written exam and receive editorial approval on their practical "
    "submission receive the DCJN Certified Contributor badge. This certification is digital and can be shared on LinkedIn or "
    "other professional platforms. Certified contributors are automatically enrolled in the contributor network and gain access "
    "to the news submission portal. The certificate includes a unique verification code that can be validated on the website."
)
body(
    "Participants who score below 70% on the written exam receive detailed feedback highlighting areas of weakness. They may "
    "re-enroll in the program after a mandatory 3-month waiting period. During this period, they are encouraged to study "
    "independently using the free study materials available on the website. This waiting period ensures that participants take "
    "the training seriously and reduces the administrative burden of handling repeat enrollments immediately."
)
body(
    "To maintain active contributor status, certified journalists must submit at least one verified news report every 90 days. "
    "Contributors who go inactive for more than 180 days are placed on a suspended list and must complete a brief refresher "
    "course (2-week abbreviated version) before regaining submission privileges."
)

heading("A.1.3 Curriculum Governance", level='subsub')
body(
    "The curriculum is reviewed and updated quarterly by the Editorial Director in consultation with an Advisory Board "
    "comprising experienced journalists, media law experts, and digital security specialists. Updates are driven by changes "
    "in the legal landscape, emerging security threats, platform feature additions, and feedback from contributors. All "
    "curriculum changes are version-controlled and contributors are notified of material updates via the platform."
)

spacer()
# A.2
heading("A.2 Recruitment & Enrollment Strategy", level='sub')
body(
    "Building a robust network of citizen journalists requires a targeted, multi-channel recruitment strategy. Unlike "
    "traditional media organizations that hire professional staff, DCJN must identify and attract individuals who have "
    "the curiosity, courage, and commitment to report on local events — while also maintaining the secrecy that is "
    "central to the model's success."
)

heading("A.2.1 Target Demographics", level='subsub')
body("The primary recruitment targets are:")
bullet("Rural school students (ages 16-18): Particularly those in government schools with limited exposure to media education. These students often have smartphones and strong community ties.")
bullet("College and university students (ages 18-25): Especially those in rural or semi-urban areas studying arts, social sciences, law, or communications.")
bullet("Conscious citizens and community leaders (ages 25-50): Individuals already engaged in community work, such as NGO volunteers, teachers, healthcare workers, and retired professionals.")
bullet("Women in rural communities: Deliberate outreach to ensure gender diversity in reporting and to capture stories that male contributors may not have access to.")
bullet("Agricultural workers and farmers: Those with first-hand knowledge of rural issues including farming crises, government scheme implementation, and environmental concerns.")

heading("A.2.2 Geographic Targeting", level='subsub')
body(
    "Initial recruitment focuses on 3-5 districts per state, selected based on the following criteria: (a) limited "
    "presence of mainstream media, (b) high incidence of underreported issues (corruption, human rights violations, "
    "infrastructure failures), (c) existing internet penetration of at least 30%, and (d) presence of educational "
    "institutions with student populations of 500 or more. A scoring matrix is used to rank and prioritize districts. "
    "The target is to have at least 15-20 active contributors per district within the first year of operation."
)

heading("A.2.3 Recruitment Channels", level='subsub')
body("<b>Digital Outreach:</b>")
bullet("Social media campaigns on Facebook, Instagram, and YouTube targeting rural and semi-urban demographics in regional languages")
bullet("Google Ads campaigns targeting searches related to 'journalism course,' 'citizen journalism,' 'how to become a reporter,' and 'part-time journalism'")
bullet("WhatsApp-based referral program: existing contributors can invite peers (anonymously) and earn bonus points for successful referrals that complete certification")
bullet("SEO-optimized blog content on the DCJN website addressing topics like career opportunities in journalism, importance of local news, and citizen rights")
bullet("YouTube tutorial snippets (2-3 minutes) showcasing the training program and success stories of citizen journalists")

body("<b>Offline / Community Outreach:</b>")
bullet("Partnerships with colleges and universities: arrange free orientation sessions about citizen journalism and offer group enrollment discounts")
bullet("Collaboration with existing NGOs and community organizations that work in rural education and empowerment")
bullet("Distribution of printed flyers and posters at educational institutions, community centers, and public libraries")
bullet("Radio announcements on local FM stations during peak listening hours")
bullet("Participation in college festivals and career fairs")

body("<b>Influencer & Ambassador Network:</b>")
bullet("Identify and recruit local influencers — teachers, community leaders, social media personalities — who can endorse the program")
bullet("Establish a Campus Ambassador program where one student per institution serves as a liaison and promoter")
bullet("Offer ambassador incentives: free certification, priority access to advanced courses, and exclusive contributor badges")

heading("A.2.4 Enrollment & Screening Process", level='subsub')
body(
    "The enrollment process is designed to be accessible while ensuring quality and commitment. Prospective contributors "
    "begin by filling out an online application form that captures basic demographic information, educational background, "
    "motivation for joining, and a brief self-assessment of their writing and photography skills. There is no minimum "
    "qualification barrier — the only requirements are being at least 16 years old, having access to a smartphone with "
    "a working camera, and having a basic internet connection."
)
body(
    "After submitting the application, candidates undergo a brief phone screening (5-10 minutes) conducted by the "
    "Recruitment Coordinator. This call verifies the candidate's identity, assesses their communication skills, "
    "confirms their understanding of the program's requirements, and ensures they can commit the necessary time "
    "(4-6 hours per week for 8 weeks). Candidates who pass the screening receive login credentials to the training "
    "platform within 48 hours."
)

spacer()
# A.3
heading("A.3 News Gathering Workflow", level='sub')
body(
    "The news gathering workflow defines the end-to-end process from the moment a contributor witnesses or learns about "
    "a newsworthy event to the publication of a verified story on the DCJN platform. This process is designed to be "
    "efficient, secure, and maintain the anonymity of contributors at every stage."
)

heading("A.3.1 Step-by-Step Workflow", level='subsub')
body("<b>Step 1: Incident Identification (Contributor)</b>")
bullet("Contributor witnesses an event or receives credible information about a newsworthy incident in their locality")
bullet("They perform a quick newsworthiness assessment: Is this timely? Does it affect the community? Is it verifiable?")
bullet("They confirm personal safety and evaluate the risk level of reporting on the incident")

body("<b>Step 2: On-Ground Documentation (Contributor)</b>")
bullet("The contributor visits the scene (if safe) and gathers facts using the WH-question framework")
bullet("They take a minimum of 3 photographs: one wide shot establishing the scene, one medium shot of the key subject, and one detail shot")
bullet("They note down the 5W1H answers in a structured format on the DCJN mobile app or a secure notepad")
bullet("If possible, they conduct a brief interview with an eyewitness or affected person (with consent)")
bullet("All documentation is done discreetly — the contributor does not identify themselves as a journalist")

body("<b>Step 3: Secure Submission (Contributor)</b>")
bullet("The contributor logs into the DCJN submission portal via the mobile-responsive website or app")
bullet("They fill out the structured submission form: headline, WH-answers, location (GPS coordinates optional), date/time, category, photos")
bullet("They attach photographs and any supplementary audio/video evidence")
bullet("Before submitting, the system performs a pre-check: all required fields filled, photos under 5MB each, minimum word count met")
bullet("The submission is encrypted and transmitted to the editorial server")
bullet("The contributor receives an acknowledgment with a unique submission tracking ID")

body("<b>Step 4: Initial Triage (Junior Editor)</b>")
bullet("Submissions are automatically routed to a Junior Editor based on category and geographic zone")
bullet("The Junior Editor performs a first-pass review within 2 hours of submission: checks for completeness, obvious factual errors, and duplicate submissions")
bullet("Submissions that are incomplete or clearly not newsworthy are flagged with feedback to the contributor")
bullet("Promising submissions are escalated to a Senior Editor for detailed review")

body("<b>Step 5: Verification & Fact-Checking (Senior Editor)</b>")
bullet("The Senior Editor cross-references the submission against publicly available information: government records, police reports, social media, other news outlets")
bullet("They may contact the contributor (via secure channel) for clarification or additional information")
bullet("They verify the photos using reverse image search and metadata analysis to rule out manipulation or recycling")
bullet("For sensitive stories, a second Senior Editor conducts an independent verification")
bullet("Verification results are documented in the editorial audit trail")

body("<b>Step 6: Editorial Approval & Editing (Senior Editor)</b>")
bullet("Once verified, the Senior Editor edits the report for clarity, grammar, and adherence to DCJN editorial guidelines")
bullet("The headline is refined for impact and accuracy, without sensationalism")
bullet("Photos are cropped and optimized for web publication; any identifying metadata is stripped")
bullet("The story is assigned to a category and given appropriate tags for discoverability")

body("<b>Step 7: Publication (Automated + Editor)</b>")
bullet("Approved stories are published on the DCJN website with byline attributed to the contributor's anonymous pen name")
bullet("The contributor's account is credited with points (typically 50-200 points per published story based on quality and significance)")
bullet("An email/push notification is sent to the contributor confirming publication")
bullet("The story is automatically distributed to social media channels and any syndication partners")

body("<b>Step 8: Follow-Up & Updates (Assigned Contributor)</b>")
bullet("For ongoing stories (crimes, investigations, infrastructure projects), the editorial team assigns a follow-up contributor from the rotation system")
bullet("Follow-up reports are linked to the original story to create a timeline of events")
bullet("Follow-up contributors earn additional points (typically 30-100 points per update)")

heading("A.3.2 Turnaround Time Targets", level='subsub')

tat_data = [
    [Paragraph("<b>Event Type</b>", styles['TableHeader']), Paragraph("<b>Submission Deadline</b>", styles['TableHeader']),
     Paragraph("<b>Editorial Review</b>", styles['TableHeader']), Paragraph("<b>Publication Target</b>", styles['TableHeader'])],
    [Paragraph("Breaking News", styles['TableCell']), Paragraph("Within 2 hours", styles['TableCellCenter']),
     Paragraph("Within 4 hours", styles['TableCellCenter']), Paragraph("Within 6 hours", styles['TableCellCenter'])],
    [Paragraph("Daily News", styles['TableCell']), Paragraph("Within 12 hours", styles['TableCellCenter']),
     Paragraph("Within 8 hours", styles['TableCellCenter']), Paragraph("Within 24 hours", styles['TableCellCenter'])],
    [Paragraph("Feature / Investigation", styles['TableCell']), Paragraph("Within 48 hours", styles['TableCellCenter']),
     Paragraph("Within 72 hours", styles['TableCellCenter']), Paragraph("Within 5 days", styles['TableCellCenter'])],
    [Paragraph("Follow-Up Report", styles['TableCell']), Paragraph("Per editorial assignment", styles['TableCellCenter']),
     Paragraph("Within 24 hours", styles['TableCellCenter']), Paragraph("Within 48 hours", styles['TableCellCenter'])],
]
story.append(make_table(tat_data, col_widths=[1.6*inch, 1.6*inch, 1.6*inch, 1.6*inch]))
spacer(8)

spacer()
# A.4
heading("A.4 Quality Control & Editorial Process", level='sub')
body(
    "Maintaining editorial quality is critical for the credibility and long-term sustainability of DCJN. The quality "
    "control framework operates on a multi-layered review system that ensures every piece of content is accurate, "
    "fair, and compliant with ethical standards before it reaches the public. This is especially important given that "
    "the contributor base consists of non-professional journalists who require structured oversight."
)

heading("A.4.1 Multi-Layer Review System", level='subsub')
body(
    "DCJN implements a three-tier editorial review system. The first tier consists of automated pre-submission checks "
    "built into the platform: required field validation, word count verification, photo format and size checks, duplicate "
    "detection via title and content matching, and automated profanity/inappropriate content screening. This layer catches "
    "approximately 15-20% of submissions before they reach human editors."
)
body(
    "The second tier is the Junior Editor review, as described in the workflow. Junior Editors are trained journalism "
    "graduates or experienced contributors who have been promoted to editorial roles. They handle initial triage, "
    "completeness checks, and basic fact verification. Each Junior Editor is expected to process 20-30 submissions per "
    "day. They have the authority to return submissions to contributors with specific feedback for revision, or to "
    "escalate promising submissions to Senior Editors."
)
body(
    "The third tier is the Senior Editor review, which involves detailed fact-checking, editorial refinement, and final "
    "publication approval. Senior Editors are experienced journalists with a minimum of 3 years of professional media "
    "experience. They also handle sensitive stories that require additional scrutiny, such as reports involving government "
    "officials, allegations of criminal activity, or content that could potentially harm individuals if published inaccurately. "
    "Every Senior Editor decision is logged in the editorial management system, creating a complete audit trail."
)

heading("A.4.2 Fact-Checking Standards", level='subsub')
body("Every published story must pass the following fact-checking criteria:")
bullet("<b>Source verification:</b> At least two independent sources must confirm the core facts of the story. For events witnessed firsthand by the contributor, at least one additional source (eyewitness, official record, or public data) is required.")
bullet("<b>Photo verification:</b> Images are checked using reverse image search tools and metadata analysis to confirm they are original, unmanipulated, and genuinely represent the reported event.")
bullet("<b>Claim verification:</b> Any statistical claims, policy references, or legal assertions are cross-checked against official sources (government websites, published reports, legal databases).")
bullet("<b>Geographic verification:</b> GPS coordinates (when provided) and landmark identification are used to confirm the reported location matches the described incident.")

heading("A.4.3 Contributor Performance Monitoring", level='subsub')
body(
    "Contributors are rated on a 5-star quality system based on the editorial assessment of their submissions. "
    "The rating considers accuracy (verified facts), completeness (all WH questions answered), writing quality "
    "(clarity and grammar), and photo quality (relevance and resolution). Contributors with an average rating "
    "below 3.0 stars over their last 10 submissions receive a mandatory refresher module. Contributors consistently "
    "rated 4.5+ stars are designated 'Senior Contributors' and receive priority access to high-value assignments "
    "and higher per-point payouts."
)

heading("A.4.4 Retraction & Correction Policy", level='subsub')
body(
    "When an error is identified in a published story, DCJN follows a strict correction protocol. Minor factual "
    "errors (incorrect dates, misspelled names) are corrected immediately with an editor's note at the top of the "
    "article indicating what was changed. Substantial errors (wrong identification, misleading claims) result in the "
    "story being temporarily unpublished, a full investigation by the Editorial Director, and either a corrected "
    "re-publication or a full retraction. All corrections are logged and publicly accessible through a 'Corrections' "
    "page on the website, demonstrating editorial accountability."
)

spacer()
# A.5
heading("A.5 Technology Platform Requirements", level='sub')
body(
    "The technology platform is the backbone of DCJN's operations. It serves three primary functions: (1) delivering "
    "the online training course, (2) enabling secure news submission and editorial management, and (3) publishing "
    "content to the public. The platform must be robust, user-friendly for contributors with varying levels of "
    "technical literacy, and secure enough to protect contributor identities."
)

heading("A.5.1 Core Platform Components", level='subsub')

tech_data = [
    [Paragraph("<b>Component</b>", styles['TableHeader']), Paragraph("<b>Description</b>", styles['TableHeader']),
     Paragraph("<b>Technology Stack</b>", styles['TableHeader']), Paragraph("<b>Priority</b>", styles['TableHeader'])],
    [Paragraph("Public Website", styles['TableCell']), Paragraph("News publication, SEO, user engagement", styles['TableCell']),
     Paragraph("Next.js / React, CMS (WordPress or Strapi)", styles['TableCell']), Paragraph("Critical", styles['TableCellCenter'])],
    [Paragraph("Training LMS", styles['TableCell']), Paragraph("Course delivery, video hosting, quizzes, certificates", styles['TableCell']),
     Paragraph("Moodle / Custom LMS on Node.js", styles['TableCell']), Paragraph("Critical", styles['TableCellCenter'])],
    [Paragraph("Submission Portal", styles['TableCell']), Paragraph("Secure form for news reports, photo upload", styles['TableCell']),
     Paragraph("React form library, encrypted API endpoints", styles['TableCell']), Paragraph("Critical", styles['TableCellCenter'])],
    [Paragraph("Editorial Dashboard", styles['TableCell']), Paragraph("Content queue, review tools, fact-checking workflow", styles['TableCell']),
     Paragraph("Custom admin panel (React + PostgreSQL)", styles['TableCell']), Paragraph("Critical", styles['TableCellCenter'])],
    [Paragraph("Contributor Dashboard", styles['TableCell']), Paragraph("Points balance, submission history, training status", styles['TableCell']),
     Paragraph("React dashboard, REST API", styles['TableCell']), Paragraph("High", styles['TableCellCenter'])],
    [Paragraph("Mobile App", styles['TableCell']), Paragraph("On-the-go submission, push notifications", styles['TableCell']),
     Paragraph("React Native / Flutter (iOS + Android)", styles['TableCell']), Paragraph("High", styles['TableCellCenter'])],
    [Paragraph("Payment System", styles['TableCell']), Paragraph("Point redemption, contributor payouts", styles['TableCell']),
     Paragraph("Stripe / Razorpay integration", styles['TableCell']), Paragraph("High", styles['TableCellCenter'])],
    [Paragraph("Analytics Engine", styles['TableCell']), Paragraph("Traffic monitoring, engagement metrics, contributor performance", styles['TableCell']),
     Paragraph("Google Analytics, Mixpanel, custom dashboard", styles['TableCell']), Paragraph("Medium", styles['TableCellCenter'])],
    [Paragraph("Content Delivery", styles['TableCell']), Paragraph("Fast page loads, image optimization, global CDN", styles['TableCell']),
     Paragraph("Cloudflare CDN, AWS S3 for media storage", styles['TableCell']), Paragraph("High", styles['TableCellCenter'])],
]
story.append(make_table(tech_data, col_widths=[1.4*inch, 1.8*inch, 1.8*inch, 0.8*inch]))
spacer(8)

heading("A.5.2 Mobile Submission Features", level='subsub')
body(
    "The mobile submission interface is designed for contributors who primarily use smartphones. Key features include: "
    "a simplified 3-step submission wizard (select category, answer WH questions, upload photos), automatic GPS location "
    "tagging (which can be disabled for sensitive reports), offline draft saving for areas with poor connectivity, "
    "photo compression built into the upload process to reduce bandwidth requirements, and a one-tap emergency button "
    "that immediately notifies the editorial team if a contributor is in danger."
)

heading("A.5.3 Security Infrastructure", level='subsub')
body(
    "The platform employs end-to-end encryption (TLS 1.3) for all data transmission. Contributor submissions are "
    "encrypted at rest using AES-256 encryption. The editorial management system uses role-based access control (RBAC) "
    "with two-factor authentication for all staff accounts. Contributor login credentials are hashed using bcrypt with "
    "a work factor of 12. The platform undergoes quarterly penetration testing by an independent security firm, and "
    "a bug bounty program rewards external researchers who identify vulnerabilities. Server infrastructure is hosted on "
    "AWS with multi-region redundancy, automated backups every 6 hours, and a documented incident response plan."
)

spacer()
# A.6
heading("A.6 Security Protocols", level='sub')
body(
    "Contributor safety is the single most important operational priority for DCJN. Unlike traditional journalists who "
    "may have institutional support, media credentials, and public recognition, DCJN contributors operate covertly in "
    "their communities. They face risks from local authorities, criminal elements, and even community members who may "
    "view their reporting with hostility. The security protocols outlined below are designed to mitigate these risks "
    "at every stage of the contributor journey."
)

heading("A.6.1 Identity Protection", level='subsub')
bullet("<b>Anonymous pen names:</b> Every contributor operates under a pseudonym. Their real name, location, and personal details are stored in a separate encrypted database accessible only to the Security Officer and Editorial Director.")
bullet("<b>Compartmentalized access:</b> No single staff member has complete access to a contributor's identity and submission history simultaneously. The editorial team sees pen names and submissions; the finance team sees pen names and payment details; only the Security Officer can link the two.")
bullet("<b>No public profiles:</b> Contributors do not have public-facing profiles on the DCJN website. Bylines use pen names only, and no photographs or identifying information of contributors are ever published.")
bullet("<b>Secure communication:</b> All editorial-contributor communication occurs through the platform's encrypted messaging system. Contributors are instructed to never use personal phone numbers or social media accounts for DCJN-related communication.")

heading("A.6.2 Digital Security Training & Tools", level='subsub')
body(
    "As covered in the training curriculum, all contributors receive comprehensive digital security training. In addition, "
    "DCJN provides the following tools and resources: a pre-configured secure mobile browser (based on Firefox Focus) "
    "for accessing the submission portal, a recommended secure messaging app (Signal) pre-loaded with DCJN editorial "
    "contacts, a virtual private network (VPN) service account for contributors in high-risk regions, and a quarterly "
    "digital security newsletter covering new threats and best practices. Contributors in especially sensitive regions "
    "(those reporting on organized crime, political corruption, or human rights abuses) receive additional one-on-one "
    "security briefings with the Security Officer."
)

heading("A.6.3 Physical Safety Protocols", level='subsub')
bullet("Contributors must never pursue a story if they assess the personal risk as 'high' or above. Safety always takes precedence over any news story.")
bullet("The platform includes a duress code feature: a specific word or pattern included in any communication that immediately signals to the editorial team that the contributor is under threat.")
bullet("DCJN maintains a legal support network — partnerships with media law firms in each operational region that can provide emergency legal assistance to contributors facing threats or legal action.")
bullet("For contributors who must be evacuated from dangerous situations, DCJN has a contingency fund and relationships with local NGOs that can provide temporary safe housing.")
bullet("An annual security audit is conducted by an external risk assessment firm to evaluate and update physical safety protocols.")

spacer()
# A.7
heading("A.7 Organizational Structure & Staffing", level='sub')
body(
    "DCJN's organizational structure is lean by design, prioritizing efficiency and clear reporting lines. The team "
    "scales with the contributor network, with key hires made at specific contributor milestones. Below is the "
    "organizational structure and staffing plan for each growth phase."
)

org_data = [
    [Paragraph("<b>Role</b>", styles['TableHeader']), Paragraph("<b>Responsibilities</b>", styles['TableHeader']),
     Paragraph("<b>Phase 1 (Yr 1)</b>", styles['TableHeader']), Paragraph("<b>Phase 2 (Yr 2)</b>", styles['TableHeader']),
     Paragraph("<b>Phase 3 (Yr 3)</b>", styles['TableHeader'])],
    [Paragraph("Founder / CEO", styles['TableCell']), Paragraph("Strategic direction, partnerships, fundraising", styles['TableCell']),
     Paragraph("1", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter'])],
    [Paragraph("Editorial Director", styles['TableCell']), Paragraph("Content quality, editorial policy, team management", styles['TableCell']),
     Paragraph("1", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter'])],
    [Paragraph("Senior Editors", styles['TableCell']), Paragraph("Fact-checking, final editorial approval, mentoring", styles['TableCell']),
     Paragraph("2", styles['TableCellCenter']), Paragraph("4", styles['TableCellCenter']), Paragraph("6", styles['TableCellCenter'])],
    [Paragraph("Junior Editors", styles['TableCell']), Paragraph("Initial review, triage, contributor feedback", styles['TableCell']),
     Paragraph("3", styles['TableCellCenter']), Paragraph("6", styles['TableCellCenter']), Paragraph("10", styles['TableCellCenter'])],
    [Paragraph("Technology Lead", styles['TableCell']), Paragraph("Platform development, security, infrastructure", styles['TableCell']),
     Paragraph("1", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter'])],
    [Paragraph("Developers", styles['TableCell']), Paragraph("Frontend/backend development, mobile app", styles['TableCell']),
     Paragraph("2", styles['TableCellCenter']), Paragraph("3", styles['TableCellCenter']), Paragraph("4", styles['TableCellCenter'])],
    [Paragraph("Training Manager", styles['TableCell']), Paragraph("Curriculum design, course delivery, certification", styles['TableCell']),
     Paragraph("1", styles['TableCellCenter']), Paragraph("2", styles['TableCellCenter']), Paragraph("3", styles['TableCellCenter'])],
    [Paragraph("Recruitment Coordinator", styles['TableCell']), Paragraph("Enrollment, screening, community outreach", styles['TableCell']),
     Paragraph("1", styles['TableCellCenter']), Paragraph("2", styles['TableCellCenter']), Paragraph("3", styles['TableCellCenter'])],
    [Paragraph("Security Officer", styles['TableCell']), Paragraph("Contributor safety, digital security, risk assessment", styles['TableCell']),
     Paragraph("1", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter']), Paragraph("2", styles['TableCellCenter'])],
    [Paragraph("Finance Manager", styles['TableCell']), Paragraph("Accounting, payouts, financial reporting", styles['TableCell']),
     Paragraph("1", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter']), Paragraph("2", styles['TableCellCenter'])],
    [Paragraph("Marketing Manager", styles['TableCell']), Paragraph("Brand building, social media, audience growth", styles['TableCell']),
     Paragraph("0", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter']), Paragraph("2", styles['TableCellCenter'])],
    [Paragraph("NGO Partnership Mgr", styles['TableCell']), Paragraph("NGO relationships, joint initiatives", styles['TableCell']),
     Paragraph("0", styles['TableCellCenter']), Paragraph("1", styles['TableCellCenter']), Paragraph("2", styles['TableCellCenter'])],
    [Paragraph("Legal Counsel", styles['TableCell']), Paragraph("Legal compliance, contributor protection", styles['TableCell']),
     Paragraph("Part-time", styles['TableCellCenter']), Paragraph("Part-time", styles['TableCellCenter']), Paragraph("Full-time", styles['TableCellCenter'])],
    [Paragraph("<b>Total Headcount</b>", styles['TableCell']), Paragraph("", styles['TableCell']),
     Paragraph("<b>~14</b>", styles['TableCellCenter']), Paragraph("<b>~24</b>", styles['TableCellCenter']), Paragraph("<b>~37</b>", styles['TableCellCenter'])],
]
story.append(make_table(org_data, col_widths=[1.3*inch, 2.0*inch, 1.1*inch, 1.1*inch, 1.1*inch]))
spacer(8)

story.append(PageBreak())

# ══════════════════════════════════════════════════════════════
# B. FINANCE MODEL
# ══════════════════════════════════════════════════════════════
heading("B. FINANCE MODEL")
body(
    "The financial model for DCJN is designed to be self-sustaining by Year 3 while maintaining the social mission "
    "of empowering citizen journalists. The model relies on a diversified revenue strategy, a transparent point-based "
    "compensation system for contributors, and disciplined cost management. This section provides detailed financial "
    "projections, pricing strategies, and funding requirements based on conservative growth assumptions."
)

# B.1
heading("B.1 Point-Based Monetization System", level='sub')
body(
    "The point-based system is the core mechanism through which contributors are compensated for their work. It provides "
    "a transparent, gamified framework that rewards quality journalism while keeping costs predictable and aligned with "
    "revenue generation."
)

heading("B.1.1 How Points Are Earned", level='subsub')

points_data = [
    [Paragraph("<b>Activity</b>", styles['TableHeader']), Paragraph("<b>Points Awarded</b>", styles['TableHeader']),
     Paragraph("<b>Conditions</b>", styles['TableHeader']), Paragraph("<b>Approx. USD Value</b>", styles['TableHeader'])],
    [Paragraph("Standard News Report (Published)", styles['TableCell']), Paragraph("50-100", styles['TableCellCenter']),
     Paragraph("Meets all WH requirements, verified", styles['TableCell']), Paragraph("$2.50 - $5.00", styles['TableCellCenter'])],
    [Paragraph("Breaking News (Published within 6 hrs)", styles['TableCell']), Paragraph("100-200", styles['TableCellCenter']),
     Paragraph("Time-sensitive, high impact", styles['TableCell']), Paragraph("$5.00 - $10.00", styles['TableCellCenter'])],
    [Paragraph("Investigative / In-Depth Report", styles['TableCell']), Paragraph("200-500", styles['TableCellCenter']),
     Paragraph("Multi-source, requires significant effort", styles['TableCell']), Paragraph("$10.00 - $25.00", styles['TableCellCenter'])],
    [Paragraph("Follow-Up Report", styles['TableCell']), Paragraph("30-100", styles['TableCellCenter']),
     Paragraph("Update to previously published story", styles['TableCell']), Paragraph("$1.50 - $5.00", styles['TableCellCenter'])],
    [Paragraph("Photo Gallery (Min 5 photos)", styles['TableCell']), Paragraph("20-50", styles['TableCellCenter']),
     Paragraph("High-quality, original photos with captions", styles['TableCell']), Paragraph("$1.00 - $2.50", styles['TableCellCenter'])],
    [Paragraph("Successful Referral", styles['TableCell']), Paragraph("25", styles['TableCellCenter']),
     Paragraph("Referred candidate completes certification", styles['TableCell']), Paragraph("$1.25", styles['TableCellCenter'])],
    [Paragraph("Monthly Active Bonus", styles['TableCell']), Paragraph("50", styles['TableCellCenter']),
     Paragraph("Min 4 published reports in the month", styles['TableCell']), Paragraph("$2.50", styles['TableCellCenter'])],
    [Paragraph("Quality Bonus (4.5+ star avg)", styles['TableCell']), Paragraph("Additional 20%", styles['TableCellCenter']),
     Paragraph("Applied to all points earned that month", styles['TableCell']), Paragraph("20% premium", styles['TableCellCenter'])],
]
story.append(make_table(points_data, col_widths=[1.7*inch, 1.1*inch, 1.9*inch, 1.2*inch]))
spacer(8)

heading("B.1.2 Point Valuation & Payout Mechanism", level='subsub')
body(
    "The base point valuation is set at $0.05 per point (5 cents). This rate is calibrated to provide meaningful "
    "supplementary income for contributors in rural areas — where even $50-100 per month represents significant "
    "additional earnings — while remaining affordable for the organization as it scales. Point valuations are reviewed "
    "semi-annually and may be adjusted based on inflation, funding availability, and contributor feedback."
)
body(
    "Contributors can redeem their points once they accumulate a minimum of 500 points ($25). Payout options include: "
    "direct bank transfer (supported banks), mobile wallet transfer (UPI, bKash, M-Pesa depending on region), gift "
    "cards from popular retailers, and donation to a charity of the contributor's choice. Payouts are processed within "
    "7 business days of redemption request. Contributors receive a monthly statement detailing points earned, redeemed, "
    "and current balance."
)
body(
    "In addition to monetary payouts, top-performing contributors (top 10% quarterly) are eligible for non-monetary "
    "rewards including advanced journalism training scholarships, paid conference attendance opportunities, and "
    "exclusive access to investigative reporting tools and resources."
)

spacer()
# B.2
heading("B.2 Revenue Streams", level='sub')
body(
    "DCJN employs a diversified revenue model to reduce dependency on any single income source. The following five "
    "revenue streams are projected based on conservative growth assumptions."
)

heading("B.2.1 Advertising Revenue", level='subsub')
body(
    "Display advertising on the DCJN website and mobile app represents the primary revenue stream in the early years. "
    "The advertising strategy focuses on quality over quantity: DCJN will not use intrusive pop-ups, clickbait, or "
    "misleading ad formats. Instead, the platform offers premium ad placements (banner ads, sponsored content, "
    "newsletter sponsorships) targeted at socially-conscious brands, educational institutions, and development "
    "organizations. CPM rates are projected at $3-8 for display ads and $15-30 for sponsored newsletter placements. "
    "As the audience grows, programmatic advertising through Google AdX and premium direct deals will be pursued. "
    "The target is to generate $40,000 in advertising revenue in Year 1, growing to $250,000 by Year 3 as traffic "
    "reaches 500,000 monthly unique visitors."
)

heading("B.2.2 Subscriptions & Memberships", level='subsub')
body(
    "DCJN offers a premium membership tier for readers who want enhanced access. The 'DCJN Insider' membership "
    "(priced at $4.99/month or $49/year) provides: ad-free reading experience, early access to investigative reports "
    "(48-hour exclusive window), access to contributor stories behind the scenes, a weekly curated newsletter with "
    "analysis, and quarterly impact reports. The free tier remains available to all, ensuring that no content is "
    "paywalled — the premium tier adds value without restricting access. Conversion rate target is 2-3% of monthly "
    "active readers. Projected Year 1 subscription revenue: $15,000; Year 3: $120,000."
)

heading("B.2.3 NGO & Institutional Partnerships", level='subsub')
body(
    "Partnerships with NGOs and development organizations generate revenue through sponsored reporting projects, "
    "data-sharing agreements, and joint research initiatives. For example, an NGO focused on rural education may "
    "commission DCJN to produce a series of reports on school infrastructure across 10 districts, paying a project "
    "fee of $5,000-15,000. DCJN also offers data licensing: anonymized, aggregated data from contributor reports "
    "(e.g., trends in government service delivery, infrastructure complaints) can be licensed to research institutions "
    "and policy think tanks. Projected Year 1 partnership revenue: $25,000; Year 3: $150,000."
)

heading("B.2.4 Content Syndication & Licensing", level='subsub')
body(
    "Original, verified content produced by DCJN can be syndicated to mainstream media outlets, wire services, and "
    "digital platforms. Content licensing deals are structured per-article or as monthly subscriptions. DCJN targets "
    "partnerships with 3-5 regional and national media outlets for content sharing agreements by Year 2. Additionally, "
    "evergreen content (guides, explainers, data-driven features) can be licensed to educational institutions and "
    "training programs. Projected Year 2 syndication revenue: $20,000; Year 3: $80,000."
)

heading("B.2.5 Grants & Philanthropic Funding", level='subsub')
body(
    "As a social enterprise focused on media democratization and rural empowerment, DCJN is well-positioned to "
    "receive grant funding from foundations focused on journalism, democracy, and human rights. Target funders include "
    "the Google News Initiative, the Open Society Foundations, the Thomson Reuters Foundation, the Ford Foundation, "
    "and the National Endowment for Democracy. Grant applications will be prepared for 2-3 major opportunities per "
    "year. Projected Year 1 grant income: $50,000; Year 3: $100,000 (reduced as commercial revenue grows)."
)

spacer()
# B.3
heading("B.3 Cost Structure", level='sub')

heading("B.3.1 Fixed Costs (Monthly)", level='subsub')

fixed_data = [
    [Paragraph("<b>Cost Category</b>", styles['TableHeader']), Paragraph("<b>Year 1 (Monthly)</b>", styles['TableHeader']),
     Paragraph("<b>Year 2 (Monthly)</b>", styles['TableHeader']), Paragraph("<b>Year 3 (Monthly)</b>", styles['TableHeader'])],
    [Paragraph("Office Space (Co-working)", styles['TableCell']), Paragraph("$500", styles['TableCellCenter']),
     Paragraph("$800", styles['TableCellCenter']), Paragraph("$1,200", styles['TableCellCenter'])],
    [Paragraph("Core Staff Salaries (FTE)", styles['TableCell']), Paragraph("$15,000", styles['TableCellCenter']),
     Paragraph("$28,000", styles['TableCellCenter']), Paragraph("$45,000", styles['TableCellCenter'])],
    [Paragraph("Legal Retainer", styles['TableCell']), Paragraph("$1,000", styles['TableCellCenter']),
     Paragraph("$1,500", styles['TableCellCenter']), Paragraph("$2,500", styles['TableCellCenter'])],
    [Paragraph("Insurance (General + Cyber)", styles['TableCell']), Paragraph("$500", styles['TableCellCenter']),
     Paragraph("$800", styles['TableCellCenter']), Paragraph("$1,200", styles['TableCellCenter'])],
    [Paragraph("Accounting & Compliance", styles['TableCell']), Paragraph("$300", styles['TableCellCenter']),
     Paragraph("$500", styles['TableCellCenter']), Paragraph("$800", styles['TableCellCenter'])],
    [Paragraph("Internet & Utilities", styles['TableCell']), Paragraph("$200", styles['TableCellCenter']),
     Paragraph("$300", styles['TableCellCenter']), Paragraph("$400", styles['TableCellCenter'])],
    [Paragraph("<b>Monthly Fixed Total</b>", styles['TableCell']), Paragraph("<b>$17,500</b>", styles['TableCellCenter']),
     Paragraph("<b>$31,900</b>", styles['TableCellCenter']), Paragraph("<b>$51,100</b>", styles['TableCellCenter'])],
]
story.append(make_table(fixed_data, col_widths=[2.0*inch, 1.4*inch, 1.4*inch, 1.4*inch]))
spacer(8)

heading("B.3.2 Variable Costs (Monthly)", level='subsub')

variable_data = [
    [Paragraph("<b>Cost Category</b>", styles['TableHeader']), Paragraph("<b>Year 1 (Monthly)</b>", styles['TableHeader']),
     Paragraph("<b>Year 2 (Monthly)</b>", styles['TableHeader']), Paragraph("<b>Year 3 (Monthly)</b>", styles['TableHeader'])],
    [Paragraph("Contributor Payouts (Points)", styles['TableCell']), Paragraph("$2,500", styles['TableCellCenter']),
     Paragraph("$8,000", styles['TableCellCenter']), Paragraph("$20,000", styles['TableCellCenter'])],
    [Paragraph("Cloud Hosting (AWS/GCP)", styles['TableCell']), Paragraph("$400", styles['TableCellCenter']),
     Paragraph("$800", styles['TableCellCenter']), Paragraph("$1,500", styles['TableCellCenter'])],
    [Paragraph("Marketing & Advertising", styles['TableCell']), Paragraph("$2,000", styles['TableCellCenter']),
     Paragraph("$4,000", styles['TableCellCenter']), Paragraph("$6,000", styles['TableCellCenter'])],
    [Paragraph("Freelance Editorial Support", styles['TableCell']), Paragraph("$1,000", styles['TableCellCenter']),
     Paragraph("$2,500", styles['TableCellCenter']), Paragraph("$4,000", styles['TableCellCenter'])],
    [Paragraph("Training Materials & Tools", styles['TableCell']), Paragraph("$500", styles['TableCellCenter']),
     Paragraph("$800", styles['TableCellCenter']), Paragraph("$1,200", styles['TableCellCenter'])],
    [Paragraph("Software Licenses (CMS, Analytics)", styles['TableCell']), Paragraph("$300", styles['TableCellCenter']),
     Paragraph("$500", styles['TableCellCenter']), Paragraph("$700", styles['TableCellCenter'])],
    [Paragraph("Payment Processing Fees (2.9%)", styles['TableCell']), Paragraph("$200", styles['TableCellCenter']),
     Paragraph("$600", styles['TableCellCenter']), Paragraph("$1,500", styles['TableCellCenter'])],
    [Paragraph("<b>Monthly Variable Total</b>", styles['TableCell']), Paragraph("<b>$6,900</b>", styles['TableCellCenter']),
     Paragraph("<b>$17,200</b>", styles['TableCellCenter']), Paragraph("<b>$34,900</b>", styles['TableCellCenter'])],
]
story.append(make_table(variable_data, col_widths=[2.0*inch, 1.4*inch, 1.4*inch, 1.4*inch]))
spacer(8)

spacer()
# B.4
heading("B.4 Pricing Strategy for Training Course", level='sub')
body(
    "The training course pricing follows a tiered model designed to maximize accessibility while generating revenue "
    "from those who can afford to pay. The fundamental principle is that financial constraints should never prevent "
    "a qualified individual from becoming a citizen journalist."
)

pricing_data = [
    [Paragraph("<b>Tier</b>", styles['TableHeader']), Paragraph("<b>Price</b>", styles['TableHeader']),
     Paragraph("<b>Target Audience</b>", styles['TableHeader']), Paragraph("<b>Includes</b>", styles['TableHeader'])],
    [Paragraph("Full Scholarship", styles['TableCell']), Paragraph("$0 (Free)", styles['TableCellCenter']),
     Paragraph("Students from low-income backgrounds, rural areas with limited connectivity", styles['TableCell']),
     Paragraph("Full course access, certification, all features", styles['TableCell'])],
    [Paragraph("Student Discount", styles['TableCell']), Paragraph("$15", styles['TableCellCenter']),
     Paragraph("Currently enrolled students with valid student ID", styles['TableCell']),
     Paragraph("Full course access, certification, student community access", styles['TableCell'])],
    [Paragraph("Standard", styles['TableCell']), Paragraph("$49", styles['TableCellCenter']),
     Paragraph("General public, working professionals", styles['TableCell']),
     Paragraph("Full course access, certification, priority editorial support", styles['TableCell'])],
    [Paragraph("Premium", styles['TableCell']), Paragraph("$99", styles['TableCellCenter']),
     Paragraph("Professionals seeking advanced skills, NGO staff", styles['TableCell']),
     Paragraph("All Standard features + advanced security module, 1-on-1 mentoring session, certificate with distinction", styles['TableCell'])],
]
story.append(make_table(pricing_data, col_widths=[1.2*inch, 0.8*inch, 2.0*inch, 2.4*inch]))
spacer(8)

body(
    "Scholarship allocation follows a means-testing approach: applicants provide a brief statement of financial need "
    "along with their enrollment form. Scholarships are funded through a combination of grant money and cross-subsidization "
    "from paid tiers. The target allocation is: 40% Full Scholarship, 30% Student Discount, 25% Standard, 5% Premium. "
    "This mix is projected to yield an average revenue of $15 per enrollment in Year 1, growing to $20 as the proportion "
    "of paid enrollees increases."
)
body(
    "Special group rates are available for institutional partnerships: NGOs, colleges, and community organizations can "
    "enroll groups of 10 or more participants at a 30% discount on the Student or Standard tier. Corporate social "
    "responsibility (CSR) sponsors can fund entire cohorts, receiving branding credit on the DCJN website and impact "
    "reports."
)

spacer()
# B.5
heading("B.5 Financial Projections (Year 1-3)", level='sub')
body(
    "The following projections are based on conservative assumptions: 500 contributors by end of Year 1, 1,500 by "
    "end of Year 2, and 4,000 by end of Year 3. Each contributor submits an average of 4 stories per month, with a "
    "60% publication rate. Website traffic grows from 50,000 monthly visitors in Year 1 to 500,000 by Year 3."
)

proj_data = [
    [Paragraph("<b>Line Item</b>", styles['TableHeader']), Paragraph("<b>Year 1</b>", styles['TableHeader']),
     Paragraph("<b>Year 2</b>", styles['TableHeader']), Paragraph("<b>Year 3</b>", styles['TableHeader'])],
    [Paragraph("<b>REVENUE</b>", styles['TableCell']), Paragraph("", styles['TableCell']),
     Paragraph("", styles['TableCell']), Paragraph("", styles['TableCell'])],
    [Paragraph("  Advertising", styles['TableCell']), Paragraph("$40,000", styles['TableCellCenter']),
     Paragraph("$120,000", styles['TableCellCenter']), Paragraph("$250,000", styles['TableCellCenter'])],
    [Paragraph("  Subscriptions", styles['TableCell']), Paragraph("$15,000", styles['TableCellCenter']),
     Paragraph("$55,000", styles['TableCellCenter']), Paragraph("$120,000", styles['TableCellCenter'])],
    [Paragraph("  NGO Partnerships", styles['TableCell']), Paragraph("$25,000", styles['TableCellCenter']),
     Paragraph("$80,000", styles['TableCellCenter']), Paragraph("$150,000", styles['TableCellCenter'])],
    [Paragraph("  Content Syndication", styles['TableCell']), Paragraph("$0", styles['TableCellCenter']),
     Paragraph("$20,000", styles['TableCellCenter']), Paragraph("$80,000", styles['TableCellCenter'])],
    [Paragraph("  Grants & Philanthropy", styles['TableCell']), Paragraph("$50,000", styles['TableCellCenter']),
     Paragraph("$75,000", styles['TableCellCenter']), Paragraph("$100,000", styles['TableCellCenter'])],
    [Paragraph("  Training Course Revenue", styles['TableCell']), Paragraph("$10,000", styles['TableCellCenter']),
     Paragraph("$35,000", styles['TableCellCenter']), Paragraph("$90,000", styles['TableCellCenter'])],
    [Paragraph("<b>Total Revenue</b>", styles['TableCell']), Paragraph("<b>$140,000</b>", styles['TableCellCenter']),
     Paragraph("<b>$385,000</b>", styles['TableCellCenter']), Paragraph("<b>$790,000</b>", styles['TableCellCenter'])],
    [Paragraph("", styles['TableCell']), Paragraph("", styles['TableCell']),
     Paragraph("", styles['TableCell']), Paragraph("", styles['TableCell'])],
    [Paragraph("<b>EXPENSES</b>", styles['TableCell']), Paragraph("", styles['TableCell']),
     Paragraph("", styles['TableCell']), Paragraph("", styles['TableCell'])],
    [Paragraph("  Fixed Costs (Annual)", styles['TableCell']), Paragraph("$210,000", styles['TableCellCenter']),
     Paragraph("$382,800", styles['TableCellCenter']), Paragraph("$613,200", styles['TableCellCenter'])],
    [Paragraph("  Variable Costs (Annual)", styles['TableCell']), Paragraph("$82,800", styles['TableCellCenter']),
     Paragraph("$206,400", styles['TableCellCenter']), Paragraph("$418,800", styles['TableCellCenter'])],
    [Paragraph("  Platform Development (One-time)", styles['TableCell']), Paragraph("$80,000", styles['TableCellCenter']),
     Paragraph("$40,000", styles['TableCellCenter']), Paragraph("$50,000", styles['TableCellCenter'])],
    [Paragraph("<b>Total Expenses</b>", styles['TableCell']), Paragraph("<b>$372,800</b>", styles['TableCellCenter']),
     Paragraph("<b>$629,200</b>", styles['TableCellCenter']), Paragraph("<b>$1,082,000</b>", styles['TableCellCenter'])],
    [Paragraph("", styles['TableCell']), Paragraph("", styles['TableCell']),
     Paragraph("", styles['TableCell']), Paragraph("", styles['TableCell'])],
    [Paragraph("<b>Net Income / (Loss)</b>", styles['TableCell']), Paragraph("<b>($232,800)</b>", styles['TableCellCenter']),
     Paragraph("<b>($244,200)</b>", styles['TableCellCenter']), Paragraph("<b>($292,000)</b>", styles['TableCellCenter'])],
    [Paragraph("Cumulative Position", styles['TableCell']), Paragraph("($232,800)", styles['TableCellCenter']),
     Paragraph("($477,000)", styles['TableCellCenter']), Paragraph("($769,000)", styles['TableCellCenter'])],
]
story.append(make_table(proj_data, col_widths=[2.0*inch, 1.3*inch, 1.3*inch, 1.3*inch]))
spacer(8)

story.append(Paragraph(
    "<i>Note: These projections reflect the startup phase where significant investment is required in platform development, "
    "team building, and contributor network expansion. Revenue ramps significantly from Year 2 as the contributor network "
    "and audience scale. Adjusted projections assuming a $200,000 seed funding injection are presented in the Break-even "
    "Analysis below.</i>", styles['FooterNote']))

spacer()
# B.6
heading("B.6 Break-Even Analysis", level='sub')
body(
    "Based on the projections above, DCJN requires external funding to cover operating losses during the first 3-4 years. "
    "The break-even analysis examines when the organization will generate sufficient revenue to cover all operating costs "
    "without grant funding."
)

body("<b>Key Assumptions:</b>")
bullet("Monthly operating costs grow linearly with contributor network size")
bullet("Revenue per contributor (advertising + subscriptions + syndication per published story) averages $0.80 per published story")
bullet("Contributor publication rate holds at 60% of submissions")
bullet("Average submissions per contributor: 4 per month")

body("<b>Break-Even Calculation:</b>")
body(
    "At break-even: Total Monthly Revenue = Total Monthly Costs. In Year 3, monthly costs are projected at $86,000 "
    "(fixed $51,100 + variable $34,900). With 4,000 contributors each submitting 4 stories per month (16,000 submissions), "
    "at 60% publication rate = 9,600 published stories. Revenue per published story must be: $86,000 / 9,600 = $8.96. "
    "Current projected revenue per published story is approximately $6.85, indicating a gap of $2.11 per story."
)
body(
    "To bridge this gap, DCJN can: (a) increase the advertising CPM through premium direct deals (targeting $10+ CPM "
    "by Year 3), (b) grow the subscription base to 5% conversion rate (from 2-3%), (c) expand NGO partnership revenue "
    "through larger commissioned projects, and (d) increase content syndication volume. With these optimizations, "
    "break-even is projected at Month 42 (mid-Year 4) when the contributor base reaches approximately 6,000 and monthly "
    "unique visitors exceed 800,000. Total funding required to reach break-even: approximately $500,000 over 3.5 years."
)

spacer()
# B.7
heading("B.7 Funding Strategy", level='sub')

heading("B.7.1 Seed Funding Round (Target: $200,000)", level='subsub')
body(
    "The initial seed round provides the capital necessary to build the platform, hire the core team, and launch the "
    "first pilot program. Funding sources include: founder's personal investment ($30,000), angel investors focused on "
    "media/tech/social enterprise ($100,000), and early-stage grants from journalism foundations ($70,000). Seed funds "
    "are allocated as follows: platform development (40%), initial hiring (30%), marketing and recruitment (15%), "
    "legal and compliance setup (10%), and operational contingency (5%)."
)

heading("B.7.2 Series A / Growth Funding (Target: $300,000 - Year 2)", level='subsub')
body(
    "After validating the model in the pilot phase (demonstrating contributor engagement, publication quality, and "
    "early revenue traction), DCJN will pursue a Series A round from impact investors and media-focused venture capital. "
    "This funding supports scaling the contributor network to 1,500+, expanding into new geographic regions, building "
    "the mobile app, and growing the editorial team. Key milestones required before this raise: 500+ certified contributors, "
    "1,000+ published stories, 50,000+ monthly website visitors, and at least 2 signed NGO partnership agreements."
)

heading("B.7.3 Revenue Reinvestment", level='subsub')
body(
    "As commercial revenue grows, DCJN follows a 60/40 reinvestment policy: 60% of net revenue (after contributor payouts) "
    "is reinvested into platform improvement, team expansion, and contributor training, while 40% is allocated to "
    "operational reserves and debt service (if any). This policy ensures sustainable growth without over-reliance on "
    "external funding. By Year 4, the goal is for DCJN to be cash-flow positive on operational revenue, with external "
    "funding reserved for strategic expansion initiatives."
)

story.append(PageBreak())

# ══════════════════════════════════════════════════════════════
# C. NGO & HUMAN RIGHTS PARTNERSHIP STRATEGY
# ══════════════════════════════════════════════════════════════
heading("C. NGO & HUMAN RIGHTS PARTNERSHIP STRATEGY")
body(
    "Strategic partnerships with non-governmental organizations (NGOs) and human rights bodies form a critical pillar "
    "of DCJN's sustainability and impact. These partnerships serve dual purposes: they provide a credible amplification "
    "channel for stories that require advocacy or intervention, and they create a revenue stream through commissioned "
    "reporting projects. This section outlines the partnership framework, value propositions, and engagement models."
)

heading("C.1 Partnership Models", level='sub')
body("DCJN offers four distinct partnership models, each designed to accommodate different levels of engagement and organizational capacity:")

body("<b>Model 1: Content Partnership (Lightweight)</b>")
bullet("NGO shares DCJN content on their channels; DCJN amplifies NGO research and reports")
bullet("Mutual cross-linking and social media sharing")
bullet("No financial exchange; both parties benefit from increased reach")
bullet("Ideal for: small to medium NGOs, local community organizations")

body("<b>Model 2: Commissioned Reporting Project (Medium Engagement)</b>")
bullet("NGO commissions DCJN to produce specific investigative reports or data-gathering projects")
bullet("Scoping: DCJN assigns trained contributors to the geographic area of interest")
bullet("Deliverables: 5-15 original reports, data summary, photo documentation")
bullet("Pricing: $5,000 - $25,000 per project depending on scope and duration")
bullet("Ideal for: international development agencies, policy research organizations, large national NGOs")

body("<b>Model 3: Embedded Correspondent Program (High Engagement)</b>")
bullet("NGO sponsors a cohort of 10-20 DCJN contributors in a specific region")
bullet("Contributors receive training and work on a combination of general reporting and NGO-specified topics")
bullet("NGO receives regular reporting dashboards, quarterly data briefs, and priority access to relevant content")
bullet("Annual partnership fee: $15,000 - $50,000 depending on cohort size and reporting requirements")
bullet("Ideal for: UN agencies, large international NGOs (e.g., Amnesty International, Human Rights Watch), bilateral aid agencies")

body("<b>Model 4: Advocacy Coalition (Strategic)</b>")
bullet("DCJN joins multi-stakeholder advocacy coalitions focused on media freedom, transparency, and human rights")
bullet("Contributes citizen-reported evidence to advocacy campaigns")
bullet("Coalition members collaboratively produce annual 'State of Rural News' reports")
bullet("Shared resources for legal defense, safety training, and policy advocacy")
bullet("Ideal for: press freedom organizations, media development agencies, democracy advocacy groups")

heading("C.2 Value Proposition for NGOs", level='sub')
body(
    "NGOs gain several unique advantages from partnering with DCJN that are difficult to obtain through traditional "
    "monitoring and evaluation methods:"
)
bullet("<b>Real-time ground intelligence:</b> DCJN contributors provide ongoing, localized reporting from communities that NGOs often struggle to monitor continuously. This creates an always-on sensor network that detects emerging issues before they become crises.")
bullet("<b>Cost-effective monitoring:</b> Compared to deploying dedicated field staff or hiring consultants, DCJN's distributed model provides monitoring coverage at a fraction of the cost. A cohort of 20 contributors can cover an entire district for less than the cost of one full-time field officer.")
bullet("<b>Authentic community voice:</b> DCJN stories are written by community members themselves, providing authentic first-person perspectives that resonate more powerfully with audiences, donors, and policymakers than third-party reports.")
bullet("<b>Verifiable evidence:</b> The DCJN editorial verification process ensures that all published content meets journalistic standards of accuracy, making the evidence more credible for advocacy purposes, legal proceedings, and policy recommendations.")
bullet("<b>Data-driven insights:</b> Aggregated data from thousands of contributor reports can reveal trends, patterns, and correlations that are invisible at the individual story level. This quantitative evidence strengthens grant proposals and policy briefs.")

heading("C.3 Joint Reporting Initiatives", level='sub')
body(
    "DCJN proactively designs joint reporting initiatives that align with the thematic priorities of potential NGO "
    "partners. Examples include:"
)
bullet("<b>Right to Education Audit:</b> A semester-long project where contributors in 50 districts document school infrastructure, teacher attendance, midday meal quality, and enrollment data. Partners: education-focused NGOs, government accountability organizations.")
bullet("<b>Healthcare Access Survey:</b> Contributors report on the availability and quality of primary healthcare services — medicine stock, doctor presence, equipment functionality, and patient experiences. Partners: public health organizations, health rights groups.")
bullet("<b>Environmental Impact Monitor:</b> Contributors document deforestation, water pollution, industrial waste dumping, and the impact of climate change on agriculture in their communities. Partners: environmental NGOs, climate advocacy organizations.")
bullet("<b>Gender Safety Index:</b> Women contributors report on street harassment, domestic violence support infrastructure, workplace safety, and access to justice. Partners: women's rights organizations, gender equality advocates.")

heading("C.4 Advocacy Collaboration", level='sub')
body(
    "Beyond reporting, DCJN serves as an advocacy multiplier for NGO partners. When a DCJN story exposes a systemic "
    "issue — for example, corruption in a government housing scheme — the NGO partner can use that story as evidence "
    "in their advocacy efforts: filing public interest litigations, lobbying legislators, engaging international human "
    "rights bodies, and generating public awareness campaigns. DCJN contributes to these efforts by providing verified, "
    "timely, and localized evidence that grounds advocacy in concrete reality rather than abstract statistics."
)
body(
    "DCJN also participates in annual advocacy events such as World Press Freedom Day, International Human Rights Day, "
    "and the Right to Information Week by producing special investigative packages, hosting webinars with contributor "
    "testimonials (anonymized), and releasing impact reports quantifying the organization's contribution to transparency "
    "and accountability in covered regions."
)

story.append(PageBreak())

# ══════════════════════════════════════════════════════════════
# D. LEGAL & ETHICAL FRAMEWORK
# ══════════════════════════════════════════════════════════════
heading("D. LEGAL & ETHICAL FRAMEWORK")
body(
    "A robust legal and ethical framework is essential for protecting DCJN, its contributors, editorial team, and "
    "the communities it serves. Given the sensitive nature of citizen journalism — particularly in regions where "
    "reporting on corruption, human rights violations, and government misconduct carries personal risk — this "
    "framework must be comprehensive, proactive, and adaptable to evolving legal landscapes."
)

heading("D.1 Contributor Agreements", level='sub')
body(
    "Every individual who enrolls in the DCJN training program signs a Contributor Agreement (electronically via the "
    "platform). This agreement covers the following key provisions:"
)
bullet("<b>Role definition:</b> Contributors are classified as independent contractors, not employees. This distinction is important for tax purposes and to avoid creating employment obligations. However, DCJN provides certain protections typically associated with employment (safety support, legal assistance) as a matter of ethical commitment.")
bullet("<b>Scope of work:</b> Contributors agree to submit original, factual news reports following the WH-question format. They agree not to fabricate, plagiarize, or distort information. They agree to follow the DCJN editorial guidelines and code of conduct.")
bullet("<b>Compensation terms:</b> The agreement clearly outlines the point-based compensation system, including point values, earning criteria, minimum redemption thresholds, and payout methods. It also states that point values may be adjusted with 30 days' notice.")
bullet("<b>Confidentiality:</b> Contributors agree to maintain the confidentiality of their involvement with DCJN. They agree not to publicly identify themselves as DCJN contributors or share internal operational details with third parties.")
bullet("<b>Termination:</b> Either party may terminate the agreement at any time with written notice. DCJN reserves the right to terminate immediately for violations of the code of conduct, submission of fabricated content, or breach of confidentiality.")
bullet("<b>Dispute resolution:</b> Disputes are first addressed through internal mediation. If unresolved, they are referred to an independent arbitration panel comprising one DCJN representative, one contributor representative, and one neutral third party.")

heading("D.2 Content Ownership", level='sub')
body(
    "Content ownership is structured to balance the interests of contributors, the organization, and the public good. "
    "Contributors retain moral rights (attribution) over their work. Upon submission, contributors grant DCJN a "
    "non-exclusive, worldwide, perpetual license to publish, distribute, and modify the content for editorial purposes. "
    "The license includes the right to sublicense content to syndication partners and media outlets. Contributors "
    "retain the right to use their submissions for non-commercial purposes (e.g., portfolio, educational use) but "
    "may not sell the same content to competing outlets without DCJN's written consent. This structure ensures that "
    "DCJN can effectively distribute and monetize content while respecting contributors' creative ownership."
)

heading("D.3 Liability Protection", level='sub')
body(
    "DCJN implements multiple layers of liability protection:"
)
bullet("<b>Editorial liability insurance:</b> A media liability insurance policy (errors & omissions coverage) of $1 million per claim protects against defamation lawsuits arising from published content.")
bullet("<b>Contributor indemnification:</b> The Contributor Agreement includes indemnification clauses where contributors warrant that their submissions are accurate to the best of their knowledge. However, DCJN accepts ultimate editorial responsibility for published content and does not pass legal liability to individual contributors.")
bullet("<b>Safe harbor provisions:</b> DCJN's editorial review process serves as a 'reasonable care' defense, demonstrating that the organization takes active steps to verify content before publication. This is a critical defense in defamation and media liability cases.")
bullet("<b>Entity structure:</b> DCJN is registered as a limited liability entity (LLC or equivalent), separating the organization's liabilities from the personal assets of founders and investors.")
bullet("<b>Content disclaimers:</b> Published stories include clear disclaimers that the views expressed are those of the anonymous contributor and do not necessarily represent DCJN's editorial position. The website also includes a detailed 'Corrections and Feedback' policy.")

heading("D.4 Ethical Guidelines", level='sub')
body(
    "DCJN's ethical guidelines are modeled on international journalism standards (adapted from the Society of Professional "
    "Journalists Code of Ethics, the BBC Editorial Guidelines, and the Ethical Journalism Network principles) with "
    "specific modifications for the citizen journalism context:"
)
bullet("<b>Truth and accuracy above all:</b> Every effort must be made to verify facts before publication. When facts cannot be fully verified, the story must clearly state what is confirmed and what remains unverified.")
bullet("<b>Independence:</b> Contributors and editors must act independently of commercial, political, and personal interests. No story should be influenced by advertising relationships, NGO partnerships, or personal biases.")
bullet("<b>Minimizing harm:</b> Editors must carefully weigh the public interest value of a story against the potential harm it may cause to individuals — particularly vulnerable populations such as minors, victims of crime, and marginalized communities. Identifying details should be removed unless editorially essential.")
bullet("<b>Privacy and consent:</b> Contributors must obtain consent before interviewing or photographing individuals in private settings. Exceptions apply only when the story involves matters of significant public interest (e.g., government corruption) and the individual is a public official.")
bullet("<b>No payment for news:</b> DCJN does not pay sources for information (checkbook journalism) as this compromises the integrity of the reporting.")
bullet("<b>Correction and accountability:</b> Errors must be corrected promptly and transparently. The organization maintains a public corrections log and encourages readers to report inaccuracies.")

story.append(PageBreak())

# ══════════════════════════════════════════════════════════════
# E. RISK MANAGEMENT
# ══════════════════════════════════════════════════════════════
heading("E. RISK MANAGEMENT")
body(
    "Operating a citizen journalism network in rural and often politically sensitive environments involves significant "
    "risks that must be systematically identified, assessed, and mitigated. This section catalogs the major risk "
    "categories and provides specific mitigation strategies for each."
)

heading("E.1 Contributor Safety Risks", level='sub')
body(
    "The most critical risk facing DCJN is the physical and psychological safety of its contributors. Contributors "
    "operating in rural areas may face threats from local power brokers, criminal elements, or government officials "
    "who do not want their activities reported. Women contributors face additional gender-based risks including "
    "harassment, social stigma, and physical danger."
)

risk_data = [
    [Paragraph("<b>Risk</b>", styles['TableHeader']), Paragraph("<b>Severity</b>", styles['TableHeader']),
     Paragraph("<b>Probability</b>", styles['TableHeader']), Paragraph("<b>Mitigation</b>", styles['TableHeader'])],
    [Paragraph("Physical assault by subjects of reporting", styles['TableCell']),
     Paragraph("Critical", styles['TableCellCenter']), Paragraph("Medium", styles['TableCellCenter']),
     Paragraph("Mandatory safety training, risk assessment before every assignment, duress code system, legal support network, emergency evacuation fund", styles['TableCell'])],
    [Paragraph("Legal harassment (false cases, defamation suits)", styles['TableCell']),
     Paragraph("High", styles['TableCellCenter']), Paragraph("High", styles['TableCellCenter']),
     Paragraph("Media liability insurance, legal retainer in each operational state, editorial review ensures defensibility of every story, contributor indemnification policy", styles['TableCell'])],
    [Paragraph("Digital surveillance / hacking", styles['TableCell']),
     Paragraph("High", styles['TableCellCenter']), Paragraph("Medium", styles['TableCellCenter']),
     Paragraph("Encrypted communications, VPN service for contributors, quarterly security audits, contributor digital security training, compartmentalized data architecture", styles['TableCell'])],
    [Paragraph("Identity exposure (doxxing)", styles['TableCell']),
     Paragraph("Critical", styles['TableCellCenter']), Paragraph("Low", styles['TableCellCenter']),
     Paragraph("Anonymous pen names, no public contributor profiles, data compartmentalization, regular penetration testing, incident response plan for data breaches", styles['TableCell'])],
    [Paragraph("Psychological trauma from witnessing violence/crime", styles['TableCell']),
     Paragraph("Medium", styles['TableCellCenter']), Paragraph("Medium", styles['TableCellCenter']),
     Paragraph("Mandatory mental health resources, volunteer counselor network, option to decline sensitive assignments without penalty, annual wellness check-ins", styles['TableCell'])],
]
story.append(make_table(risk_data, col_widths=[1.6*inch, 0.7*inch, 0.8*inch, 3.3*inch]))
spacer(8)

heading("E.2 Legal & Regulatory Risks", level='sub')
body(
    "Media organizations face a complex and evolving legal landscape. Key legal risks include:"
)
bullet("<b>Defamation liability:</b> Published stories may contain inaccuracies that lead to defamation claims. Mitigation: rigorous editorial verification process, media liability insurance, legal review of sensitive stories, and prompt correction policy.")
bullet("<b>Content regulation:</b> Governments may impose restrictions on media content, particularly content related to government criticism or national security. Mitigation: maintain a registered legal entity, comply with all applicable media laws, engage a media law specialist, and build relationships with press freedom organizations.")
bullet("<b>Data protection compliance:</b> DCJN collects personal data from contributors and handles sensitive information. Mitigation: comply with applicable data protection laws (GDPR, local equivalents), appoint a Data Protection Officer, conduct privacy impact assessments, and maintain transparent data handling practices.")
bullet("<b>Cross-border legal complexity:</b> As DCJN expands across regions or countries, varying legal frameworks create complexity. Mitigation: engage local legal counsel in each jurisdiction, maintain a legal compliance database, and train editorial staff on jurisdiction-specific requirements.")

heading("E.3 Reputational Risks", level='sub')
body(
    "DCJN's credibility is its most valuable asset. Reputational risks include:"
)
bullet("<b>Publication of false information:</b> A contributor submitting fabricated content that passes editorial review. Mitigation: multi-layer verification, fact-checking standards, anonymous tip line for reporting internal issues, and public corrections policy.")
bullet("<b>Contributor misconduct:</b> A contributor using their DCJN role for personal gain, harassment, or unethical behavior. Mitigation: background screening during enrollment, code of conduct enforcement, and immediate termination policy for violations.")
bullet("<b>Perceived political bias:</b> Accusations that DCJN favors certain political viewpoints. Mitigation: strict editorial independence policy, balanced coverage guidelines, regular internal audits for bias, and diverse editorial team composition.")
bullet("<b>Platform security breach:</b> A data breach exposing contributor identities. Mitigation: encrypted storage, regular security audits, bug bounty program, and a documented incident response plan including legal notification procedures.")

heading("E.4 Operational & Financial Risks", level='sub')
body(
    "Operational risks include platform downtime, contributor attrition, and editorial bottlenecks. Mitigation: "
    "multi-region cloud hosting with 99.9% uptime SLA, contributor retention programs (quality bonuses, recognition, "
    "career development), and scalable editorial processes with clear escalation protocols. Financial risks include "
    "revenue shortfalls and funding gaps. Mitigation: maintain 6-month operating reserve, diversify revenue streams, "
    "and build relationships with multiple funding sources to avoid dependency on any single donor or advertiser."
)

story.append(PageBreak())

# ══════════════════════════════════════════════════════════════
# F. GROWTH STRATEGY
# ══════════════════════════════════════════════════════════════
heading("F. GROWTH STRATEGY")
body(
    "DCJN's growth strategy is designed to be deliberate, phased, and sustainable. Rather than pursuing rapid expansion "
    "at the expense of quality and safety, the strategy prioritizes building depth in initial markets before scaling "
    "geographically. Each phase has clear milestones that must be achieved before advancing to the next."
)

heading("F.1 Phase-Wise Expansion", level='sub')

body("<b>Phase 1 — Foundation (Months 1-12):</b>")
bullet("Focus on 2-3 districts within a single state")
bullet("Target: 500 certified contributors, 2,000+ published stories")
bullet("Build and refine all operational systems: training, editorial, technology, security")
bullet("Establish 2-3 NGO partnerships as proof of concept")
bullet("Achieve 50,000 monthly unique visitors to the website")
bullet("Validate the point-based monetization model and adjust pricing as needed")
bullet("Key milestone: Positive contributor retention rate of 60%+ after 6 months")

body("<b>Phase 2 — Consolidation (Months 13-24):</b>")
bullet("Expand to 8-10 districts across 2-3 states")
bullet("Target: 1,500 certified contributors, 8,000+ published stories")
bullet("Launch the mobile app (iOS and Android)")
bullet("Hire additional editorial and security staff")
bullet("Develop premium membership tier and content syndication pipeline")
bullet("Sign 5-10 NGO partnership agreements")
bullet("Achieve 200,000 monthly unique visitors")
bullet("Key milestone: Revenue covers 40%+ of operating costs")

body("<b>Phase 3 — Scaling (Months 25-48):</b>")
bullet("Expand to 25-30 districts across 5-8 states")
bullet("Target: 4,000+ certified contributors, 25,000+ published stories")
bullet("Establish regional editorial hubs for faster turnaround")
bullet("Launch advanced training modules: investigative journalism, data journalism, multimedia storytelling")
bullet("Achieve 500,000+ monthly unique visitors")
bullet("Begin content syndication with 5+ mainstream media outlets")
bullet("Key milestone: Operating cash flow positive or within 20% of break-even")

body("<b>Phase 4 — Leadership & Influence (Year 4+):</b>")
bullet("National presence with contributor network in 50+ districts")
bullet("Position DCJN as a recognized brand in independent journalism")
bullet("Launch annual 'Rural India Report' — a comprehensive data-driven publication")
bullet("Host a national citizen journalism conference")
bullet("Explore international expansion opportunities in other developing countries")
bullet("Key milestone: Self-sustaining financially with diversified revenue streams")

heading("F.2 Geographic Scaling Model", level='sub')
body(
    "Geographic expansion follows a 'hub-and-spoke' model. Each new state is entered by establishing a regional hub "
    "in the capital city, staffed by a Regional Coordinator and 1-2 Senior Editors. From this hub, recruitment extends "
    "to 3-5 districts in the first quarter, and to 8-10 districts by the end of the first year in the new state. "
    "This model allows for centralized quality control while enabling rapid geographic coverage. The hub also serves as "
    "a base for local NGO partnerships, media outreach, and contributor community events."
)

heading("F.3 Community Building", level='sub')
body(
    "Building a strong sense of community among contributors is essential for retention and quality. DCJN implements "
    "several community-building initiatives:"
)
bullet("<b>Monthly virtual meetups:</b> Contributors join optional online sessions to discuss challenges, share experiences, and hear from guest speakers (experienced journalists, digital security experts, and community leaders)")
bullet("<b>Contributor leaderboard:</b> A gamified leaderboard recognizes top contributors each month, fostering healthy competition and motivation")
bullet("<b>Mentorship program:</b> Senior Contributors mentor newly certified contributors through their first 10 submissions")
bullet("<b>Annual contributor summit:</b> An in-person event (travel costs covered by DCJN) bringing together top contributors for workshops, networking, and recognition awards")
bullet("<b>Private community forum:</b> A secure, anonymous forum where contributors can discuss reporting techniques, share resources, and support each other")

heading("F.4 Brand Development", level='sub')
body(
    "DCJN's brand is built on four pillars: <b>Trust</b> (verified, accurate reporting), <b>Courage</b> (reporting "
    "what matters, even when it's difficult), <b>Inclusivity</b> (amplifying voices from underserved communities), and "
    "<b>Transparency</b> (open about methodology, funding, and corrections). The brand development strategy includes: "
    "a consistent visual identity (logo, color palette, typography) applied across all platforms; a content strategy "
    "that positions DCJN as a thought leader on citizen journalism and media democratization; strategic media appearances "
    "by the CEO and Editorial Director in industry publications and conferences; and a social media presence focused on "
    "impact storytelling — highlighting real-world changes catalyzed by DCJN reports. By Year 3, the target is brand "
    "recognition among 30% of the target demographic and regular mentions in mainstream media as a credible source of "
    "rural news and ground-level reporting."
)

story.append(PageBreak())

# ══════════════════════════════════════════════════════════════
# G. IMPLEMENTATION TIMELINE
# ══════════════════════════════════════════════════════════════
heading("G. IMPLEMENTATION TIMELINE")
body(
    "The implementation timeline provides a detailed, month-by-month roadmap for executing the business plan. "
    "Each phase has clearly defined deliverables, milestones, and success metrics."
)

# Phase 1
heading("Phase 1: Platform & Training Setup (Months 1-6)", level='sub')

p1_data = [
    [Paragraph("<b>Month</b>", styles['TableHeader']), Paragraph("<b>Activities</b>", styles['TableHeader']),
     Paragraph("<b>Deliverables</b>", styles['TableHeader']), Paragraph("<b>Key Milestones</b>", styles['TableHeader'])],
    [Paragraph("1-2", styles['TableCellCenter']),
     Paragraph("Business registration, legal setup, initial hiring (CEO, Tech Lead, 1 Developer), finalize curriculum outline", styles['TableCell']),
     Paragraph("Registered entity, bank accounts, legal agreements drafted, curriculum framework document", styles['TableCell']),
     Paragraph("Entity registered, core team of 3 onboarded", styles['TableCell'])],
    [Paragraph("3-4", styles['TableCellCenter']),
     Paragraph("Platform development (LMS + submission portal), hire Editorial Director, Training Manager, begin curriculum content creation", styles['TableCell']),
     Paragraph("Alpha version of LMS, 3 modules of content drafted, editorial guidelines document", styles['TableCell']),
     Paragraph("Platform alpha live, editorial team in place", styles['TableCell'])],
    [Paragraph("5-6", styles['TableCellCenter']),
     Paragraph("Beta testing of platform, hire first 2 Junior Editors, Security Officer, complete all 5 training modules, begin pilot recruitment (50 candidates)", styles['TableCell']),
     Paragraph("Beta-tested platform, complete curriculum, 50 pilot enrollees, security protocols documented", styles['TableCell']),
     Paragraph("Platform beta live, 50 pilot enrollees, all 5 modules ready", styles['TableCell'])],
]
story.append(make_table(p1_data, col_widths=[0.7*inch, 2.1*inch, 2.1*inch, 1.8*inch]))
spacer(12)

# Phase 2
heading("Phase 2: Pilot Launch (Months 7-12)", level='sub')

p2_data = [
    [Paragraph("<b>Month</b>", styles['TableHeader']), Paragraph("<b>Activities</b>", styles['TableHeader']),
     Paragraph("<b>Deliverables</b>", styles['TableHeader']), Paragraph("<b>Key Milestones</b>", styles['TableHeader'])],
    [Paragraph("7-8", styles['TableCellCenter']),
     Paragraph("Launch pilot training with 50 candidates, begin public website content, initiate first NGO partnership discussions", styles['TableCell']),
     Paragraph("First cohort in training, website live with initial content, 2+ NGO conversations initiated", styles['TableCell']),
     Paragraph("Training live, public website launched", styles['TableCell'])],
    [Paragraph("9-10", styles['TableCellCenter']),
     Paragraph("First batch of contributors certified, begin accepting news submissions, launch editorial workflow, hire Finance Manager, Recruitment Coordinator", styles['TableCell']),
     Paragraph("20-30 certified contributors, first published stories, functional editorial pipeline, payment system operational", styles['TableCell']),
     Paragraph("First stories published, point system active", styles['TableCell'])],
    [Paragraph("11-12", styles['TableCellCenter']),
     Paragraph("Scale recruitment to 500 target, optimize editorial processes based on pilot learnings, launch second training cohort, execute initial marketing campaigns", styles['TableCell']),
     Paragraph("500 enrollees, 100+ certified contributors, 500+ published stories, 50,000 monthly visitors, 1 signed NGO partnership", styles['TableCell']),
     Paragraph("500 enrollees, 100+ certified, 1 NGO deal", styles['TableCell'])],
]
story.append(make_table(p2_data, col_widths=[0.7*inch, 2.1*inch, 2.1*inch, 1.8*inch]))
spacer(12)

# Phase 3
heading("Phase 3: Expansion (Year 2 - Months 13-24)", level='sub')

p3_data = [
    [Paragraph("<b>Quarter</b>", styles['TableHeader']), Paragraph("<b>Activities</b>", styles['TableHeader']),
     Paragraph("<b>Deliverables</b>", styles['TableHeader']), Paragraph("<b>Key Milestones</b>", styles['TableHeader'])],
    [Paragraph("Q1 (M13-15)", styles['TableCellCenter']),
     Paragraph("Expand to 2-3 additional districts, launch mobile app beta, hire 2 more editors, pursue Series A funding", styles['TableCell']),
     Paragraph("Mobile app beta, 750+ total contributors, expanded geographic coverage, Series A pitch deck", styles['TableCell']),
     Paragraph("Mobile app beta, 750 contributors, Series A initiated", styles['TableCell'])],
    [Paragraph("Q2 (M16-18)", styles['TableCellCenter']),
     Paragraph("Mobile app public launch, expand to additional state, sign 3-5 NGO partnerships, launch premium membership", styles['TableCell']),
     Paragraph("Public mobile app, presence in 2+ states, 5 NGO deals, premium tier live, 1,000+ contributors", styles['TableCell']),
     Paragraph("App live, premium tier launched, 1,000+ contributors", styles['TableCell'])],
    [Paragraph("Q3 (M19-21)", styles['TableCellCenter']),
     Paragraph("Begin content syndication, launch advanced training modules, host first contributor meetup", styles['TableCell']),
     Paragraph("1-2 syndication deals, advanced courses live, contributor community events, 1,200+ contributors", styles['TableCell']),
     Paragraph("First syndication deal, advanced training", styles['TableCell'])],
    [Paragraph("Q4 (M22-24)", styles['TableCellCenter']),
     Paragraph("Consolidate operations, optimize unit economics, prepare Year 3 expansion plan, annual impact report", styles['TableCell']),
     Paragraph("Impact report published, 1,500+ contributors, 8,000+ published stories, 200K+ monthly visitors", styles['TableCell']),
     Paragraph("1,500 contributors, 200K visitors, impact report", styles['TableCell'])],
]
story.append(make_table(p3_data, col_widths=[0.9*inch, 2.0*inch, 2.0*inch, 1.7*inch]))
spacer(12)

# Phase 4
heading("Phase 4: Scaling (Year 3 - Months 25-36+)", level='sub')

p4_data = [
    [Paragraph("<b>Quarter</b>", styles['TableHeader']), Paragraph("<b>Activities</b>", styles['TableHeader']),
     Paragraph("<b>Deliverables</b>", styles['TableHeader']), Paragraph("<b>Key Milestones</b>", styles['TableHeader'])],
    [Paragraph("Q1 (M25-27)", styles['TableCellCenter']),
     Paragraph("Expand to 4-5 states, establish 2 regional editorial hubs, hire regional coordinators", styles['TableCell']),
     Paragraph("2 regional hubs, presence in 4-5 states, 2,500+ contributors", styles['TableCell']),
     Paragraph("Regional hubs operational, 2,500 contributors", styles['TableCell'])],
    [Paragraph("Q2 (M28-30)", styles['TableCellCenter']),
     Paragraph("Launch annual 'Rural India Report,' host first citizen journalism conference, expand syndication to 5+ outlets", styles['TableCell']),
     Paragraph("Published annual report, successful conference, 5 syndication partners, 3,000+ contributors", styles['TableCell']),
     Paragraph("Annual report published, conference held", styles['TableCell'])],
    [Paragraph("Q3 (M31-33)", styles['TableCellCenter']),
     Paragraph("Optimize revenue per story, explore international expansion opportunities, launch data licensing product", styles['TableCell']),
     Paragraph("Data licensing revenue stream, international feasibility study, 3,500+ contributors, 400K+ visitors", styles['TableCell']),
     Paragraph("Data licensing live, international study complete", styles['TableCell'])],
    [Paragraph("Q4 (M34-36)", styles['TableCellCenter']),
     Paragraph("Achieve operating breakeven trajectory, publish Year 3 impact report, plan Phase 5 (national coverage)", styles['TableCell']),
     Paragraph("4,000+ contributors, 500K+ monthly visitors, 25,000+ stories, approach break-even", styles['TableCell']),
     Paragraph("4,000 contributors, break-even trajectory", styles['TableCell'])],
]
story.append(make_table(p4_data, col_widths=[0.9*inch, 2.0*inch, 2.0*inch, 1.7*inch]))
spacer(12)

# Final section
story.append(Spacer(1, 24))
story.append(HRFlowable(width="100%", thickness=2, color=PRIMARY, spaceAfter=16))
story.append(Paragraph("— END OF BUSINESS PLAN DOCUMENT —", ParagraphStyle(
    'EndNote', parent=styles['BodyText2'], alignment=TA_CENTER, fontName='Helvetica-Bold',
    fontSize=12, textColor=PRIMARY
)))
story.append(Spacer(1, 8))
story.append(Paragraph(
    "This document is the intellectual property of the Decentralized Citizen Journalism Network (DCJN). "
    "It is provided for authorized internal use and investor/partner evaluation purposes only. "
    "Reproduction or distribution without written consent is prohibited.",
    ParagraphStyle('EndDisclaimer', parent=styles['FooterNote'], alignment=TA_CENTER)
))
story.append(Spacer(1, 8))
story.append(Paragraph(
    f"Document generated: {datetime.datetime.now().strftime('%B %d, %Y at %H:%M')}",
    ParagraphStyle('GenDate', parent=styles['FooterNote'], alignment=TA_CENTER)
))

# ══════════════════════════════════════════════════════════════
# BUILD PDF
# ══════════════════════════════════════════════════════════════
print("Building PDF...")
doc.build(story, onFirstPage=add_page_number, onLaterPages=add_page_number)
print(f"PDF saved to: {OUTPUT}")

# Word count estimation
import re
all_text = []
for item in story:
    if hasattr(item, 'text'):
        all_text.append(item.text)
full_text = ' '.join(all_text)
words = len(re.findall(r'\b\w+\b', full_text))
print(f"Approximate word count: {words}")

